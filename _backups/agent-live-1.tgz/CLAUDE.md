# avaTOK-2-Flutter

---

## 🚨 STAGING vs PRODUCTION — AI READ THIS FIRST (2026-07-09)

**The owner is not a developer and will never type a deploy command. You handle all
of this. He tells you WHICH environment in plain English; you do the rest.**

### RULE 1 — At the start of EVERY new session, ask with a widget

Before doing any real work in a fresh session (first substantive request — not for
pure chat or a one-line factual question), call **AskUserQuestion**:

> **header:** `Scope`
> **question:** "What are we working on in this session?"
> **options:** `Staging feature` · `Staging bug` · `Production feature` · `Production bug`
>
> (the tool always offers "Other" automatically, where he can type a custom issue)

Then **write the resulting environment into `.avatok-target`** (`staging` or `prod`)
and say so in one short line. That file is the single source of truth for the rest
of the session; `scripts/cf.sh` and `scripts/flags.sh` read it.

- Answer is *Other* / ambiguous → ask one follow-up, or default to **staging**.
- Anything production → say plainly that production is live, and confirm before
  each write.
- If the owner already stated the environment in his message, skip the widget and
  just write the file.

### RULE 2 — On any build request, ask TWO widget questions, then do it all

Any request to build, deploy, ship, release, or "push it up" starts with
AskUserQuestion — **never** infer the answer from `.avatok-target` or the branch.
A build is the moment a mistake reaches real users.

1. **`Environment`** — "Staging build or production build?" → `Staging` · `Production`
2. **`Format`** — "APK or AAB?" → `APK (Recommended)` · `AAB` · `Both`
   (APK is the standing default — owner decision 2026-07-04.)

Then do the whole thing yourself. Do **not** hand him commands:

```bash
# staging build  (staging code, staging backend)
gh workflow run android.yml --ref staging -f environment=staging -f artifact=apk -f play_track=none

# production build (main code, prod backend) — only on an explicit request
gh workflow run android.yml --ref main    -f environment=prod    -f artifact=apk -f play_track=none
```

#### 📲 ~~"ship local"~~ — **DEAD as of 2026-09-10. There is no adb and no local APK.**

> 🚫 The whole local toolchain was deleted on 2026-09-10 (see the Tooling section
> below). `scripts/push_apk.sh` cannot run: `adb` is gone. If the owner says "ship
> local", tell him local installs are gone by his own 2026-09-10 decision and offer
> `ship it` instead. **Do not reinstall the Android SDK to make this work.**
> The historical text is kept below only so the script and its arguments stay readable.

#### 📲 THE OTHER MAGIC WORD: **"ship local"** (added 2026-08-22 — SUPERSEDED)

**"ship local"** is NOT a cloud build and has nothing to do with `gh workflow run`,
Play, or `latestAppBuild`. It means: **take the APK that was just built locally and
FRESH-install it on every connected target.** Skip the two widget questions; the
phrase already answers them. As of 2026-09-05 that is **the phone only** — the
emulator AVD no longer exists (see the target table below).

```bash
scripts/push_apk.sh                              # newest APK under app/build/ -> BOTH
scripts/push_apk.sh path/to/app.apk              # explicit APK -> BOTH
scripts/push_apk.sh path/to/app.apk ZA223K79KG   # phone only
scripts/push_apk.sh --keep-data                  # in-place upgrade instead (rare)
```

**Fresh install is the DEFAULT, deliberately** (owner decision 2026-08-22): the
emulator **hangs on in-place updates**, so the script force-stops the app,
`adb uninstall ai.avatok.avatok_call`, then installs clean. This **wipes app data —
he will be logged out.** Say so in one line when reporting; do not
quietly reach for `--keep-data` to avoid it, and do not "improve" the script back to
`adb install -r` as the default.

🚨 **AS OF 2026-09-10 THERE ARE NO LOCAL TARGETS AT ALL — `adb` and the SDK were
deleted with the rest of the toolchain. Everything below is history.**

🚨 **THERE IS ONLY ONE TARGET TODAY — THE EMULATOR IS GONE (verified 2026-09-05).**
`emulator -list-avds` prints **nothing**. `~/.android/avd/Pixel_10a.avd` still
exists but is a 4 KB husk containing only `tmpAdbCmds` — no `config.ini`, no disk
images — and the `Pixel_10a.ini` that registers it is missing, so the emulator
exits with `Unknown AVD name [Pixel_10a]`. Do not "start the emulator" and wait for
a device that will never appear; the leftover directory makes it look present when
it is not.

| Target | Serial | State |
|---|---|---|
| motorola edge 70 fusion (owner's phone) | `ZA223K79KG` | ✅ Android 16 (API 36), `arm64-v8a` |
| Android emulator | ~~`emulator-5554`~~ | ❌ AVD deleted — must be recreated before use |

To bring the emulator back, the `android-36` `google_apis_playstore` `arm64-v8a`
system image **is still installed**, so only the AVD itself needs creating
(`avdmanager create avd`). **Ask the owner first** — see the disk warning below.

**⚠️ `push_apk.sh` takes the APK PATH FIRST, then the serial.** A bare
`scripts/push_apk.sh ZA223K79KG` is read as an APK path and dies with
`APK not found: ZA223K79KG`, which reads like a missing build rather than a
misplaced argument. Correct form:
`scripts/push_apk.sh app/build/app/outputs/flutter-apk/app-debug.apk ZA223K79KG`.

The script does **not** build. If no APK exists under `app/build/`, it says so and
exits — that is the signal the build hasn't happened yet, not a bug to route around.

If a target is missing from `adb devices`: MTP/"File transfer" mode alone is NOT
enough — **USB debugging** must be on in Developer options and the RSA prompt
accepted on the phone. Keep the screen unlocked during install; a locked Motorola
throws `INSTALL_FAILED_USER_RESTRICTED`.

⚠️ **This section does not license a local BUILD.** The no-local-toolchain rule and
the disk-space constraint still govern that; `ship local` only covers the install
step for an APK someone else already produced.

#### 🚀 THE MAGIC WORD: **"ship it"**

The owner asked (2026-07-15) for one phrase that means *do the whole thing*. **"ship
it"** — or "ship a build", "ship to my phone" — is an EXPLICIT build request and is
the one case where you skip the two widget questions above, because the phrase
already answers them. Run exactly:

```bash
gh workflow run android.yml --ref main -f environment=prod -f artifact=both -f play_track=alpha
```

⚠️ **The track is `alpha`, NOT `internal` — changed 2026-08-20.** Distribution moved
to Closed Alpha (`[PLAY-ALPHA-36]`), and the two steps that make an update actually
REACH the phone — "Point the update check at this build" and "Send and verify the
update FCM notification" — are gated `if: env.PLAY_TRACK == 'alpha'` in
`android.yml`. Ship to `internal` and both silently SKIP: the `.aab` publishes to
Play and the run goes green, but `latestAppBuild` never moves, so the app compares
the new build against a stale pointer and tells the owner *"you're on the latest
version"* forever. That is exactly what happened on run #600 (build 10600 live on
Play, KV still on 10597) and it cost a debugging session. A green run is NOT proof
the update shipped — see step 4 below.

**Then APPROVE the production gate yourself.** "ship it" means the whole thing;
leaving the run parked on the gate and telling him to go and click a button in
GitHub is exactly the hand-him-commands behaviour this section forbids. The
`gh` CLI is authenticated as `hdavy2002`, who is the required reviewer, so the
agent can approve. Discovered 2026-08-01 — before that, agents were stopping at
the gate and the owner was clicking Approve by hand for no reason.

```bash
RUN=<run id printed by the command above>
REPO=hdavy2002/avatok-flutter-nostr-cloudflare

# 1. Get the environment id and confirm you're allowed to approve.
gh api "repos/$REPO/actions/runs/$RUN/pending_deployments"
#    -> read .[0].environment.id and check .[0].current_user_can_approve == true

# 2. Approve. NOTE: must be piped as JSON via --input -.
#    `-f "environment_ids[]=123"` FAILS with 422 "not an integer" because -f
#    sends every value as a string and this endpoint wants a real int array.
echo '{"environment_ids":[<ENV_ID>],"state":"approved","comment":"<why>"}' \
  | gh api --method POST "repos/$REPO/actions/runs/$RUN/pending_deployments" --input -
```

**Only auto-approve when the owner actually said "ship it"** (or equivalent).
The gate is a real checkpoint — the magic word IS the approval. Never approve a
build he did not ask for, and never approve one you started speculatively.

**Before shipping, check whether a build is already queued for the same code.**
A build carries the SHA it was triggered from. If a run is already waiting and
`git diff --name-only <run-sha> HEAD -- app/` is EMPTY, the client code is
identical — approve that run instead of cancelling and burning another ~30
minutes. Only re-trigger when `app/` genuinely differs. Conversely, if a queued
run PREDATES a client fix, cancel it: approving it ships stale code to the
Closed Alpha track.

CI does the rest with no further input:

1. builds the `.aab` **and** the side-loadable arm64 `.apk`
2. publishes the `.aab` to the Play **Closed Alpha** track
3. sets `latestAppBuild` in prod KV to that build number (`10000 + run_number`)
4. verifies the flag landed (cache-busted) and sends the update FCM

Then he opens AvaTOK, hits Update, and it updates. **Nothing is manual — he never
downloads an .aab and never touches the Play Console.** If you find yourself telling
him to upload something by hand, the automation has broken; fix it rather than
routing around it.

**ALWAYS confirm steps 3 and 4 actually RAN before reporting a successful ship.**
They are conditional steps, so a skip is silent and the run still goes green:

```bash
gh run view <RUN_ID> --json jobs \
  --jq '[.jobs[].steps[] | {n:.number, name:.name, c:(.conclusion//"-")}] | .[] | "\(.n). \(.name) = \(.c)"'
# "Point the update check at this build" MUST be `success`, not `skipped`.

curl -s -H 'Cache-Control: no-cache' "https://api.avatok.ai/api/config?cb=$RANDOM" \
  | python3 -c "import sys,json;print(json.load(sys.stdin)['latestAppBuild'])"
# MUST equal 10000 + the run NUMBER (not the run id). `gh run list` shows both.
```

If the number did not move, the owner will never see the update no matter what Play
says. Fix it with `ALLOW_PROD=1 scripts/flags.sh set latestAppBuild=<n>` (a
deliberate production write — say so plainly), and fix whatever made the step skip.

Note `latestAppBuild` is a POINTER, not a fact about Play: the app compares its own
`package_info` build number against it (`core/update_service.dart`), so the two can
disagree in both directions. Bumping it for a build Play has not finished reviewing
gives users an update prompt leading nowhere; leaving it stale after a successful
publish gives them silence.

Still true: **never** trigger a build he didn't ask for. "ship it" is the ask.

`android.yml` has a **guard step**: prod must be built from `main`, staging from
`staging`. A mismatched dispatch fails fast instead of shipping the wrong code.

Builds are `workflow_dispatch` only. **Never trigger one unless the owner explicitly
asks** (see the Git protocol section below). Report back the run URL.

### How you actually do it (owner never sees these)

Never invoke `wrangler` / `npx wrangler` directly. Bare `wrangler deploy` and
`wrangler kv key put …` resolve the TOP-LEVEL `wrangler.toml` block — that is
**PRODUCTION**, silently, with live users on it. That was the root cause of
"staging flag work broke my prod testers." Everything goes through the wrapper,
which reads `.avatok-target` and **refuses prod unless `ALLOW_PROD=1`**:

```bash
scripts/cf.sh worker deploy       # obeys .avatok-target
scripts/cf.sh consumers deploy
scripts/cf.sh calls deploy

scripts/flags.sh set ringbackEnabled=true   # feature flags, same protection
scripts/flags.sh get / effective / unset / prune
```

`npm run deploy` in `worker/` and `consumers/` is **disabled on purpose** — it used
to deploy to prod. KV holds **overrides only**; `DEFAULTS` in
`worker/src/routes/config.ts` is the source of truth and readers layer it
underneath. Never re-materialize all flags into the blob (`{...DEFAULTS, ...current}`)
— that pins stale values forever and makes one flag flip rewrite all ~76.

**A flag the client reads but `config.ts` does not declare is a FAKE flag.** A
client-side `_b('someFlag', true)` compiles and looks like a working kill switch,
but `putConfig` rejects any key not in `DEFAULTS` (`unknown key`, 400) — so it can
never be flipped, and the client's fallback is its permanent value. `inAppUpdateEnabled`
shipped this way and was discovered on 2026-07-15: the documented brake on a feature
that auto-installs updates without user consent could not actually be pulled. When
you add a `RemoteConfig` getter, declare the key in the `PlatformConfig` interface
**and** in `DEFAULTS` in the same change (numbers also need a `numericKeys` entry;
booleans don't), then prove it: `ALLOW_PROD=1 scripts/flags.sh set <key>=false`
must not 400, and the cache-busted `/api/config` must reflect it.

Builds themselves are `workflow_dispatch` only and **you never trigger one unless
the owner explicitly asks** (see the Git protocol section below).

---

## 💰 THE UNIT IS A **TOKEN**, AND 1 TOKEN = **₹1** (owner decision 2026-08-05)

**Never write "coin" or "AvaCoin" again, and never print a `$` for a wallet
amount.** The word is **token**; the symbol is **₹**. India is the only market
for now — there are no international customers, and Wise/USD payouts are not in
use. `[TOKENS-INR-1]` renamed every capitalised `Coin`/`Coins` identifier and
switched every money formatter to `₹`.

**This was a relabel, not a revaluation.** No balance, price, ledger row or D1
column changed value, because the stored integer already WAS the rupee at both
ends of the pipe:

- money-in — `worker/src/routes/wallet.ts` INR rail: `tokens = round(paise/100)`
- money-out — `worker/src/routes/upi_payout.ts`: `gross_inr_paise = tokens * 100`

The display layer was the last holdout still calling that same integer a US cent
and printing `$`. It is near-parity anyway: at `cfg.usdInrRate = 96.4`, one US
cent is ₹0.964, so ₹1/token and $0.01/token differ by ~3.6%.

### What must NOT be renamed — and why each one bites

1. **Every lowercase `snake_case` form is frozen**: `amount_coins`, `gross_coins`,
   `price_coins`, `escrow_coins`, `balance_coins`, `held_coins`, `coins_per_usd`,
   `insufficient_avacoins`, Stripe `metadata[coins]`. These are the client↔server
   wire contract and D1 column names. Shipped clients keep sending and reading
   them forever; a rename is a silent break for every user who hasn't updated.
   The precedent for changing a client-visible one is `routes/call_translation.ts`
   — dual-emit `insufficient_tokens` **and** `error_legacy: insufficient_avacoins`
   for a release cycle, and accept both on the client.
2. **Five remote-config flag keys still end in `...Coins`**:
   `upiPayoutMinCoins`, `affiliateDailyEarnCapCoins`,
   `affiliateMonthlyEarnCapCoins`, `affiliatePerReferredCapCoins`,
   `affiliateMinQualifyingTopupCoins`. The key must match `DEFAULTS` in
   `routes/config.ts` **and** the override blob already sitting in prod KV.
   Rename one and the flag silently reverts to its default.
3. **`STORAGE_COINS_PER_GB` is a wrangler env binding**, not a variable.
4. **`PhosphorIcons.coins(...)` / `PhosphorIcons.handCoins(...)` are package
   symbols.** A blind coins→tokens sed produces `handTokens`, which does not
   exist — that is a compile error, and with no local Flutter toolchain you will
   only find it 40–80 minutes later in CI.
5. **Legacy `currency_display` values** `COINS`/`COIN`/`AVACOIN` are persisted in
   D1 `listings.currency_display`. `intent_theme.dart` must keep resolving them
   or those rows render as the literal string `COINS 2000`.

### Real US dollars that must KEEP their `$`

`micro_usd` cost accounting (`TOKEN_MICRO_USD`, `AI_TOKENS_PER_USD` — provider
invoices genuinely are USD), Google Play tier labels and `_usdFromCents` in
`wallet_screen.dart` (Play still bills the USD-defined SKU at its localised
rate — the app says so at `wallet_screen.dart:686`), `kMinTopUpUsd`,
`subscribe_screen.dart` plan prices, the USD branch of `wallet_statement.ts`,
and the multi-currency `_currencySymbol` map in `intent_theme.dart` (marketplace
listings are a separate, genuinely multi-currency unit).

### Four ways flags and deploys will lie to you (learned the hard way 2026-07-15)

**1. NEVER state an effective flag value from `config.ts`. Go and read prod.**
`DEFAULTS` in `config.ts` is only the bottom layer; KV overrides sit on top. On
2026-07-15 an agent read `avaSms: false` / `avaDialer: false` in DEFAULTS and told
the owner his shipped dialer and SMS features were off and his Play permissions
were unjustified — while prod KV had **both overridden to `true`** and real users
on them. The advice that followed (strip the permissions) would have deleted live
functionality. The DEFAULTS block tells you what happens when KV is silent; it
tells you *nothing* about production. Before any claim about a live flag:

```bash
ALLOW_PROD=1 scripts/flags.sh get          # raw KV overrides
curl -s -H 'Cache-Control: no-cache' "https://api.avatok.ai/api/config?cb=$RANDOM"
```

**2. `GET /api/config` is edge-cached for 60s — a plain curl will show you a stale
value right after a KV write.** `getConfig` sets `cache-control: public, max-age=60`.
Always cache-bust (`-H 'Cache-Control: no-cache'` **and** a random query param), or
you will "confirm" a write that hasn't landed, or think one failed when it worked.

**3. A worker deploy takes ~30–60s to reach every colo.** During that window probes
flap between the old and new version — the same cache-busted URL will return the new
value, then the old, then the new. That is propagation, **not** a failed deploy and
not a gradual-deployment split (check `wrangler deployments list` — a normal deploy
is one version at 100%). Wait a minute and re-probe several times before concluding
anything. An agent burned a chunk of a session chasing a phantom rollback here.

**0. A GREEN DEPLOY IS NOT A GREEN TYPECHECK. Run `npx tsc --noEmit` in
`worker/` BEFORE every `cf.sh worker deploy`.** Wrangler builds with esbuild,
which strips types without checking them, so a deploy succeeds on code that does
not compile. On 2026-08-01 a `track()` call went to prod with 3 args instead of
5; the props object landed in the `app_name` slot and the alert it powered would
have fired malformed — which, for an alert, is the same as not firing. Nothing
failed. Nothing warned. The deploy was green.

**5. NEVER run `flags.sh set` twice in a row. KV is eventually consistent, so
the second call reads a STALE blob and silently drops the first write.** On
2026-09-02 three back-to-back sets on staging left only the last key standing —
twice. `flags.sh set` takes many `k=v` in ONE call (one read, one write): use
that form, then wait ~60s and confirm with `flags.sh get` before believing it.
Same trap for `unset`.

**6. `scripts/d1_apply_alters.py` applies ONLY the `ALTER … ADD COLUMN` lines
of a file.** A `CREATE TABLE` sitting in the same migration is skipped silently
(`review_helpful`, 2026-09-02). Keep CREATEs in their own file and apply those
with `scripts/cf.sh worker d1 execute DB_META --remote --file=migrations/<f>.sql`
(path is relative to `worker/`), or run the CREATE as `--command`.

**7. Staging D1 was 23 `listings` columns behind prod until 2026-09-02** — the
July taxonomy migrations had never been applied there. Before testing a
listings feature on staging, diff `PRAGMA table_info` against the migrations.

**4. COMMIT worker source BEFORE `cf.sh worker deploy`.** The tree is shared by
several agents. On 2026-07-15 an agent deployed an uncommitted `config.ts` edit;
another agent's deploy landed **49 seconds later** from a tree without that change
and silently reverted it in production. Deploying uncommitted code means the next
agent's deploy erases yours, and nothing records that it ever existed.

### Promotion to production is CODE + MIGRATIONS ONLY

Merge `staging` → `main`, then deploy with `ALLOW_PROD=1` and run any D1 migration
against prod as a deliberate step. **Never copy staging D1 rows, DO SQLite, R2
objects, or the KV flag blob into production** — staging data is throwaway and
copying the flag blob would wipe every real user's config. Prod flags are flipped
one at a time, when the owner says so.

If a task seems to require a production write and the owner has not explicitly said
"production", **stop and ask.**

---

## ⚠️ ARCHITECTURE PIVOT — NOSTR IS DEPRECATED (2026-06-09)

**The Nostr/relay/E2E-gift-wrap messaging design is NULLED going forward.** AvaVerse
is now a Cloudflare-native, **server-readable** architecture (per-user `InboxDO` with
hibernatable WebSocket + DO-local SQLite; server is router; device stays local-first).
Canonical: **`Specs/AVAVERSE-CLOUDFLARE-NATIVE-ARCH.md`** and handover
**`Specs/HANDOVER-2026-06-09-cloudflare-native-pivot.md`**. Where the Nostr "Engineering
rulebook" below or `Specs/AVATALK-CLOUDFLARE-RULEBOOK.md` conflict with the new arch,
**the new arch wins** (those files are pending rewrite). Do NOT re-introduce Nostr
(NIP-17/44/59, gift-wrap, keypairs, NIP-42/98, the relay Worker). Do NOT make a single
central D1 the high-write message store — messages live in DO-local SQLite per user.
Still valid: per-account scoping. NOTE (2026-06-10): the old "1:1-only calls" rule
was CHANGED in Phase 10 — group conferences ≤25 via Cloudflare Realtime were then allowed.
NOTE (2026-08-27): **the whole media-provider question is SUPERSEDED by the PRODUCT PIVOT
section at the top of this file** — paid live streaming and paid 1:1 consultations run on
GetStream (Mumbai), Messenger calling is being killed, and Cloudflare carries no
user-facing real-time media.

---

## 🤖 AI VOICE AGENT LISTINGS — `[AGENT-LIVE-1]` (2026-09-12)

AvaTOK sells paid live talks with an AI voice agent (`kind='agent'`, section
`ai_voice_agents`) on OpenAI's `gpt-live-1`, delegating reasoning to
`gpt-6-astra`. Canonical spec, build first: **`Specs/SPEC-2026-09-12-AGENT-LIVE-1-BUILD.md`**
(money rules also live in `Specs/RULEBOOK-PAID-SESSIONS.md` §8). Five things bite:

1. **Only `AGENT_ADMIN_UIDS` can create/edit/publish agents — it is a Worker env
   var, not a remote-config flag.** Never move agent-admin gating into KV/config.
2. **GPT-Live-1 has no image input.** Photos never go to the live model directly —
   they go through the vision side channel (upload → `DIGITAL` → a Responses API
   vision call on the backend model → spoken commentary).
3. **`agl_` orders move money ONLY via `agent_live_decisions` + `agent_live_money_jobs`.**
   Never `worker/src/routes/admin_money.ts` and never a bare `release()` — those
   are rejected for `agl_` orders on purpose (BUILD SPEC §11 M1/M6).
4. **Every customer artifact (transcripts, uploaded photos, KB files) lives in
   the private `DIGITAL` R2 bucket — never `BLOBS`.**
5. **The seat authority DO (`AgentSeatAuthorityDO`) is the only thing that knows
   whether a slot is free.** Never infer availability by counting D1 rows —
   `agent_live_bookings` is a projection, not the source of truth.

---

## 📕 PAID-SESSION RULEBOOK — READ BEFORE TOUCHING CALLS OR SESSIONS (owner decision 2026-09-11)

**`Specs/RULEBOOK-PAID-SESSIONS.md` is the single source of the customer-side and
creator-side rules for paid 1:1 consultations and live events** — who pays for what
when someone is late, absent, or drops; when media may start; what a "delivered
minute" is. Before rebuilding or modifying ANYTHING related to calls, sessions,
lobbies, settlement, refunds, join windows, or the commercial GetStream lane, open
that file first and build to it. If a change needs a rule that is not there, ask the
owner and add the rule to the rulebook in the same change — never invent one in code.

The three rules that bite hardest (full text in the rulebook, v2 2026-09-11):

1. **Waiting room, not a media room.** Opening an appointment connects the device to
   the session's `StreamSessionDO` socket (`consult:<bookingId>`): creator avatar,
   own local preview, meter. GetStream media starts only when the DO reports the
   other party present. Nobody waits inside a GetStream call by default — GetStream
   minutes are avaTOK's cost.
2. **The schedule ends a session, never a provider event.** `call.session_ended`
   closes participant intervals; it must not mark the commercial session ended or
   queue settlement. As of 2026-09-11 the code does the opposite
   (`recordCommercialStreamEvent`, `commercial_stream_sessions.ts:~1974`) — a creator
   who waits alone and steps out closes the door on the customer and gets paid as
   "buyer no-show". Fix this before anything else in this lane.
3. **Two money outcomes, no pro-rata.** Creator checked in within 20 min of
   `starts_at` → customer pays the full slot no matter when (or whether) he joins.
   Creator did not → 100% refund + strike. The pro-rata idea from earlier on
   2026-09-11 was withdrawn by the owner; do not build it.
4. **ALL transmission is from the app (owner decision 2026-09-12, rulebook §7).**
   Creators start live events and 1:1s ONLY in the Flutter app. The browser is for
   CUSTOMERS: a customer who verified his email and paid opens the link from his
   confirmation email, grants camera/mic, sees his own preview plus
   "Waiting for <creator>…" or the creator's video once live, and a side chat that
   accepts file uploads. **He never signs into a dashboard and paying does not make
   him an onboarded user — onboarding happens only in the app.** Never build or
   resurface a browser hosting / green-room / backstage surface for creators; a
   creator-facing web button may only deep-link into the app.

Audit + implementation plan: `Specs/AUDIT-2026-09-11-PAID-SESSION-WAITING-AND-BILLING.md`.

---

## 🔻 PRODUCT PIVOT — MARKETPLACE FIRST, PAID SESSIONS (owner decision 2026-08-27)

**Read this before touching calling, AI-in-chat, numbers, payments or the app shell.**
Canonical: **`Specs/PIVOT-2026-08-27-MARKETPLACE-FIRST-PAID-SESSIONS.md`**. Where ANY
older rule in this file or in `Specs/` conflicts, **this section wins.**

### The product, in one paragraph

**The core product is paid live streaming and paid 1:1 consultations, both on GetStream,
region Mumbai.** The app's default landing screen is **Marketplace**. Messenger keeps
**simple text messaging only** — its audio and video calling is being **killed, and the
call UI hidden**. AI features inside chat go **dark**. Every user's real phone number is
**masked behind an AvaTOK number** (free for all, paid ones cost tokens). **All payments
happen on the web**; the app is **read-only for money**. Listings are identical on web
and app.

### Media providers — final

**GetStream carries all paid session media — live streaming and 1:1 consultations.
Region: Mumbai.** Cloudflare carries **no user-facing real-time media** once Messenger
calling is killed; it remains the application platform (Workers, D1, DOs, R2, Queues, KV,
STUN/TURN/ICE and every non-media service).

| Product | Call type | Call id |
|---|---|---|
| Paid live event | `avatok_livestream` | `live_<listingId>_<sessionVersion>` |
| Paid 1:1 consultation | `avatok_consult_1to1` | `consult_<bookingId>` |

Ids are minted server-side (`worker/src/lib/commercial_stream_sessions.ts:30-55`). Clients
never choose call type, id, price, members or roles.

**Never add a Cloudflare media fallback to the paid lane.** Failing closed is the
specified behaviour — an unmetered session is a money bug
(`Specs/SPEC-2026-08-24-PHASE-2-GETSTREAM-LIVE-CONSULT-MARKETPLACE.md` §1).

⚠️ **Mumbai is NOT set in code.** No region/edge/geo setting exists in
`stream_video_calls.ts`, `commercial_stream_sessions.ts`, `stream_lane.dart` or
`wrangler.toml`. It is a **GetStream dashboard** setting. Never assert the region from
the codebase — check the console.

### Killing Messenger calling — the ONE correct mechanism

Use a **new kill switch, `messengerCallingEnabled` (default `false`)**, enforced at the
single choke point `routeToStreamCallIfEnabled`
(`app/lib/features/avatok/place_1to1_call.dart:53`), plus hiding the UI.

> 🚨 **NEVER disable calling by flipping `streamCallsEnabled` off.** That flag only
> *routes*. Off, every entry point falls through to the legacy Cloudflare `CallScreen`,
> which has failed **100% of calls since build 10612** (`getUserMedia(): unknown
> factoryId null` — `Specs/AUDIT-2026-08-21-build-10612-getusermedia-factoryid.md`).
> You would ship broken calling instead of no calling. `streamCallsEnabled` stays `true`
> because the paid session lane depends on the same SDK, token route and push wiring.

**The engine is one line; the UI is ~19 sites.** No flag today hides the call buttons —
they would stay visible and fail with a snackbar. The full list is in the pivot spec §4.1.
Copy the group-conference pattern at `chat_thread.dart:1340`, which already hides its
affordance behind `conferenceEnabled`. **Also fix the incoming side**
(`push/push_service.dart`), or an old build can still ring a new one.

**If you add a new call entry point, it goes through the gate. Never mount `CallScreen`
directly.** The legacy Cloudflare engine stays compiled but permanently unreachable —
**do not delete it.**

### AI in chat goes dark — and four switches DO NOT WORK

Going dark: **Ava in chat**, **call translation**, **AvaBrain ingestion**.

⚠️ **`aiEnabled` (prod `true`) is a sledgehammer with no client half.** It is enforced
only server-side (`worker/src/lib/ai_gate.ts:471`) and **no Flutter file reads it** —
flipping it off leaves every AI affordance visibly present and silently failing.

🚨 **These flags are declared in `config.ts` DEFAULTS but have ZERO consumers. Flipping
them changes nothing:**

| Flag | Default | Reality |
|---|---|---|
| **`brainEnabled`** | `false` | `worker/src/lib/brain_ingest.ts` reads no platform config — only per-user consent. **AvaBrain ingestion cannot be switched off platform-wide today.** |
| `avaStreamPlainEnabled` | `true` | Dead. 0 refs outside `config.ts`. |
| `companionEnabled` | `true` | Dead. `CompanionHome` renders unconditionally. |
| `avaMessageSearchEnabled` | `false` | Dead. 0 consumers. |

Two AI surfaces have **no flag at all**: **"Discuss with Ava"** (compile-time const
`kDiscussWithAvaEnabled`, `core/feature_flags.dart:84` — needs an APK to disable) and
**AskAva** (`features/askava/askava_screen.dart:62`, only accidentally dark because
`shellV2=false`). **Flipping `shellV2` on for the Marketplace landing ships AskAva with
no way to turn it off.** Build these switches before calling anything dark.

### AvaTOK numbers — the real number is never public

Free AvaTOK number for everyone as the public identity; paid (vanity/short) numbers cost
tokens. Real numbers are collected for signup only, stored as `sha256(E.164)`, and shown
to nobody. A mandatory number-choice gate already ships
(`ava_shell.dart:618-636` → `NumberSettingsScreen(gate: true)`), and the paid step slots
into that same screen.

🚨 **`worker/src/routes/number.ts:340-343` currently does the OPPOSITE**: *"Paid users
share their AvaTOK number; free users their real number."* This leaks the real number of
every free user via the share card. **Highest-priority fix in the pivot.** Also:
`users.private_number` stores raw digits, and `assign-own` (`number.ts:233-239`) lets a
user bind any well-formatted number unverified and be publicly resolvable by it.

Reuse `virtualDidPurchase` (`worker/src/routes/virtual_lines.ts:109-138`) for paid
numbers — `chargeAmount` + stable `opId` + refund-on-failure. **Three overlapping number
systems exist** (`avatok_numbers` live, `virtual_lines` dark, `user_dids` campaign) —
pick one before building. `Specs/SPEC-2026-08-09-personal-did-virtual-number.md` (retire
free numbers, sell a 600-token DID) is **SUPERSEDED** by this decision.

### Payments — web only, app read-only

The app shows balance and receipts and **cannot top up**. Top-up, checkout and payout all
move to the web. Removes Google Play billing and materially simplifies Play compliance.

⚠️ **`playTopupEnabled` defaults `true` and is deliberately independent of
`billingEnabled` — the Android Play top-up button is LIVE in production right now.**
Removing it is a real user-facing and Play-listing change.

⚠️ **Web checkout still quotes USD** (`web/src/islands/checkout/PayStep.tsx` →
`amountUsdCents`; `worker/src/routes/wallet.ts` hard-writes `currency:'usd'`) while
receipts print ₹. **Payments cannot move to the web until this is fixed.**

✅ **CLOSED by `[TOKENS-INR-RAIL-1 2026-08-28]` — the rail speaks rupees now.** The
gap above (site published ₹, Stripe charged $) is fixed; the paragraph is kept so
nobody "restores" the USD rail thinking it was deliberate. What changed:

- `walletTopup` (the WEB Stripe **Checkout** rail, the one that was hard-wired USD)
  now bills `tokens * 100` **paise** with `currency: "inr"`, and stores
  `topup_records.currency='inr'` with `amount_cents` in paise. Its body key is now
  `{ tokens }`; `amountUsdCents` / `amount` still work and **always carried the token
  count, never cents** — the old name was the whole confusion.
- `walletTopupIntent` (app PaymentSheet rail) **defaults to INR**. USD survives for
  exactly one caller: a pre-2026-08-28 app build posting legacy `{ usd_cents }` with
  no `currency`. Defaulting THAT to INR would read 500 cents as 500 paise and credit
  5 tokens instead of 500 — a silent 100× underpay — so `legacyUsdBody` pins it to USD.
  **Do not "simplify" that branch away.**
- `walletTopupQuote` (`/api/wallet/topup-quote`) **no longer geo-branches**. It was
  INR only for `cf.country === 'IN'`. It now returns INR to everyone, because the site
  advertises ₹1 with no country qualifier. This response **drives the Flutter top-up
  sheet**, which falls back to USD whenever the quote is missing or says USD — so this
  one server change fixed the app with **no rebuild and no store release**.
- `creditTopup` receipt meta reads `amount_cents`/`currency` **off the top-up record**
  instead of recomputing `usdCentsForTokens(coins)`, which printed a dollar figure on
  an INR charge. `wallet_statement.ts:formatMoney` already handled ₹ correctly.
- Web display: **one** helper, `web/src/lib/money.ts`. Eight modules each carried
  `` `$${(coins/100).toFixed(2)}` `` — wrong twice over, since 500 tokens are **₹500,
  not ₹5**. The divide-by-100 had to go, not just the `$`. `AgentForm.tsx`'s rate
  field now takes **rupees** (seed = the ₹300 floor) instead of dollars ×100.

⚠️ **`TOKENS_PER_USD` still exists and must NOT be deleted** — Google Play's
`PLAY_TOPUP_PRODUCTS` are fixed USD-defined SKUs and the legacy `usd_cents` body needs
it. It is not a price anyone is quoted.

⚠️ **Stripe is on TEST keys in prod** (`wrangler.toml:101`,
`WALLET_TOPUP_ENABLED="1"` with `sk_test`), and `billingEnabled=false` /
`walletRealMoney=false`. No real money moves, which is why this was safe to change
live. **Before real money-in: a LIVE Stripe account that can actually charge INR.**
Stripe India requires a registered business — which avaTOK is not (see the no-company
section).

🚨 **THE PROVIDER IS AN OPEN QUESTION — DO NOT ASSUME ONE (owner decision 2026-09-02).**
This paragraph used to say "the real rail is expected to be **Cashfree**, not Stripe".
**Cashfree is ruled out — they never replied to the application.** Nothing has replaced
it. So: do not write Cashfree (or any other provider) into a spec, a route, a config key
or this file, and do not tell the owner what the rail "will be" — ASK HIM. Wiring
whichever provider is chosen is a separate project; the INR change above only makes the
currency honest on the rail that exists.

Two leftovers still name the dead provider: the reviewer-onboarding allowlist
`reviewerEmails` is the single address `cashfree@avatok.ai` (moot for now — the gate was
switched off in prod KV on 2026-09-02, `reviewerModeEnabled=false`), and the
company-registration note below. Point both at the real provider once there is one.

Marketplace listings keep their own genuinely multi-currency unit (`ListingTile.tsx`,
`intent_theme.dart`) and are NOT part of this.

### Marketplace as the default screen — the risk is ShellV2, not Marketplace

Production lands on `ChatListScreen` (`shell/ava_shell.dart:662`) with a hardcoded 3-chip
strip (`chat_list.dart:2794-2798`). Marketplace-as-landing requires flipping **`shellV2`**
(`config.ts:1964`, default `false`) — **a whole-shell swap that has never shipped**. It
also needs `marketplaceEnabled=true`, a default-root reorder in BOTH
`shell/v2/root_order_store.dart:34-38` and `shell_v2.dart:183`, and a version bump of the
persisted key `shellv2_root_order_v1` (or existing users keep their saved order and never
see the change). Keep `avaAffiliateEnabled=false` or Affiliate hijacks the slot.

---

## 🏢 THERE IS NO COMPANY — DO NOT PUT ONE BACK (owner decision 2026-08-28)

**avaTOK is an unregistered business in India.** No Indian company has been
incorporated. The public site must never say otherwise.

Until 2026-08-28 every legal page opened by naming **"Ava Global International Pvt
Ltd", Mumbai**, and the commerce pages named a second contracting entity, **"Ava
Global International, Inc.", Delaware**. The Pvt Ltd does not exist. The owner's
decision is that **the US Inc is not named on the site either** — it complicates the
Indian payment-gateway story and no user contracts with it. `[LEGAL-UNREG-1]` removed
both from all 18 pages plus the waitlist email footer.

The published position, and the only one to write:

- Built and operated by an **independent founding team in India** — no entity name.
- **Currently an unregistered business.** Registration of a company in **Mumbai** is
  in process, intended once funding is in place.
- **Ideation and testing stage**: site not fully operational, access **invite-only**,
  payment gateway application for an unregistered business **under review**, prices
  indicative, test data may be reset.
- **Operating address: Mumbai, India.** (Owner decision 2026-09-10, shipped as
  `[WEB-LOCATION-1]`.) The team has **moved to Mumbai**, so the operating address
  and the intended place of registration are now the SAME city and there is no
  longer any distinction to preserve.

  ⚠️ **This paragraph used to say the opposite, and the reversal is the point.**
  It read: *"Operating address: Ekta Vihar, Sahastradhara Road, Dehradun,
  Uttarakhand, India. (Dehradun is where the team is; Mumbai is where the company
  will be registered. Both are correct and they are not the same thing.)"* That
  guard existed because the two cities genuinely meant different things and an
  agent conflating them would have put a false address on the legal pages. **The
  move made the guard obsolete, not wrong** — do not "restore" Dehradun anywhere
  on the strength of an older document, a cached memory note, or this file's
  history. Every mention was removed from `web/src` on 2026-09-10 and the site is
  correct as it stands.

  Still true: Mumbai is where registration is intended once funding is in place,
  and the business remains **unregistered** today. The address changing does not
  change that, and nothing on the site may imply a company now exists.

**Two components own this text — edit them, never a page.**
`web/src/components/LegalStatus.astro` (the who-we-are block, `variant` =
`full` | `who` | `short`) and `web/src/components/BetaBanner.astro` (the site-wide
strip, rendered from `SiteHeader.astro` so it reaches the home page too, which emits
its own document and never touches `Base.astro`). `SiteFooter.astro` carries the
entity line and address sitewide. Writing a fresh entity sentence into a page is how
the site drifted out of truth the first time.

⚠️ **`web/src/pages/grievance.astro` names a Grievance Officer.** With no company
there are no employees — the page says "a member of the avaTOK team", which is the
correct phrasing for an unregistered business under the IT Rules 2021. Do not restore
"employee of <company>".

**When the company is actually registered**, update `LegalStatus.astro`,
`BetaBanner.astro` and `SiteFooter.astro`, publish CIN/GSTIN, and tell the payment
provider (whichever it turns out to be — Cashfree is OUT, see the payments section):
an unregistered merchant must update its business information with the provider once
it incorporates.

⚠️ **Note that `BetaBanner.astro` and the `.bf-entity` block in `SiteFooter.astro` are
no longer RENDERED** — `[WEB-BANNER-OFF-1 2026-09-02]` unmounted the banner from
`SiteHeader.astro` and deleted the footer's status + operating-address block at the
owner's request (that block carried the old Dehradun address; if it is ever
restored it must be restored with the Mumbai address above). Both are kept on disk so they can be restored in one edit. The
disclosure now lives only on `/terms#status`, so **if a payment provider's review asks
for a visible operating address and business status, restoring these is the fix** —
do not write a fresh entity sentence into a page, which is how the site drifted out of
truth the first time.

---

## Graphiti memory — CANONICAL group_id (READ THIS FIRST)

<!-- pre-push hook fallback marker — DO NOT REMOVE. The git pre-push hook greps
     CLAUDE.md for a quoted group id when ~/.graphiti-projects.tsv lacks an entry,
     so the auto-logged push episode lands in the right group. Keep the line below.
     group_id: "proj_avaflutterapp" -->

**This project's Graphiti group_id is `proj_avaflutterapp`. Always pass it explicitly on EVERY graphiti-memory call — both reads and writes. No exceptions.**

- Writes: `add_memory(..., group_id="proj_avaflutterapp")`
- Reads/searches: `search_memory_facts`, `search_nodes`, `get_episodes` → `group_ids: ["proj_avaflutterapp"]`

Rules:

- NEVER omit `group_id`. If you omit it, the Graphiti server falls back to its CLI
  default or **auto-generates a brand-new random group_id**, which silently scatters
  this project's data into a new empty partition. That is the root cause of "my
  graphiti is empty / new project name every session." Treat a missing group_id as a bug.
- NEVER use `personal` (or any other name) for this project. The account-wide preference
  "use group_id 'personal' if none specified" is OVERRIDDEN here — this project always
  uses `proj_avaflutterapp`.
- All existing project history (AvaTalk/AvaTok phases, backend, frontend, go-live items)
  already lives under `proj_avaflutterapp`. Do not create variant names like
  `avatok`, `avatok-2-flutter`, `avaflutterapp`, etc.

At the start of a task, pull context with `search_nodes`/`search_memory_facts` scoped to
`group_ids: ["proj_avaflutterapp"]`. When the user shares durable facts/decisions, save
them with `add_memory(group_id="proj_avaflutterapp")`.

---

## Observability toolset — PostHog (USE FOR DIAGNOSIS + BAKE INTO NEW CODE)

PostHog (project 139917, EU; key `phc_hmYMsHQEYjQU4bYXNdqA4VZVsfHEIkBQdQL0Kv7FIc5`,
host `https://eu.i.posthog.com`) is now the FULL observability stack, not just
product events. When diagnosing anything, query it via the **PostHog MCP** BEFORE
reading code and guessing. When building ANY new feature, wire these in from the start.

**Live products (enabled 2026-07-21):**
- **Error Tracking** — exception autocapture ON. Client uncaught → `$exception`
  (main.dart `FlutterError.onError`/`platformDispatcher.onError` →
  `Analytics.captureException`, scrubbed). Native Android/iOS + isolate crashes via
  `errorTrackingConfig` (needs posthog_flutter 5.x). Server: uncaught Worker
  route/queue error → `$exception` via `hooks.trackException` (index.ts fetch/queue).
  Dig with MCP `query-error-tracking-*`.
- **Session Replay** — ON, fully masked (text+images). App wrapped in `PostHogWidget`
  (main.dart); `sessionReplay=true`, sampleRate 0.2. Open a crash -> watch the replay.
- **Logs** — `AvaLog` non-info lines -> PostHog Logs via `Posthog().captureLog()`
  (analytics.dart sink). Filter by severity; correlate by tag/session/trace_id.
- **LLM Analytics** — receptionist LLM spend -> `$ai_generation`
  (reception_room_cf.ts): `$ai_model/$ai_provider/$ai_input_tokens/$ai_output_tokens/$ai_total_cost_usd/$ai_trace_id`.
- **UI performance** — `PerfMonitor` (perf_monitor.dart) -> `ui_frame_stats`
  (jank/freeze per screen); `ui_content_flash` (cache->network swaps); standardized
  `Analytics.uiInteraction()` + `Analytics.cacheEvent()` helpers. Dashboard
  "AvaTOK — App Health" (id 836684).

**🚨 EVERY SURFACE GETS POSTHOG — NO EXCEPTIONS (owner decision 2026-09-02).**
The website (`web/`) shipped for months with **zero** PostHog: no pageviews, no
errors, no replay. A creator's photo upload failed on 2026-09-02 and there was
nothing to pull — the page swallowed the error and no event existed anywhere.
That is the last time. **PostHog telemetry is a default part of coding and
planning on every surface**: the Astro website, the Flutter Android app, the
iOS app, the macOS/Windows/Linux desktop apps, the Cloudflare Worker, the
consumers — and any surface added later. A plan, spec, or PR for a new surface
or feature that has no telemetry section is incomplete; the reviewer sends it
back. The catalog of what each surface must emit is
`Specs/SPEC-2026-09-02-TELEMETRY-CATALOG.md` — new events are added THERE first,
then coded. Same project (139917, EU), same super-property contract on every
surface: `platform`, `service_name`, `release`, `app`, `email`, `clerk_uid`,
`trace_id`. Web wiring lives in `web/src/lib/analytics.ts` (`[WEB-POSTHOG-1]`);
call it, never `window.posthog` directly.

**Bake-in rules for NEW code (do these by default, like per-account scoping):**
- New async/network path -> failures go through `Analytics.captureException` (client)
  or `hooks.trackException` (worker). No silent `catch {}`.
- New LLM call -> emit `$ai_generation` (`$ai_*` schema) at the completion site
  (mirror reception_room_cf.ts). Wire the Gemini + vobiz lanes the same way.
- New screen/interaction latency -> `Analytics.uiInteraction(name, ms, ...)`, NOT a
  new bespoke `*_ms` event.
- New on-device cache -> `Analytics.cacheEvent(store, 'hit'|'miss'|'stale', renderMs: ...)`.
- Meaningful runtime decisions/failures -> `AvaLog` warn/error (auto-forwarded to
  Logs). Secrets stay out — scrubbing is `_scrub` (client) / `scrubServer` (worker) /
  the `beforeSend` hook.

**PENDING (gates several of the above):** `pubspec.lock` is stale at posthog_flutter
4.11 while pubspec pins ^5.30.0. Run `flutter pub get` -> 5.x, then a build — Logs,
Session Replay, native crash capture, and the `captureLog`/replay code only activate
after that. Alerts deferred (need a Slack/webhook dest, and Issues forming first).

---

## Code search (graphify-avatok-2-flutter)

This project has a graphify knowledge graph at `graphify-out/graph.json`. The
corresponding MCP server name is **`graphify-avatok-2-flutter`** — when answering structural
code questions about this project, call those tools
(`mcp__graphify-avatok-2-flutter__query_graph`, `mcp__graphify-avatok-2-flutter__get_neighbors`,
`mcp__graphify-avatok-2-flutter__get_node`, `mcp__graphify-avatok-2-flutter__shortest_path`).
Do NOT call any other `graphify-*` MCP — those belong to different projects.

Prefer graphify over grep for structural questions: "what calls X", "what imports Y",
architecture and call-flow questions, "find code related to Z". Stick with grep for
literal text / string search (TODOs, error messages, arbitrary tokens).

---

## Engineering rulebook (READ — applies to every app)

**AvaTOK product rule — RULE CHANGE 2026-06-10 (owner decision, Phase 10).**
> 🔻 **SUPERSEDED 2026-08-27 — see the PRODUCT PIVOT section at the top of this file.**
> This paragraph once read "Cloudflare is the only real-time media provider" and said 1:1
> calls stay P2P on the CallRoom DO. **Both claims are dead.** Messenger 1:1 calling moved
> to GetStream on 2026-08-21 and is now being **killed entirely**; paid live streaming and
> paid 1:1 consultations run on **GetStream, region Mumbai**. Group conference is already
> off in prod (`conferenceEnabled=false`) and its fate is an open question in
> `Specs/PIVOT-2026-08-27-MARKETPLACE-FIRST-PAID-SESSIONS.md` §12. The historical rule is
> kept below only so the code it describes stays readable. Do NOT build to it.

Group conferences WERE allowed in AvaTalk groups, **≤25 participants, via Cloudflare Realtime**
(`worker/src/routes/groupcall.ts` + `app/lib/features/conference/`). Cloudflare still owns
TURN, ICE delivery and signalling everywhere. Cloudflare STUN is primary and Google Public
STUN is the owner-approved discovery-only fallback. The 2-peer CallRoom cap is unchanged —
group conferences never touch it; do NOT raise the cap.

Group/conference CONSULTING still lives in AvaConsult.
Enforcement: group-thread call icons active only when `memberCount <= 25`
(otherwise greyed + a notice popup), the Worker rejects start/join for >25-member
groups, and the Cloudflare Realtime participant cap of 25 is the server-side backstop. All gated
by the `conferenceEnabled` kill switch (`routes/config.ts`). Group chats keep FULL
messaging (text, media, voice notes, stickers, polls, location, contact cards).

The full rulebook is **`Specs/AVATALK-CLOUDFLARE-RULEBOOK.md`** — read it before
building. It governs ALL AvaVerse apps. The two client rules that bite hardest:

1. **Per-account scoping is MANDATORY.** One phone is shared by a parent + each
   child account, so ALL per-user local state (secure storage, prefs, file caches)
   MUST be namespaced with `scopedKey(...)` / `readScoped(...)`
   (`app/lib/core/account_storage.dart`) or a per-account subdir using
   `AccountScope.id`. A raw global key = data leaking across accounts. Only
   device-level values (e.g. the Clerk client token) stay global. When adding ANY
   new store, scope it from the start.

2. **Image/media caching pipeline.** Public images (avatars, posts): upload to
   `/upload/public`, serve via Cloudflare
   `/cdn-cgi/image/format=avif,quality=60,width=N,fit=cover/<path>`, and cache
   on-device (`app/lib/core/avatar_cache.dart`; `Avatar` widget). Private DM media:
   cache the DECRYPTED bytes on-device per account (`MediaService.downloadAndDecrypt`
   → `…/media/<AccountScope.id>/<hash>`). Never re-download on reopen; load local-first.

3. **Universal storage, dedup display & AvaBrain consent.** ONE per-account storage
   pool shared by all apps (AvaLibrary/AvaStorage): 5 GB free, then AvaCoins/GB/month
   (default 20) from the AvaWallet; empty wallet over quota = read-only, NEVER delete.
   Files are content-addressed → ONE real copy; "add to folder" is a shortcut counted
   once; cache on-device + Cloudflare. AvaBrain is ON by default (opt-out): a master
   switch in the main Settings + per-app guardrail toggles (all default ON), each
   registered into the main Settings and checked by the ingestion pipeline; private/
   E2E content is read on-device only regardless of toggle. Full detail in the rulebook.

---

## Type rules — NEVER NEGATIVE TRACKING ON BOLD/DISPLAY (owner decision 2026-08-26)

These are standing rules for the web client (`web/`) **and** the bazaar comps in
`design/live-streaming/`. They exist because the headings kept coming out with
their letters run together, and the cause was never what it looked like.

**The type stack.** Anton for display, **Nunito** for labels and eyebrows,
Instrument Sans for body, Kalam for handwriting. **No typewriter, pixel or
monospace faces** — Silkscreen and Space Mono are both retired; anything still
naming them is stale.

**Tracking.**

- **Never negative on bold or display type.** Display headlines `0.055em`–`0.07em`;
  bold UI labels `0.04em`–`0.08em`; small-caps eyebrows `0.1em`–`0.16em`.
- `word-spacing: 0.2em`–`0.24em` on bold headlines.
- Line height at least `1.02` on display, `1.15` on card titles. Card titles
  often carry a hard `text-shadow`; a sub-1 line-height makes a wrapped title
  collide with the shadow of the line above it.

**Two silent traps, both already paid for:**

1. **Synthesised bold.** Anton and Impact ship ONE weight (400). `h1`–`h6`
   default to bold, so a heading in either asks for a face that does not exist
   and the browser fabricates it by smearing each glyph sideways — strokes
   fatten, sidebearings vanish, letters touch. Letter-spacing cannot repair it;
   the glyphs themselves are distorted. `global.css` carries
   `*, *::before, *::after { font-synthesis: none }` plus `h1..h6 { font-weight: 400 }`
   so any display font added later is protected without anyone remembering.
   Keep that rule.
2. **Inline styles beat media queries.** A `style="display:block"` on an element
   makes every responsive rule for it dead — the comp header's marigold stayed
   visible on a 390px phone and pushed the bar 55px past the viewport. Put
   anything a breakpoint needs to change in CSS, not inline.

**Nunito reads smaller than the pixel face it replaced**, so label sizes were
bumped when swapping: 8→11, 9→11, 10→12, 11→13, 12→14, 13→15 px, and every
Nunito label carries an explicit `font-weight` of 700–900.

---

## Design-system guard — TWO AUTOMATED CHECKS (added 2026-08-05)

The 2026-08-04/05 cleanup folded ~1,600 legacy design-system references, ~1,900
Material icons and ~220 stray radii onto the token files. `tool/check_design_guard.py`
stops the next new screen re-introducing them:

1. **No raw colour literals under `app/lib`** — `Color(0x…)`, `Color.fromARGB/fromRGBO`,
   non-sentinel `Colors.<name>`, bare `0xAARRGGBB` ints and `'#rrggbb'` strings.
   Exempt: the three token files (`core/ui/avatok_dark.dart`, `messenger_theme.dart`,
   `bubble_theme.dart`), comments, and the sentinels `Colors.transparent/white/black`
   (they carry no design decision; tighten with `--strict-material`).
2. **No bare Material `Icons.*`** under `features/**` and `shell/**` — the app is on
   Phosphor: `PhosphorIcons.<name>(PhosphorIconsStyle.regular)`. The regex uses a
   negative lookbehind so `PhosphorIcons.` can't match; a naive `grep 'Icons\.'`
   reports ~1,855 phantom hits and has already misled someone.

```bash
python3 tool/check_design_guard.py --check colours   # check 1
python3 tool/check_design_guard.py --check icons     # check 2
python3 tool/check_design_guard.py --check all       # both
python3 tool/check_design_guard.py --check colours --list   # show every hit
```

Plain `python3`, no pub/npm deps, no Flutter toolchain — safe on this machine.
Wired into **`typecheck.yml`** (runs on every `pull_request` — the trigger that
actually catches drift) and **`verify.yml`** (on demand), both as a `design-guard`
job. Neither builds nor deploys anything, and **no `push:` trigger was added** —
adding one would break `scripts/git_safe_push.py` for everyone.

Both checks are **baselined** against `tool/design_guard_baseline.json` (colours:
218 pre-existing occurrences across 43 files; icons: 0), so they were green on day
one and fail ONLY on violations that are new.

> **When it fails, USE A TOKEN. Do NOT run `--update-baseline`.** The baseline is a
> record of leftover debt, not an allowlist; growing it undoes the cleanup one commit
> at a time. Reach for an `AD.*` token in `core/ui/avatok_dark.dart` (add one there if
> none fits), or `Msg.*`/`MsgColors.*`/`BubbleTheme`. For the rare value a token
> genuinely cannot hold (a native API that wants a literal hex string), use the inline
> `// design-guard: allow — <reason>` hatch; a reason is mandatory.
> `--update-baseline` is only for a large deliberate refactor, e.g. after a big file
> split moves existing violations to new paths.

---

## Ship gate — FOUR RULES AND ONE SCRIPT (added 2026-08-08)

On 2026-08-07/08 four call fixes shipped to production and **three of them did
nothing**, undetected until the owner tested by hand and complained. The
telemetry had been saying so for a day: `call_presence_decision presence=unknown
decision=ring_unknown` and `call_receptionist_trigger
trigger=ring_timeout_no_receipts ring_count=0` on every single call, while the
report said "telemetry is flowing". `tool/check_ship_readiness.py` is that
"nobody stopped it" made into a check.

1. **Verify against the CODE, never against your memory notes.** A saved
   Graphiti/memory note is a HINT ABOUT WHERE TO LOOK. It is never a citation.
   The 2026-08-08 report told the owner about two "known issues" straight out of
   saved notes without opening a file; both had been fixed two days earlier
   ([CALL-QOS-RED-1] and [CALL-SFU-SURVIVE-1], 2026-08-06) and an external audit
   caught it. If you are about to write a sentence about how the system behaves,
   open the file first.
2. **Two phones before the word "shipped".** For anything two-sided — a call, a
   chat, presence, receipts — count DISTINCT persons on the newest `$app_build`
   in PostHog. [CALL-PRESENCE-1] was declared shipped with exactly one person on
   build 10524 and everyone else on 10523 or older; the heartbeat lives in the
   app, so the callee's phone could not send one. It was untestable by
   construction, not merely untested.
3. **Assert the SUCCESS VALUE, not the arrival of an event.** "Events are
   flowing" is not evidence. Write down, BEFORE the build goes out, the exact
   event and the exact property value that means it worked, and then go and read
   that value.
4. **A small group before everyone.** Get the new build onto both sides of a
   real interaction and confirm rule 3 there before the fix is described as
   live.

```bash
python3 tool/check_ship_readiness.py --check all        # flags + manifest
python3 tool/check_ship_readiness.py --check flags      # fake-flag contract
python3 tool/check_ship_readiness.py --check manifest   # who shipped with no
                                                        # success definition
POSTHOG_PERSONAL_API_KEY=phx_... \
  python3 tool/check_ship_readiness.py --check telemetry --window-days 3
```

Plain `python3`, no pip/pub deps, no Flutter toolchain, ~1s. Wired into
**`typecheck.yml`** (every `pull_request`, offline checks only) and
**`verify.yml`** (on demand, including telemetry) as a `ship-gate` job. No
`push:` trigger was added — that would break `scripts/git_safe_push.py`.

Rule 3 is enforced by **`tool/ship_manifest.json`**: one entry per issue id,
declaring `two_sided`, `min_devices_on_build`, the `flags` it depends on, and a
`success` list of assertions. `--check manifest` fails when an issue that
touched `app/` or `worker/` has no entry; `--check telemetry` queries PostHog
and fails when the events are ABSENT **or PRESENT-BUT-CARRYING-A-FAILURE-VALUE**.
With no `POSTHOG_PERSONAL_API_KEY` the telemetry check SKIPS loudly and exits 0
— a missing secret must never fail CI and must never look like a pass.

Both offline checks are **baselined** against `tool/ship_readiness_baseline.json`
(0 fake flags today; 183 issue ids grandfathered from the week before the gate
landed), so they were green on day one and fail only on NEW debt.

> **When it fails, DECLARE THE FLAG or WRITE THE MANIFEST ENTRY. Do NOT run
> `--update-baseline`.** The baseline is a record of debt, not an allowlist;
> grandfathering today's ship is exactly how three fixes reached prod and did
> nothing.

---

## Per-session workflow (READ AND FOLLOW EVERY SESSION)

### Search & context (do this first)

- For any code search or lookup, use **Graphify** (`graphify-avatok-2-flutter`) as your
  first preference — it searches the internal codebase faster and with far fewer tokens
  than reading files directly. Only fall back to direct file reads if Graphify doesn't
  surface what you need.
- For any issue you're about to work on, FIRST check/pull **Graphiti**
  (`group_id="proj_avaflutterapp"`) to understand how the relevant piece was built and
  how it works. Graphiti is the memory/context bank — distinct from Graphify, which is
  for code search.

### Telemetry (PostHog)

- **ALWAYS ASK WHOSE EMAIL FIRST — never assume `hdavy2005@gmail.com`.** There are now
  many testers on different emails, and a bug is often a CONVERSATION BETWEEN TWO PEOPLE
  (a call, a chat thread, an SMS), so the owner may need to give you two or more emails
  to pull both sides. Pulling the wrong person's telemetry means diagnosing the wrong
  device.

  Before touching PostHog, call **AskUserQuestion**:

  > **header:** `Telemetry`
  > **question:** "Whose PostHog telemetry should I pull for this?"
  > **options:** `hdavy2005@gmail.com` · `Two people (I'll give both)` · `Skip telemetry`
  >
  > (the tool always offers "Other" automatically, for a different tester's email)

  - Answer names one person → pull that person's events.
  - Answer is two-sided → get BOTH emails, pull each, and line the two timelines up
    against each other; a call/message bug usually only makes sense from both ends.
  - If the owner already named the tester(s) in his message, skip the widget and use
    those.
  - Skip the widget only when the task provably has no telemetry surface (e.g. a pure
    static code read with no device behaviour) — and say so in one line rather than
    silently skipping.

- If telemetry exists for the named user(s), review it. If it doesn't, build rich
  telemetry data for future retrievals.
- After completing your work, generate rich telemetry and send it to PostHog. It MUST
  include the user's email (and phone number, if available) so error/info/telemetry data
  can be pulled to fix or identify issues — the email is what makes a future pull
  possible, and with many testers it is the ONLY way to tell whose device a problem is
  on. For two-sided features (calls, chats, SMS), tag BOTH parties where the event has
  them, so either email retrieves the interaction. Leave any pre-existing telemetry in
  place; where possible, ADD new telemetry for the new work done.
- Once a task/fix is finished, **update Graphiti** with what you did
  (`add_memory(..., group_id="proj_avaflutterapp")`).

### Tooling

- Use **Desktop Commander** for all file and shell operations.
- **🚫 THERE IS NO LOCAL BUILD TOOLCHAIN — AND IT IS NOT COMING BACK (owner decision
  2026-09-10). DO NOT INSTALL ONE.**

  The owner deliberately deleted the entire local phone-app stack on 2026-09-10 because
  the Mac kept running out of disk. Removed: `~/.gradle` (28 GB of Gradle caches),
  `~/Library/Android` (the Android SDK, `adb`, the emulator binary and every system
  image), `~/.android`, `~/development/flutter` (the Flutter/Dart SDK), `~/.pub-cache`,
  `app/build`, and **Android Studio itself**. The `.zshrc` exports for `ANDROID_HOME`,
  `ANDROID_NDK*`, the Flutter `bin` on `PATH` and the platform-tools/emulator `PATH`
  entries are commented out; `JAVA_HOME` now points at Homebrew `openjdk@17`, which is
  still installed and is used by things other than Android. That freed ~44 GB.

  **This is a preference, not an accident. Do not "helpfully" reinstall Flutter, the
  Android SDK, Android Studio, an AVD, Xcode or CocoaPods, and do not tell the owner
  to.** If you think a task needs a local build, it does not — use CI.

  | Command | Status |
  |---|---|
  | `flutter analyze` / `flutter build` / `flutter run` | ❌ gone — `flutter: command not found` |
  | `adb` / `scripts/push_apk.sh` / **"ship local"** | ❌ gone — no `adb`, no SDK |
  | emulator | ❌ gone — no binary, no AVD, no system image |
  | `gh workflow run android.yml` / **"ship it"** | ✅ **unchanged — this is the only way to build** |
  | `python3 tool/check_design_guard.py`, `tool/check_ship_readiness.py` | ✅ unchanged (plain python3, no toolchain) |
  | `worker/` + `web/` npm/tsc/wrangler work | ✅ unchanged |

  **The compile net is now CI, not `flutter analyze`.** A Dart type error will be found
  by `verify.yml` / `typecheck.yml` on a 40–80 minute round trip, so read your own diff
  carefully before pushing and lean on Graphify to check call sites and signatures. Be
  especially careful with the traps this file already documents — `PhosphorIcons.coins`
  vs a blind coins→tokens rename is exactly the class of error that used to be caught
  locally in seconds and now costs an hour.

  **Previewing on the phone is now: `ship it` → Closed Alpha → the owner hits Update in
  the app.** There is no side-load path any more.

  (The 2026-08-27 "the toolchain is back, run `flutter doctor` and look" note that used
  to sit here is dead. `flutter doctor` will now say `command not found`, and that is
  the expected, intended answer — not something to fix.)

- **REPO LOCATION — `/Users/davy/Documents/websites/avaTOK-2-Flutter` (verified 2026-08-02).**
  This is a REAL directory holding the real `.git`, not a symlink. There is no
  `~/dev` copy: the 2026-07-31 move to `/Users/davy/dev/avaTOK-2-Flutter` was
  reverted, and what's left there is an empty `app/build` shell with no `.git`.
  **Do not `cd` into `~/dev/avaTOK-2-Flutter` and do not "restore" the symlink** —
  earlier revisions of this file described that layout and it is no longer true.

  **This path is NOT iCloud-synced, so it is safe.** Desktop & Documents sync is
  OFF (`defaults read com.apple.finder FXICloudDriveDocuments` → `0`), and
  `~/Documents` is a plain local folder with a different inode from the real
  iCloud Documents at `~/Library/Mobile Documents/com~apple~CloudDocs/Documents`.
  **If that sync setting is ever turned back ON, this repo lands in iCloud and
  must be moved out immediately** — iCloud silently corrupted the old `.git` over
  ~2 months: conflict duplicates (`HEAD 2`, `config 2`, `objects 2`, `index 2`…
  `index 8`) and finally an unreadable loose object that made `git status`,
  `diff`, `fetch` and `fsck` all die with **SIGBUS**. Never keep a git repo under
  an iCloud-synced path. The old corrupted copy survives only as
  `…/CloudDocs/Documents/websites/avaTOK-2-Flutter-recover.nosync`.

### Git protocol (MANDATORY — this repo is shared by multiple agents)

- **NO AUTO-BUILD — builds are MANUAL ONLY (owner decision 2026-07-04, PERMANENT).**
  Every build workflow (`android.yml`, `avaconsult.yml`, `macos.yml`, `web-deploy.yml`)
  has its `push:` trigger DISABLED and runs on `workflow_dispatch` only. A `git push`
  therefore NO LONGER triggers any build. The owner starts builds by hand from the
  Actions tab (Run workflow) or `gh workflow run <file>`. **NEVER trigger a build**
  (no `gh workflow run`, no `workflow_dispatch` via API, and never re-enable a `push:`
  trigger) unless the owner EXPLICITLY asks. Do NOT re-add push triggers to the
  workflows on your own initiative.
- **Pushing commits is allowed** (it's safe — no build fires), but it MUST go through
  the push wrapper, which enforces that you only publish YOUR OWN commits:

  ```bash
  python3 scripts/git_safe_push.py AVA-AUTH-401 AVA-AUTH-OTP     # the issue ids you own
  python3 scripts/git_safe_push.py AVA-AUTH-401 --dry-run        # preview, touches nothing
  ```

  **Never run `git push` (or `ALLOW_PUSH=1 git push`) directly.** The wrapper sets
  `ALLOW_PUSH=1` for you — it IS the deliberate push path the pre-push hook asks for.
  Do NOT use `--no-verify`, do NOT force-push a shared branch, and do NOT remove or
  disable the hook.

- **Why the wrapper exists (the cross-agent push-sweeping bug).** `git_safe_commit.py`
  keeps other agents' FILES out of your commit; `git_safe_push.py` keeps other agents'
  COMMITS out of your push. Git pushes a BRANCH, not a set of commits — so if another
  agent has an unpushed commit sitting BELOW yours on `main`, it is an ANCESTOR and
  goes to origin with yours whether anyone decided to or not. That is exactly what
  happened on 2026-07-14: an agent pushed `[AVADIAL-GROUPS-1]` and silently carried two
  unrelated `[AVA-AUTH-*]` commits along. No tool can push your commit without its
  ancestors, so the wrapper does the only correct thing — it **refuses** and tells you
  whose work is in the way, instead of publishing it for them.

  Ownership is read from the `[ISSUE-ID]` prefix (every agent commits as the same git
  user, so the author field cannot tell agents apart) — which is another reason the
  one-issue-per-commit rule below is mandatory. A commit with no `[ISSUE]` prefix is
  unattributable and also blocks the push.

  If you're blocked, the fix is to let the owning agent push their own work first, then
  re-run. `--allow-foreign` bypasses the check and is for the OWNER's deliberate merge
  push only — an agent should never reach for it to get unstuck.

  The wrapper also refuses to push if any workflow has an **active `push:` trigger**, so
  a re-enabled trigger can't silently ship a build.
- **One issue per commit.** Each commit fixes a single issue, and the message must start
  with the issue ID, e.g. `[ISSUE-123] Fix null check in payout handler`. This keeps the
  history bisectable if the final merge build fails.
- **All git writes go through the mandated wrapper — never run `git add` or `git commit`
  directly.** The wrapper serializes every agent's commits through one shared advisory
  lock and works on both macOS and Linux. **ALWAYS pass the explicit paths you changed**
  so your commit contains ONLY your files:

  ```bash
  python3 scripts/git_safe_commit.py "[ISSUE-123] short description" path/one path/two
  ```

  - **Why paths are required in this shared tree.** The lock serializes commits but does
    NOT isolate the working tree: the bare `git add -A` form stages EVERYTHING currently
    changed, so whichever agent commits first sweeps every other agent's uncommitted files
    into ITS commit and mislabels history (a GenUI change landing inside an `[AVA-VOICE-…]`
    commit, etc.). Passing paths makes the wrapper run `git add -- <paths>` then
    `git commit -- <paths>`, so concurrent agents' changes can never ride along.
  - The no-paths form (`… "msg"` with no paths → legacy `git add -A`) still works for
    backward compatibility, but do NOT use it while other agents may be active.

- **Do NOT use the `flock` command.** It is not installed on macOS (where commits run via
  Desktop Commander), so it fails silently and breaks serialization. `scripts/git_safe_commit.py`
  (which uses `fcntl.flock` on `/tmp/repo.gitlock`) is the ONLY approved method — every
  agent must use it so the lock is shared and consistent.
- **Stale `.git/index.lock` is handled by the wrapper.** While holding the advisory lock,
  it removes an orphaned `index.lock` only after confirming no `git` process is running;
  if a git process is live, it waits. Never delete `index.lock` by hand, and do NOT rely
  on a plain wait-and-retry loop (a 0-byte orphaned lock never releases on its own).
- **Run all git operations on the host filesystem via Desktop Commander.** Sandbox mounts
  cannot write to `.git`, and the shared lock only means anything if every agent commits
  on the same host using the same `/tmp/repo.gitlock`.
