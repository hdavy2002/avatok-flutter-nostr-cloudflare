import {gcalExportSweep} from "./cal/gcal";
// AvaTok API Worker — route-based dispatch (one Worker, not one-per-app).
//
// Single HARDENED contract: every mutation requires a NIP-98 signature (+ Clerk
// JWT when CLERK_JWKS_URL is set). The caller's identity comes from the
// signature, never the body. Public reads (resolve/search/communities/ice) are
// unauthenticated and cached. The old compat layer (identity-in-body, no auth)
// has been removed — the Flutter app signs NIP-98 and calls /api/*.
import type { Env } from "./types";
import { json, preflight } from "./util";
import { requireUser, isFail } from "./authz";
import * as api from "./routes/api";
import { uploadPublic, uploadPrivate, mediaCommit, mediaRedirect, getLibrary, getLibraryTree, libraryFolders, libraryMove, libraryCopy, libraryDelete, libraryRecord, libraryFolderMove, libraryFolderCopy, getStorage, getIce, privateMediaRead, sweepAvaReadableCopies } from "./routes/media";
import { getStorageSummary } from "./storage";
import { streamWebhook } from "./routes/stream";
import { streamVideoToken, streamVideoPrepare, streamVideoWebhook, streamCallPlace, streamCallCancel } from "./routes/stream_video_calls";
import {
  commercialLiveJoin,
  commercialConsultPrejoin,
  commercialConsultJoin,
  commercialLivePrepareHost,
  commercialLiveGoLive,
  commercialLiveEnd,
  commercialConsultEnd,
  commercialConsultState,
  commercialConsultExtensionQuote,
  commercialConsultExtensionConfirm,
  commercialLiveState,
  commercialReceipt,
  commercialRefundReceipt,
  commercialSessionsMine,
  reconcileCommercialSessions,
} from "./routes/commercial_stream_sessions";
import { commercialCheckout, commercialHold, resendCommercialConfirmation } from "./routes/commercial_checkout";
import { recoverEmailOutbox } from "./lib/email_outbox";
import { commercialLifecycle, runCommercialOrphanNoShowSweep } from "./routes/commercial_lifecycle";
import { commercialRoutePattern } from "./lib/commercial_ids";
import { commercialSessionAttachmentUpload } from "./routes/commercial_session_attachment";
import { commercialDiagnostics, scanCommercialHealth } from "./routes/commercial_diagnostics";
// [STREAM-CALLTYPES-1] Provision the provider call types the commercial lane mints.
import { ensureStreamCallTypes } from "./routes/admin_stream_calltypes";
import { runCommercialSettlements, runCommercialHostNoShowSweep } from "./commercial_settlement";
import { refreshStaleCreatorStats } from "./lib/creator_stats"; // [LIST-STATS-1]
import { endDueConsultSessions, backfillCheckedInConsultSessions } from "./lib/commercial_session_clock"; // [SESSION-CLOCK-0]
import { sweepExpiredLiveGrace } from "./lib/live_grace"; // [WAITROOM-4 / R3]
import { messengerCallAuthorize, messengerCallPricing, messengerCallReceipt, messengerCallBillingStatus, cancelMessengerCallAuthorization } from "./routes/messenger_call_billing";
import { brain } from "./routes/brain";
import { brainDomains } from "./routes/brain_domains";
import { brainMediaPrepare, brainMediaComplete, brainMediaStatus, brainMediaDelete } from "./routes/brain_media"; // [AVABRAIN-MEDIA-1]
import { brainExport, brainMemoryList, brainMemoryConfirm, brainMemoryCorrect, brainMemoryDelete, brainMemoryExport } from "./routes/brain_export"; // [AVABRAIN-EXPORT-1]
import { deleteAccount, cancelDeletion, deletionStatus } from "./routes/account";
import { adminDeleteUser } from "./routes/admin_delete_user"; // [ADMIN-DELETE-USER-1] admin immediate erasure of another user
import { adminListings, adminListingAction, adminListingDetail, adminEditListing } from "./routes/admin_listings";
import { listingReview } from "./routes/listing_review";
import { webAccountBootstrap, webAccountAppOnboarded } from "./routes/web_account";
import { phoneOtpSend, phoneOtpVerify, phoneOtpStatus } from "./routes/phone_otp"; // [WEB-PHONE-OTP-1]
import { adminPurgeListing } from "./routes/admin_listing_purge";
// [AVADIAL-CALL-INTEL-1] Call-intelligence ingest. The ONLY place raw E.164 and the
// HMAC secret meet — the device never holds the key. See routes/telemetry_calls.ts.
import { ingestCallTelemetry } from "./routes/telemetry_calls";
import { presenceBeat } from "./routes/presence"; // [CALL-PRESENCE-1] device heartbeat
// [AVA-IDGATE-1] idSession / idResult / idPhoneConfirm are NO LONGER ROUTED — they
// minted verification without a Didit check. See LEGACY_GONE in the router.
import { idStatus, idEmailStart, idEmailVerify, idPasswordStart, idPasswordSet } from "./routes/id";
import { walletTopup, walletTopupIntent, walletTopupPlayVerify, runPlayVoidedPurchaseSweep, stripeWebhook, walletSpend, walletBalance, walletTransactions, walletEarnings, walletLive, walletLedger, walletLedgerDetail, walletReceiptResend } from "./routes/wallet";
import { walletStatement, walletStatementExport, walletSummary, walletTopupQuote, walletActivity } from "./routes/wallet_statement";
import { adminLedger, adminRefund, adminAdjust, adminAccount, adminRecon, adminEscrowHold, adminEscrowRelease, adminTaxExport, adminFailedSettlements, adminRetrySettlement, requireAdmin } from "./routes/admin_money";
import { adminCommercialClaims, adminResolveCommercialClaim } from "./routes/commercial_admin_claims";
import { cashfreeCreateOrder, cashfreeWebhook, cashfreeStatus } from "./routes/cashfree";
import { payMethods, payCreateOrder, payWebhook, payStatus } from "./routes/pay"; // [PAY-RAIL-1]
import { dynwAcceptance } from "./routes/dynw_test"; // [DYNW-CORE-1] Phase 0 acceptance battery (admin-only, dark behind dynamicWorkersEnabled)
import { receptRules } from "./routes/recept_rules"; // [DYNW-RECEPT-RULES-1] owner receptionist rule scripts
import { welcomeBackfill } from "./routes/welcome_bonus"; // [WELCOME-100-1]
import { tokenHardResetBackfill } from "./routes/token_reset"; // [TOKENS-100-GRANT-1] one-time hard reset to 100
import { liveStart, liveStop, liveJoin, liveRoom, liveDonate, liveMod, liveState } from "./routes/live";
import { consultJoin, consultRoom, consultSfu, consultComplete, consultCancel, consultExtend, consultProbe, consultProbeBlob } from "./routes/consult";
import { runMoney, moneyDlq, type MoneyMsg } from "./money_engine";
import { setTestClock } from "./clock";
import { stripeIdentityWebhook, agreementStatus, agreementDoc, agreementAccept } from "./routes/kyc";
// [AVA-IDGATE-1] The V2/V3 HTTP entrypoints are no longer routed (LEGACY_GONE).
// The queue consumers stay imported: in-flight messages must still drain cleanly.
// Nothing enqueues new ones now that the routes are closed.
import { runLivenessChecks } from "./routes/liveness";
import { runLivenessV3Checks } from "./routes/liveness_v3";
import { diditSession, diditResult, diditDone, diditWebhook, connectorsDone, livenessConsent } from "./routes/liveness_didit";
import * as hooks from "./hooks"; // [AVA-IDGATE-1] legacy-route telemetry
import { recoverAiMediaJobs } from "./queues/ai_media_recovery";

// [AVA-IDGATE-1] Routes closed 2026-07-10. Each previously called setVerifiedCache(),
// so each could mark a user "verified" without a Didit liveness check ever running —
// the flag the entire deterrence model rests on. 410 + telemetry, never silently 404.
const LEGACY_GONE = new Set<string>([
  "/api/id/session",            // id.ts — Rekognition Face Liveness session
  "/api/id/result",             // id.ts — auto-verified at >=90% confidence
  "/api/id/phone/confirm",      // id.ts — phone OTP; all phone verification removed
  "/api/id/liveness/start",     // liveness.ts — Workers AI provider
  "/api/id/liveness/upload",
  "/api/id/liveness/verify",
  "/api/id/liveness/result",
  "/api/liveness/v3/session",   // liveness_v3.ts — policy engine
  "/api/liveness/v3/upload",
  "/api/liveness/v3/verify",
  "/api/liveness/v3/result",
]);
import { guestCreate, guestHandleCheck, guestUpgrade, getIdentityLevel } from "./routes/ladder";
import { createSlot, listSlots, cancelSlot, bookSlot, cancelBooking, listEvents, listBlocks, getRules, putRules, getTime } from "./routes/calendar";
import { getAvailabilitySchedule, putAvailabilitySchedule, getListingAvailability, previewAvailabilityConflicts } from "./routes/calendar_availability";
import { listBookings, getPolicies, putPolicies, proposeReschedule, respondReschedule, listReschedules, joinInfo } from "./routes/booking";
import { joinLinkSession } from "./routes/join_link";
import { routeAgentLive, runAgentLiveSweeps } from "./routes/agent_live/index";
import { gcalConnect, gcalCallback, gcalStatus, gcalDisconnect, gcalWebhook, gcalCalendars, gcalSaveCalendars } from "./cal/gcal";
import { payoutSetup, payoutAccounts, payoutRequest, payoutStatus, wiseWebhook } from "./routes/payout";
import { upiAccount, upiAccountGet, upiPayoutQuote, upiPayoutRequest, upiPayoutRequests, adminUpiPayouts, adminUpiAccountVerify, adminUpiApprove, adminUpiReject, adminUpiPaid, adminUpiReconcile } from "./routes/upi_payout";
import { olxCreate, olxBrowse, olxGet, olxUpdate, olxDelete, olxUploadFile, olxBuy, olxRefund, olxDownloads, olxDownloadFile } from "./routes/olx";
import { listPersonas, upsertPersona, converse, getInbox, getInboxItem, approveInbox, agentTask } from "./routes/agent";
import { agentTts, agentAudio } from "./routes/agent_tts";
import { listNotifications, unreadCount, markRead, clearNotifications } from "./routes/notifications";
import { wsInbox, wsParty, sendMsg, syncMsg, receiptMsg, msgReceiptBatch, msgSeenState, readMsg, hideMsg, reactMsg, stateMsg, pollVote, pollState, convList, convCreate, convAdopt, convMembers, convAddMembers, convRemoveMember, convSetRole, convSetAvatar, convLeave, convDelete, convInvites, convInviteRespond, callLogAppend, callLogDelete, callLogClear, convAvaGroupStateGet, convAvaGroupStatePut, convAvaMemberPrefsGet, convAvaMemberPrefsPut, reactionsState, convAvaDmStateGet, convAvaDmStatePut } from "./routes/messaging"; // [AVA-GROUP-COMPANION-1]: group-Ava state + member-prefs handlers; [AVA-REACT-1]: reactionsState; [AVA-TOGGLE-DM-1]: 1:1 Ava toggle
import { archiveList, archivePage } from "./routes/archive";
import { getAutoResponder, putAutoResponder } from "./routes/auto_responder"; // STREAM F — away auto-responder settings
import { getAvaVoiceStyle, putAvaVoiceStyle } from "./routes/ava_voice_style"; // [AVA-VOICE-STYLE-1] WS-14 — how Ava speaks
import { getConfig, putConfig, readConfig } from "./routes/config";
import { createConversation, listConversations, getParticipants } from "./routes/conversations2";
import { getPlans } from "./routes/plans";
import * as num from "./routes/number";
import { virtualLinesRoute } from "./routes/virtual_lines";
import { avacallsResolve } from "./routes/avacalls";
import * as keybk from "./routes/keybackup";
import * as cbook from "./routes/contacts_backup";
import * as team from "./routes/team";
import { subscribeCheckout, subscribeAndroidVerify, subscribeCancel } from "./routes/subscribe";
import { referralClaim, referralSummary } from "./routes/referral";
import { inviteEmail } from "./routes/invite";
// [WP2] Paid-call escrow/settlement routes (plan §3B/§11/§15.3)
import { getPaidCallOfferRoute, getPaidCallSettingsRoute, putPaidCallSettingsRoute, preparePaidCallRoute, confirmPaidCallRoute, cancelPaidCallRoute } from "./routes/call_billing_routes";
// [WP3] Agent Profiles + service numbers (plan §4/§7/§8b/§12.5/§12.8/§12.10).
import { getAgentSettings, putAgentSettings, listAgentServices, createAgentService, updateAgentService, deleteAgentService, listAgentCalls, getAgentCallTranscript } from "./routes/agent_profiles";
// [WP3] Voicemail bot session start (plan §3 step 4 / §7 item 5 / §15.5).
import { voicemailStart, voicemailRecording } from "./routes/voicemail_routes";
// [CALLREC-SERVER-1] On-demand call recording — upload/meta/delete/playback.
// All four 403 while `callRecordingEnabled` is false (it ships false).
import {
  callRecFinalize, callRecMeta, callRecDelete, callRecPlayback,
  // [CALLREC-UPLOAD-1] the resumable lane for long recordings (spec §5.1).
  callRecUploadBegin, callRecUploadPart, callRecUploadComplete, callRecUploadAbort,
} from "./routes/callrec";
// [ADDCALL-1-SRV] Add-to-call — the invisible ad-hoc conversation an escalating
// 1:1 needs so the conference stack will admit its participants
// (Specs/SPEC-ADD-TO-CALL-2026-08-06.md §2). Dark behind addToCallEnabled.
import { adhocRoomCreate, adhocRoomAdd } from "./routes/adhoc_room";
import { pstnRoute } from "./routes/pstn";
// [AVA-CAMP-B2-WIRE] Outbound AI calling campaigns — PSTN bridge + CRUD API
// (dark behind campaignDialerEnabled; Specs/OUTBOUND-AI-CALLING-CAMPAIGNS.md).
import { campaignPstnRoute } from "./routes/campaign_pstn";
import { campaignsRoute } from "./routes/campaigns";
import { campaignKbRoute } from "./routes/campaign_kb";
// [AVA-CAMP-Q-VOICES] AI-voice catalog + preview.
import { campaignVoicesRoute } from "./routes/campaign_voices";
// [AVA-CAMP-D-*] Campaign contacts ingest, DID provisioning, analytics RPC.
import { campaignContactsRoute, insertCampaignContacts, type CampaignContactsChunkMsg } from "./routes/campaign_contacts_route";
import { campaignDidsRoute } from "./routes/campaign_dids_route";
import { campaignAnalyticsRoute } from "./routes/campaign_analytics";
// [TEL-TIERS-1] Telephony subscription tiers (Teler/Vobiz resale, Phase 4).
import { telephonySubscribe, telephonyAddon, telephonyCancel, telephonyStatus } from "./routes/telephony_tiers";
// [AVA-PSTN-AGENT-1] Vobiz bidirectional media-stream WS → VobizAgentRoom DO
// (live Gemini agent on cell/DID calls; dark behind pstnAgentEnabled).
import { pstnAgentStream } from "./routes/pstn_agent";
// [AVA-VM-SELFREC-1] Vobiz bidirectional media-stream WS → VoicemailStreamRoom DO
// (self-recorded voicemail replacing Vobiz's billed <Record>; dark behind
// pstnVoicemailSelfRecord).
import { pstnVoicemailStream } from "./routes/pstn_voicemail_stream";
// [WP4] Ava AI Voice Agent — Grok realtime session start (plan §4/§8/§15.1/§15.3).
import { agentCallStart } from "./routes/agent_voice_routes";
// [WP4] RAG document pipeline — Grok Collections (plan §5/§9).
import { uploadAgentDoc, listAgentDocs, deleteAgentDoc } from "./routes/agent_docs";
import { featureCostsRoute } from "./feature_pricing";
import { googleAuth } from "./routes/google_auth";
import { conferenceStart, conferenceJoin, conferenceStatus, conferenceEnd, conferenceBeat } from "./routes/conference";
import { groupCallJoin, groupCallRejoin, groupCallPublish, groupCallPull, groupCallRenegotiate, groupCallClose, groupCallStatus, groupCallInvite } from "./routes/groupcall";
import { callSfuJoin, callSfuPrepare, callSfuPublish, callSfuPeer, callSfuPull, callSfuRenegotiate, callSfuHeartbeat, callSfuClose } from "./routes/call_sfu";
import { callRtkJoin } from "./routes/call_rtk";
import { conferenceRoomRoute } from "./routes/conference_room";
import { translateStart, translateBeat, translateStop, translateToken, translateQuote } from "./routes/translate";
import { callTranslationStart, callTranslationActivate, callTranslationRenew, callTranslationStop, callTranslationToken, callTranslationLanguage } from "./routes/call_translation";
import { sttTranscribe } from "./routes/stt";
import {
  avavoiceVoices, avavoiceMarketplace, avavoiceMine, avavoiceCreateAgent, avavoiceGetAgent,
  avavoiceUpdateAgent, avavoicePublish, avavoiceDeleteAgent, avavoiceUploadFile, avavoiceDeleteFile,
  avavoiceAvailability, avavoiceStats, avavoiceBook, avavoiceMyBookings, avavoiceCancelBooking,
  avavoiceCallNow, avavoiceSessionStart, avavoiceHeartbeat, avavoiceSessionStop,
} from "./routes/avavoice";
import {
  receptionistGetSettings, receptionistPutSettings, receptionistConfigFor,
  receptionistStart, receptionistFinish, receptionistKbUpload, receptionistKbClear,
  receptionistRecording,
} from "./routes/receptionist";
import { receptionistAnalytics } from "./routes/recept_analytics"; // [RECEPT-STATS-1]
import {
  avavisionTemplates, avavisionVoices, avavisionMarketplace, avavisionMine, avavisionCreateAgent,
  avavisionGetAgent, avavisionUpdateAgent, avavisionPublish, avavisionDeleteAgent, avavisionUploadFile,
  avavisionDeleteFile, avavisionAvailability, avavisionStats, avavisionBook, avavisionMyBookings,
  avavisionCancelBooking, avavisionCallNow, avavisionSessionStart, avavisionSessionToken,
  avavisionHeartbeat, avavisionSessionStop, avavisionSnapshot,
} from "./routes/avavision";
import {
  adminOverview, adminLive, adminAgents, adminHealth, adminAnalytics, adminAuditLog,
  adminUserSearch, adminAlerts, adminAlertAck, adminAlertResolve, adminAlertEvaluate,
  adminAlertRules, adminAlertRuleMutate, adminRoles, adminRoleSet,
} from "./routes/admin_dashboard";
import { marketplaceStub } from "./routes/stubs";
import { verseSummary, verseAnnounce, verseStatement } from "./routes/verse";
// [LIST-CONTENT-2] replaces routes/listings.ts's old createReview and routes/verse.ts's
// old reviewReply — see worker/src/routes/reviews.ts header for the migration context.
import { createReview, replyReview, helpfulReview, listReviews, reviewEligibility } from "./routes/reviews";
// [REVIEW-MOD-1] Reviews are held for admin approval before they are published.
import { adminReviews, adminReviewAction } from "./routes/admin_reviews";
// [LIST-ASK-1] "Ask the host" — see worker/src/routes/listing_questions.ts header.
import { askQuestion, answerQuestion, listMyQuestions, listCreatorQuestions, promoteToFaq } from "./routes/listing_questions";
import {
  createListing, updateListing, publishListing, submitListingForApproval, listingBlockersRoute, setListingStatus, duplicateListing, repeatListing, cancelListing,
  myListings, listingPromotions, deletePromotion, exploreBrowse, exploreLiveNow, exploreSearch,
  exploreCategories, getListing, getListingBySlug, getCreator, updateMyChannel, followCreator, unfollowCreator,
  blockCreator, report, bookListing,
  listingFeeQuote, reconcileListingLifecycleProjections, reconcileListingPublicationEffects, expireEndedEventListings,
} from "./routes/listings";
import { listingStats, creatorStats } from "./routes/insights";
import {
  marketplaceAiAssist, marketplaceNegotiate, marketplaceNegotiateState,
  marketplaceSearch, marketplacePrecheck, marketplaceAudio, marketplaceDealDecision,
} from "./routes/marketplace";
import { marketplaceCategories, proposedCategories } from "./routes/categories";
import { sitemapListings, sitemapCreators } from "./routes/sitemap"; // [WEB-SEO-3]
import { composeSession, composeTurn, composePublish } from "./routes/compose";
import {
  affiliateRegister, affiliateMe, affiliateListings, affiliateLinkCreate, affiliateLinks,
  affiliateLinkStats, affiliateLinkSubscribers, affiliateLinkPause, affiliateClick,
  affiliateBind, adminAffiliates, adminAffiliateSuspend, runAffiliateQualification,
} from "./routes/affiliate";
import { affiliateAssetsGenerate, affiliateAssetsList } from "./routes/affiliate_assets";
// --- Ava in-chat AI (Phase 0 — Foundations) ---
// These handler modules + DO classes are created by LATER phases (see master-plan
// §4: P2 gemini, P3 thread, P5 tools, P8 guardian, P9 image, P10 backup). The
// routes are registered now so feature phases just drop in the named handler.
// CONSEQUENCE: the worker will NOT typecheck/build until those files exist — this
// is expected and accepted for Phase 0 (Phase 11 reconciles). See
// Specs/ava-build/INTEGRATION-NOTES.md.
import { avaGemini, avaGeminiStream } from "./routes/ava_gemini";        // P2
import { avaLiveToken, avaLiveHeartbeat, avaLiveClose } from "./routes/ava_live"; // fast online voice + [AVABRAIN-VOICE-BILL-1] lease lifecycle
import { avaRagIngest, avaRagStore, avaRagSearch, avaRagBackfill, avaThreadSearch } from "./routes/ava_rag"; // RAG (Cloudflare AI Search)
import { avaAppsCatalog, avaAppsConnect, avaAppsDisconnect, avaAppsStatus, avaAppsRun, avaGenuiAction } from "./routes/ava_apps"; // AvaApps (Composio)
import { avaGenuiThumb } from "./routes/genui_thumb"; // GenUI preview-thumbnail proxy
import { avaEmailList, avaEmailGet, avaEmailSpam, avaEmailTrash, avaEmailReply } from "./routes/ava_email"; // in-chat email (Composio Gmail)
import { driveStatus, driveListRoute, driveUploadRoute, driveBackupEnsureRoute, driveBackupUploadRoute, driveBackupDownloadRoute, driveBackupListRoute } from "./routes/ava_drive"; // AvaTOK Drive storage
import { avaChatHistorySave, avaChatHistoryGet, avaChatHistoryMeta } from "./routes/ava_chat_history"; // AvaChat history (D1)
import { avaThreadTurn } from "./routes/ava_thread";    // P3
import { avaGuardianScan } from "./routes/ava_guardian"; // P8
import { moderateText } from "./routes/moderate";        // save-time content validation (Nemotron)
import { avaImage } from "./routes/ava_image";          // P9
import { avaDocSummarize, avaDocTranslate, avaDocTranslateFile, avaChatToggle } from "./routes/ava_copilot"; // Copilot A+B (doc actions + per-chat toggle)
import {
  aiMediaJobsCreate, aiMediaJobsGet, aiMediaJobsCancel, aiMediaJobsList,
  aiMediaJobSongShare, aiMediaSongSharePage, aiMediaSongShareAsset, aiMediaJobVideoShare, aiMediaVideoSharePage, aiMediaVideoShareAsset,
} from "./routes/ai_media_jobs"; // [AVA-MEDIA-JOB-1] durable AI media job state machine
import { runAiMediaJobMessage, type AiMediaJobQueueMsg } from "./queues/ai_media"; // [AVA-MEDIA-JOB-1] self-consumed, same pattern as money-settlements/liveness-verify below
import { avaTriggersGet, avaLedgerGet, avaMomentOutcome } from "./routes/ava_odl_routes"; // Copilot C+D (ODL trigger sync D31 + cost ledger D25 + learning loop)
import { avaGroupModeGet, avaGroupModePost, avaGroupPolicyGet, avaGroupDraftApprove, avaGroupDraftReject, avaGroupDraftsGet } from "./routes/ava_group"; // [AVABRAIN-COMPANION-2]/[AVABRAIN-COMPANION-UI-1] group Companion mode + effective policy + draft approval + pending-draft list
import { backupGet, backupPut, backupStatus } from "./routes/backup"; // P10
import { ringtone } from "./routes/ringtone"; // AI ringback tones + busy tone
import { spamReport, spamLookup, spamBloom, spamRescore } from "./routes/spam"; // AvaDial spam shield (Phase 2a, dark behind spamShield)
import { missedCallToken, missedCallLookup } from "./routes/missedcall"; // [AVA-MISSEDCALL-1] device-token lane (dark behind missedCallOverlay)
import { homeCards } from "./routes/homecards"; // Home dashboard card aggregates (Phase 3, dark behind shellV2)
import { delegateHandler } from "./routes/ava_delegate"; // P7 (Phase 11 route wiring)
// --- AI Messenger Batch 2026-07-03 (Streams A/B/C/E/F/G/I) ---
import { marketplaceAgentSettingsGet, marketplaceAgentSettingsPut } from "./routes/agent_settings"; // STREAM A
import { convAccept, convBlock, safetyReport, convAcceptState } from "./routes/safety";              // STREAM B
import { unfurl } from "./routes/unfurl";                                                            // STREAM C
import { gifSearch, gifTrending } from "./routes/gif";                                               // STREAM E
import { aiCatchup, aiSmartReplies, aiTranslate, aiGroupTranslate, safetyScore, aiBio, aiGender } from "./routes/ai_chat"; // STREAM G + bio writer + gender infer
import { forwardMsg } from "./routes/messaging";                                                     // STREAM I
import { addFavorite, removeFavorite, listFavorites, favoriteState } from "./routes/listings";         // STREAM K
import { listSlots as listListingSlots, createSlot as createListingSlot, patchSlot as patchListingSlot, deleteSlot as deleteListingSlot } from "./routes/listing_slots"; // [LIST-SLOTS-1]
import { listingCopyReview } from "./routes/listing_copy_review";                                    // [CARD-AI-REVIEW-1]

export { CallRoom } from "./do/call_room";
export { MeshRoom } from "./do/mesh_room";
export { GroupCallRoom } from "./do/group_call_room"; // CF Realtime SFU group AUDIO (≤32)
export { ConferenceRoomDO } from "./do/conference_room";
export { InboxDO } from "./do/inbox";
// Dormant call-state control-plane authority (Phase A plumbing only — no
// route reads/writes it yet). Specs/CALL-CONTROL-PLANE-UNIFIED-PLAN.md.
export { CallStateAuthorityDO } from "./do/call_state_authority";
export { SentinelDO } from "./sentinel/do"; // Guardian Sentinel S1 hot-cache DO (DARK behind sentinelEnabled)
export { PartyDO } from "./do/party"; // PartyKit realtime layer (ephemeral; replaces Ably)
export { UserBrain } from "./do/user_brain";
export { WalletDO } from "./do/wallet";
export { MessengerCallBillingDO } from "./do/messenger_call_billing";
export { StreamSessionDO } from "./do/stream_session";
export { AgentDO } from "./do/agent";
export { ConversationDO } from "./do/conversation";
// Ava in-chat AI DOs (Phase 0 binding contract; classes implemented later —
// AvaAgentDO by P3, BackupDO by P10). These exports are required by the
// wrangler.toml DO bindings + v6 migration; the files arrive with their phases.
export { AvaAgentDO } from "./do/ava_agent"; // P3
export { BackupDO } from "./do/backup";      // P10
export { ReceptionRoom } from "./do/reception_room"; // Ava Receptionist call bridge (Gemini engine)
export { ReceptionRoomCf } from "./do/reception_room_cf"; // Ava Receptionist — Cloudflare-native engine (separate)
export { VoicemailRoom } from "./do/voicemail_room"; // [WP3] carrier-style voicemail bot (dark behind voicemailBot)
export { AgentVoiceRoom } from "./do/agent_voice_room"; // [WP4] Ava AI Voice Agent — Grok realtime bridge (dark behind voiceAgent)
export { VobizAgentRoom } from "./do/vobiz_agent_room"; // [AVA-PSTN-AGENT-1] live Gemini agent on Vobiz DID calls (dark behind pstnAgentEnabled)
export { VoicemailStreamRoom } from "./do/voicemail_stream_room"; // [AVA-VM-SELFREC-1] self-recorded PSTN voicemail over <Stream> (dark behind pstnVoicemailSelfRecord)
export { DialerGateDO } from "./do/dialer_gate_do"; // [AVA-CAMP-B1-GATE] per-user outbound-dial channel pool + rate limit (dark — nothing calls it yet, campaignDialerEnabled)
export { CampaignDO } from "./do/campaign_do"; // [AVA-CAMP-B2-WIRE] per-campaign SQLite-backed DO (call_fsm state, pacing; dark behind campaignDialerEnabled)
export { AgentSeatAuthorityDO } from "./do/agent_seat_authority"; // [AGENT-LIVE-1] single global seat/capacity authority (WS-B)
export { AgentLiveRoom } from "./do/agent_live_room"; // [AGENT-LIVE-1] per-booking live room DO bridging browser <-> OpenAI gpt-live-1 (WS-E1)
// [DYNW-CORE-1] Dynamic Workers capability entrypoints. Top-level exports are
// REQUIRED so lib/dynw can mint scoped stubs via ctx.exports (enable_ctx_exports)
// and pass them into sandboxed child Workers. Dark behind dynamicWorkersEnabled.
export { DynKV, DynBrain, DynComposio } from "./lib/dynw/caps";
// [DYNW-FLOWS-1] DARK PARALLEL Cloudflare Workflow — account-deletion cascade port
// (§WS-3). LIVE path is still the account-deletions queue → consumers/src/
// deletion.ts + cron backstop; this export is required so wrangler's [[workflows]]
// class_name = "DeletionWorkflow" binding resolves. Dark behind
// deletionWorkflowEnabled (routes/config.ts).
export { DeletionWorkflow } from "./workflows/deletion";

export default {
  async fetch(req: Request, env: Env, ctx: ExecutionContext): Promise<Response> {
    const t0 = Date.now();
    const traceId = req.headers.get("x-trace-id") || crypto.randomUUID();
    let res: Response;
    try {
      res = await dispatch(req, env, ctx);
    } catch (err) {
      // [SRV-ERR-TRACK-1] An uncaught error in any route handler previously became
      // a silent Cloudflare 500 that never reached PostHog. Capture it as a
      // server-side $exception (-> grouped Error-Tracking Issue) and still answer a
      // clean JSON 500. waitUntil so the send survives the response returning.
      ctx.waitUntil(hooks.trackException(env, err, {
        route: new URL(req.url).pathname.slice(0, 120),
        method: req.method,
        trace_id: traceId,
      }));
      res = json({ error: "internal_error", trace_id: traceId }, 500);
    }
    // Operational metric: route, method, trace, latency, status (Analytics Engine).
    try { env.ANALYTICS?.writeDataPoint({ blobs: [new URL(req.url).pathname.slice(0, 64), req.method, traceId], doubles: [Date.now() - t0, res.status], indexes: ["api"] }); } catch { /* best-effort */ }
    return res;
  },

  // Phase 7 — this worker consumes its own money queue (max_retries=5 →
  // money-dlq). The engine is idempotent: a retry or cron re-run can never
  // double-refund (WalletDO op_id dedupe + settlement_log).
  //
  // [LIVE-QUEUE-1] this worker ALSO self-consumes liveness-verify (see
  // wrangler.toml [[queues.consumers]]) — same self-consuming pattern as
  // money-settlements, for the same reason: runLivenessChecks can't be imported
  // into consumers/ (worker↔consumers package split). Each message is
  // {uid, sid}; req is undefined (no live HTTP request in a queue consumer) —
  // runLivenessChecks already treats a missing req as "no edge geo" (see the
  // device ctx comment inside it), so this is a safe, already-handled case.
  async queue(batch: MessageBatch, env: Env): Promise<void> {
    for (const msg of batch.messages) {
      try {
        if (batch.queue.startsWith("money-dlq")) {
          await moneyDlq(env, msg.body);
        } else if (batch.queue.startsWith("contacts-chunk")) {
          // Shared contacts-chunk queue carries TWO message shapes — discriminate
          // on `kind` the same way liveness-verify discriminates on `v3` below.
          // [AVA-CAMP-P-CONTACTS] campaign contact-list chunks (large .csv/.xlsx
          // uploads split by campaign_contacts_route.ts's enqueueOrInsertChunks)
          // carry kind==='campaign_contacts_chunk'; everything else is the
          // pre-existing contact-book chunking job (dormant until a CONTACTS
          // queue is bound; today that job runs inline via ctx.waitUntil in
          // contacts_backup.ts).
          const cm = msg.body as { kind?: string };
          if (cm?.kind === "campaign_contacts_chunk") {
            const m = msg.body as CampaignContactsChunkMsg;
            await insertCampaignContacts(env, m.campaign_id, m.uid, m.rows);
          } else {
            await cbook.contactsChunkConsume(env, msg.body);
          }
        } else if (batch.queue.startsWith("ai-media-jobs")) {
          // [AVA-MEDIA-JOB-1] self-consumed, same pattern as money-settlements/
          // liveness-verify below — ai_media_jobs.ts needs this worker's D1/
          // WalletDO bindings, which consumers/ (separate package) can't reach.
          await runAiMediaJobMessage(env, msg.body as AiMediaJobQueueMsg, Number((msg as any).attempts ?? 1));
        } else if (batch.queue.startsWith("liveness-verify")) {
          // [LIVENESS-V3] the shared liveness-verify queue now carries BOTH V2
          // ({uid,sid}) and V3 ({v3:true,uid,sid}) messages. Discriminate on the
          // `v3` flag so V3 dispatches to runLivenessV3Checks (its own deterministic
          // Rekognition pipeline) while V2 stays on runLivenessChecks unchanged.
          const m = msg.body as { v3?: boolean; uid: string; sid: string };
          if (m.v3) await runLivenessV3Checks(env, m.uid, m.sid, undefined);
          else await runLivenessChecks(env, m.uid, m.sid, undefined);
        } else {
          await runMoney(env, msg.body as MoneyMsg);
        }
        msg.ack();
      } catch (e) {
        console.error(`[${batch.queue}] settlement retry:`, String(e));
        // [SRV-ERR-TRACK-1] Surface queue-consumer failures as PostHog $exceptions
        // too -- a message that exhausts retries used to vanish into logs only.
        try { await hooks.trackException(env, e, { route: `queue:${batch.queue}`, handled: true, extra: { queue: batch.queue } }); } catch { /* best-effort */ }
        msg.retry();
      }
    }
  },

  // [AFF-COMM-LIFECYCLE-1] Affiliate commission qualification (§6.1). The
  // hourly cron is wired in wrangler.toml, but both handlers remain safe while
  // the feature flags are off: runAffiliateQualification returns immediately unless
  // avaAffiliateEnabled is true (default false), and it never throws — the
  // affiliate program must not be able to take a cron tick down. Hourly (not
  // per-minute) on purpose: the qualification window is measured in days, and
  // each tick is bounded to QUALIFY_BATCH rows.
  async scheduled(_event: ScheduledController, env: Env, ctx: ExecutionContext): Promise<void> {
    ctx.waitUntil(
      Promise.all([
        gcalExportSweep(env).catch(e=>console.error("[gcal-export]",String(e))),
        runAffiliateQualification(env)
          .then((r) => { if (r.scanned) console.log("[affiliate-qualify]", JSON.stringify(r)); })
          .catch((e) => { console.error("[affiliate-qualify] failed:", String(e)); }),
        runPlayVoidedPurchaseSweep(env)
          .then((r) => { if (r.scanned) console.log("[play-voids]", JSON.stringify(r)); })
          .catch((e) => { console.error("[play-voids] failed:", String(e)); }),
        recoverAiMediaJobs(env)
          .catch((e) => { console.error("[ai-media-recovery] failed:", String(e)); }),
        sweepAvaReadableCopies(env)
          .then((n) => { if (n) console.log("[ava-readable-cleanup]", n); })
          .catch((e) => { console.error("[ava-readable-cleanup] failed:", String(e)); }),
        reconcileCommercialSessions(env)
          .then((r) => { if (r.scanned) console.log("[commercial-reconciliation]", JSON.stringify(r)); })
          .catch((e) => { console.error("[commercial-reconciliation] failed:", String(e)); }),
        // [SESSION-CLOCK-0] "The schedule ends a session, never a provider event"
        // (RULEBOOK-PAID-SESSIONS.md §5) -- this is that schedule for 1:1 consults.
        // [WAITROOM-3] backfillCheckedInConsultSessions runs first: it synthesizes
        // the missing commercial_sessions row (+ settlement job) for a booking the
        // creator checked into but the buyer never opened, so that booking is not
        // invisible to settlement. It must not block endDueConsultSessions on
        // failure, so its own error is caught before the chain continues.
        backfillCheckedInConsultSessions(env)
          .then((r) => { if (r.scanned) console.log("[commercial-consult-checkin-backfill]", JSON.stringify(r)); })
          .catch((e) => { console.error("[commercial-consult-checkin-backfill] failed:", String(e)); })
          .then(() => endDueConsultSessions(env))
          .then((r) => { if (r.scanned) console.log("[commercial-consult-session-clock]", JSON.stringify(r)); })
          .catch((e) => { console.error("[commercial-consult-session-clock] failed:", String(e)); }),
        // [WAITROOM-4 / R3] Cron safety net for the DO `live_grace` alarm —
        // see sweepExpiredLiveGrace's own doc comment for why this exists
        // alongside the alarm rather than instead of it.
        sweepExpiredLiveGrace(env)
          .then((r) => { if (r.scanned) console.log("[commercial-live-grace-sweep]", JSON.stringify(r)); })
          .catch((e) => { console.error("[commercial-live-grace-sweep] failed:", String(e)); }),
        reconcileListingLifecycleProjections(env)
          .then((r) => { if (r.scanned) console.log("[listing-lifecycle-reconciliation]", JSON.stringify(r)); })
          .catch((e) => { console.error("[listing-lifecycle-reconciliation] failed:", String(e)); }),
        reconcileListingPublicationEffects(env)
          .then((r) => { if (r.scanned) console.log("[listing-publication-reconciliation]", JSON.stringify(r)); })
          .catch((e) => { console.error("[listing-publication-reconciliation] failed:", String(e)); }),
        recoverEmailOutbox(env)
          .catch(() => { console.error("[commercial-email-recovery] failed"); }),
        // [LISTING-EXPIRY-1] Close published shows whose scheduled end has passed.
        expireEndedEventListings(env)
          .then((r) => { if (r.scanned) console.log("[listing-schedule-expiry]", JSON.stringify(r)); })
          .catch((e) => { console.error("[listing-schedule-expiry] failed:", String(e)); }),
        // [WAITROOM-3 / reviewer nit 9] Both no-show sweeps run to completion
        // BEFORE runCommercialSettlements (rather than concurrently with it),
        // so a no-show refund/strike/settlement-job insert this same tick is
        // visible to the settlement pass instead of racing it. Sequenced in
        // their own chain so the rest of this Promise.all stays concurrent.
        (async () => {
          await Promise.all([
            runCommercialHostNoShowSweep(env)
              .then((r) => { if (r.scanned) console.log("[commercial-host-no-show-sweep]", JSON.stringify(r)); })
              .catch((e) => { console.error("[commercial-host-no-show-sweep] failed:", String(e)); }),
            // [LISTING-EXPIRY-1] Buyers of a show nobody ever opened (no session row) —
            // invisible to the sweep above — are refunded as the host's no-show.
            runCommercialOrphanNoShowSweep(env)
              .then((r) => { if (r.scanned) console.log("[commercial-orphan-no-show-sweep]", JSON.stringify(r)); })
              .catch((e) => { console.error("[commercial-orphan-no-show-sweep] failed:", String(e)); }),
          ]);
          await runCommercialSettlements(env)
            .then((r) => { if (r.scanned) console.log("[commercial-settlement]", JSON.stringify(r)); })
            .catch((e) => { console.error("[commercial-settlement] failed:", String(e)); });
        })(),
        scanCommercialHealth(env)
          .then((r) => {
            const warnings = r.alarms.filter((alarm) => alarm.state === "warning");
            if (warnings.length) console.log("[commercial-health]", JSON.stringify({ checked_at: r.checked_at, warnings }));
          })
          .catch((e) => { console.error("[commercial-health] failed:", String(e)); }),
        // [LIST-STATS-1] Sweeps creator_stats rows older than 6h (or missing
        // entirely for a creator with sessions), batch of 50 per tick.
        refreshStaleCreatorStats(env)
          .then((r) => { if (r.scanned) console.log("[creator-stats-sweep]", JSON.stringify(r)); })
          .catch((e) => { console.error("[creator-stats-sweep] failed:", String(e)); }),
        // [AGENT-LIVE-1] Claims due refund/release money jobs, finalizes
        // bookings whose ends_at passed with no terminal state, and expires
        // provisional seat reservations (BUILD SPEC §3 "Cron"). Never throws —
        // a bad tick must not take the rest of the cron down.
        runAgentLiveSweeps(env)
          .catch((e) => { ctx.waitUntil(hooks.trackException(env, e, { route: "agent_live_sweeps" })); console.error("[agent-live-sweeps] failed:", String(e)); }),
      ]),
    );
  },
};

// req.cf.continent → DO location hint (no "me" mapping derivable from continent).
const CONTINENT_HINT: Record<string, DurableObjectLocationHint> = {
  AF: "afr", AS: "apac", EU: "weur", NA: "enam", OC: "oc", SA: "sam",
};
function continentHint(req: Request): DurableObjectLocationHint | undefined {
  const c = (req as { cf?: { continent?: string } }).cf?.continent;
  return c ? CONTINENT_HINT[c] : undefined;
}

async function dispatch(req: Request, env: Env, ctx: ExecutionContext): Promise<Response> {
    if (req.method === "OPTIONS") return preflight();
    const url = new URL(req.url);
    const p = url.pathname;

    if (p === "/health") return json({ ok: true, service: "avatok-api", ts: Date.now() });

    // [ADDCALL-2-SRV] `release` added (spec §4.1 step 8 — the 1:1 leg is torn
    // down on the device, so the server needs a signal to close the escalation
    // funnel and emit groupcall_release_p2p). `ctx` is now passed because every
    // migration emit must be waitUntil'd: workerd drops unawaited telemetry on
    // an early-return error path, which is exactly where these emits sit.
    const conferenceRoom = p.match(/^\/api\/conference-room\/([A-Za-z0-9_:.-]{1,96})\/(state|start|participant\/(?:reserve|join|leave)|migration\/(?:reserve|prepare|commit|abort|release)|billing\/(?:start|sponsor\/accept|tick)|host\/transfer|end)$/);
    if (conferenceRoom) return await conferenceRoomRoute(req, env, conferenceRoom[1], conferenceRoom[2], ctx);

    // Remote kill switches (Phase 1, A2) — public read, admin write.
    if (p === "/api/config" && req.method === "GET") return await getConfig(env);
    if (p === "/api/admin/config" && req.method === "PUT") return await putConfig(req, env);

    // Messenger Phase 1 billing authority. These endpoints are mounted for
    // client contract testing, but the master flag in config.ts remains dark;
    // authorization/pricing therefore fail closed until the two-account gate.
    if (p === "/api/messenger-calls/authorize" && req.method === "POST") return await messengerCallAuthorize(req, env);
    if (p === "/api/messenger-calls/pricing" && req.method === "GET") return await messengerCallPricing(req, env);
    if (p === "/api/messenger-calls/status" && req.method === "GET") return await messengerCallBillingStatus(req, env);
    if (p === "/api/messenger-calls/receipt" && req.method === "GET") return await messengerCallReceipt(req, env);
    if (p === "/api/messenger-calls/cancel" && req.method === "POST") {
      const auth = await requireUser(req, env);
      if (isFail(auth)) return json({ error: auth.error }, auth.status);
      const body = await req.json().catch(() => null) as Record<string, unknown> | null;
      const authorizationId = typeof body?.authorization_id === "string" ? body.authorization_id : "";
      if (!authorizationId) return json({ error: "authorization_id required" }, 400);
      const cancelled = await cancelMessengerCallAuthorization(env, auth.uid, authorizationId, "caller_cancelled");
      return json({ cancelled }, cancelled ? 200 : 404);
    }

    // [DYNW-CORE-1] Dynamic Workers Phase 0 acceptance battery (admin-only; 403s
    // unless dynamicWorkersEnabled — dark in prod, exercised on staging).
    if (p === "/api/admin/dynw/acceptance" && req.method === "POST") return await dynwAcceptance(req, env, ctx);

    // [DYNW-RECEPT-RULES-1] Owner receptionist rule scripts (dark behind
    // dynReceptionistRulesEnabled; source moderated + sandboxed, fail-open in-call).
    if (p === "/api/receptionist/rules") return await receptRules(req, env, ctx);

    // Store-review login bypass REMOVED (2026-06-18). Login is moving to
    // Google-only OAuth (no OTP), so reviewers sign in with a Gmail test
    // account and no bypass is needed. The /api/review/login route is gone.

    // Group-call signaling → CallRoom DO (thin router, no logic). The location
    // hint places the room near the FIRST opener (the caller) — hints only apply
    // on first access, so the callee reaches the same instance. Cuts call-setup
    // signaling RTT for far-from-APAC users (Scale proposal Phase 1).
    const room = p.match(/^\/(?:api\/)?room\/([A-Za-z0-9_-]{1,64})$/);
    if (room) {
      const hint = continentHint(req);
      return env.CALL_ROOMS.get(env.CALL_ROOMS.idFromName(room[1]), hint ? { locationHint: hint } : undefined).fetch(req);
    }

    // FREE-tier P2P mesh group-call signaling → MeshRoom DO (≤5). Keyed by group
    // id so all members of one group meet on the same mesh instance. WS = join
    // the mesh; plain GET = presence probe for the "ongoing call" banner. Paid
    // tiers use the CF Realtime SFU (/api/groupcall/*) instead — LiveKit
    // (formerly /api/conference/*) was removed [CF-CALL-007A] (2026-07-24).
    const mesh = p.match(/^\/(?:api\/)?mesh\/([A-Za-z0-9_:.-]{1,64})$/);
    if (mesh) {
      const hint = continentHint(req);
      return env.MESH_ROOMS.get(env.MESH_ROOMS.idFromName(mesh[1]), hint ? { locationHint: hint } : undefined).fetch(req);
    }

    // AvaTalk group conferencing — LiveKit REMOVED [CF-CALL-007A] (2026-07-24).
    // /api/conference/* now always returns a 410 "provider_removed" so any
    // still-installed old client fails cleanly instead of hanging; group calls
    // moved to the CF Realtime SFU path below (/api/groupcall/*). The old
    // /api/conference/webhook (LiveKit → worker) route is gone entirely — no
    // LiveKit deployment will ever call it again. See
    // worker/src/routes/conference.ts header and rollback tag
    // pre-livekit-removal-2026-07-24 for the removed implementation.
    const conf = p.match(/^\/api\/conference\/([A-Za-z0-9_:.-]{1,64})\/(start|join|status|end|beat)$/);
    if (conf) {
      if (conf[2] === "start" && req.method === "POST") return await conferenceStart(req, env, conf[1]);
      if (conf[2] === "join" && req.method === "POST") return await conferenceJoin(req, env, conf[1]);
      if (conf[2] === "status" && req.method === "GET") return await conferenceStatus(req, env, conf[1]);
      if (conf[2] === "end" && req.method === "POST") return await conferenceEnd(req, env, conf[1]);
      if (conf[2] === "beat" && req.method === "POST") return await conferenceBeat(req, env, conf[1]);
    }

    // CF Realtime SFU group calls (≤32 legacy audio-only / ≤25 authenticated A/V).
    // WS → GroupCallRoom DO, which is now the authenticated call authority
    // (call_id/generation/state, [CF-CALL-001]) — the WS upgrade below is a bare
    // pass-through; the DO itself verifies the signed `ticket` query param BEFORE
    // touching any state (never a raw uid/session query param — Non-negotiable
    // migration rule #4). HTTP → SFU session/track proxy (routes/groupcall.ts,
    // CF_RT_SFU_APP_TOKEN + CONF_TICKET_SECRET stay server-side). Gated by
    // groupAudioSfuEnabled (legacy, audio-only) or cloudflareConferenceEnabled
    // ([CF-CALL-001/002] audio+video); LiveKit /api/conference/* was removed
    // [CF-CALL-007A] (2026-07-24) and now always 410s. Keyed by group id so all
    // members meet on one room instance.
    // [ADDCALL-3-SRV] `invite` added to the verb list (spec §5 — ring specific
    // people into a call that is already running). The <verb> group is a CLOSED
    // ENUMERATION, not a wildcard: a handler exported from routes/groupcall.ts
    // but missing from this alternation 404s here, which reads like a routing
    // bug in the client rather than a missing word in a regex.
    const gc = p.match(/^\/api\/groupcall\/([A-Za-z0-9_:.-]{1,64})\/(join|rejoin|publish|pull|renegotiate|close|status|invite|ws)$/);
    if (gc) {
      const groupId = gc[1];
      if (gc[2] === "ws") {
        const hint = continentHint(req);
        return env.GROUP_CALL_ROOMS.get(env.GROUP_CALL_ROOMS.idFromName(groupId), hint ? { locationHint: hint } : undefined).fetch(req);
      }
      if (gc[2] === "join" && req.method === "POST") return await groupCallJoin(req, env, groupId);
      if (gc[2] === "rejoin" && req.method === "POST") return await groupCallRejoin(req, env, groupId);
      if (gc[2] === "publish" && req.method === "POST") return await groupCallPublish(req, env, groupId);
      if (gc[2] === "pull" && req.method === "POST") return await groupCallPull(req, env, groupId);
      if (gc[2] === "renegotiate" && req.method === "PUT") return await groupCallRenegotiate(req, env, groupId);
      if (gc[2] === "close" && req.method === "POST") return await groupCallClose(req, env, groupId);
      if (gc[2] === "status" && req.method === "GET") return await groupCallStatus(req, env, groupId);
      // `ctx` is passed because every invite emit sits on an early-return error
      // path, and workerd drops unawaited telemetry there (CLAUDE.md).
      if (gc[2] === "invite" && req.method === "POST") return await groupCallInvite(req, env, groupId, ctx);
    }

    // [CALL-SFU-1 2026-08-06] 1:1 calls on the Cloudflare Realtime SFU. Keyed by
    // the SAME room id the P2P signalling uses, so `CallRoom` — which already owns
    // ringing, the 2-peer cap and the participant identities — is the authority for
    // both transports. There is deliberately no `ws` verb here: 1:1 signalling
    // stays on the existing CallRoom socket, only the MEDIA path is new.
    const cs = p.match(/^\/api\/callsfu\/([A-Za-z0-9_:.-]{1,64})\/(join|prepare|publish|peer|pull|renegotiate|heartbeat|close)$/);
    if (cs) {
      const room = cs[1];
      if (cs[2] === "join" && req.method === "POST") return await callSfuJoin(req, env, room, ctx);
      if (cs[2] === "prepare" && req.method === "POST") return await callSfuPrepare(req, env, room, ctx);
      if (cs[2] === "publish" && req.method === "POST") return await callSfuPublish(req, env, room, ctx);
      if (cs[2] === "peer" && req.method === "GET") return await callSfuPeer(req, env, room, ctx);
      if (cs[2] === "pull" && req.method === "POST") return await callSfuPull(req, env, room, ctx);
      if (cs[2] === "renegotiate" && req.method === "PUT") return await callSfuRenegotiate(req, env, room, ctx);
      if (cs[2] === "heartbeat" && req.method === "POST") return await callSfuHeartbeat(req, env, room, ctx);
      if (cs[2] === "close" && req.method === "POST") return await callSfuClose(req, env, room, ctx);
    }

    // [CALL-RTK-2 2026-08-08] Cloudflare RealtimeKit media admission
    // (Specs/CALL-REALTIMEKIT-MIGRATION.md). Same room id as the callsfu block
    // above and the P2P signalling, so `CallRoom` stays the single authority on
    // who is on a call across all three media paths. One verb only: RealtimeKit
    // owns the transport after the token is minted, so there is no publish/pull/
    // renegotiate surface to proxy — that absence IS the migration. 503s
    // `rtk_unavailable` while callRealtimeKitV1 / groupRealtimeKitV1 are false.
    const crtk = p.match(/^\/api\/callrtk\/([A-Za-z0-9_:.-]{1,64})\/(join)$/);
    if (crtk) {
      if (crtk[2] === "join" && req.method === "POST") return await callRtkJoin(req, env, crtk[1]);
    }

    // Cloudflare-native messaging — live socket → caller's InboxDO (Nostr deprecated).
    if (p === "/api/inbox" && req.headers.get("Upgrade") === "websocket") return await wsInbox(req, env);

    // PartyKit realtime layer (ephemeral; replaces Ably) — one hibernatable
    // WebSocket per room → PartyDO. Room passed as ?room=<type:id>.
    if (p === "/api/party" && req.headers.get("Upgrade") === "websocket") return await wsParty(req, env);

    // Ava Receptionist call bridge → ReceptionRoom DO (thin router; the DO
    // validates the one-time rtc token from KV). Keyed by session id so caller +
    // DO meet on the same instance. See Specs/PROPOSAL-AI-RECEPTIONIST.md.
    if (p === "/api/receptionist/rtc" && req.headers.get("Upgrade") === "websocket") {
      const sid = url.searchParams.get("session") || "";
      if (!sid) return new Response("session required", { status: 400 });
      const hint = continentHint(req);
      // Engine routing: /start stamps `&engine=cf` on the WS URL when the
      // receptionistUseCf flag is on, so the SAME client connects to the
      // Cloudflare-native DO; otherwise the Gemini ReceptionRoom (unchanged).
      if (url.searchParams.get("engine") === "cf") {
        return env.RECEPTION_ROOM_CF.get(env.RECEPTION_ROOM_CF.idFromName(sid), hint ? { locationHint: hint } : undefined).fetch(req);
      }
      return env.RECEPTION_ROOM.get(env.RECEPTION_ROOM.idFromName(sid), hint ? { locationHint: hint } : undefined).fetch(req);
    }

    // [AVA-PSTN-AGENT-1] Vobiz bidirectional media stream → VobizAgentRoom DO
    // (live Gemini agent on cell/DID calls, Specs/PLAN-2026-07-19-vobiz-media-
    // stream-agent.md). Secret-in-path auth (webhook pattern) is verified in
    // the route; the DO validates the single-use pstn_agent:<sid> KV record.
    if (p.startsWith("/api/pstn-agent/stream/") && req.headers.get("Upgrade") === "websocket") {
      return await pstnAgentStream(req, env, p);
    }

    // [AVA-VM-SELFREC-1] Vobiz bidirectional media stream → VoicemailStreamRoom DO
    // (self-recorded voicemail; secret-in-path auth verified in the route, the DO
    // validates the single-use pstn_vm:<sid> KV record). DARK behind
    // pstnVoicemailSelfRecord — routes/pstn.ts only emits this <Stream> when the
    // flag is on, so the route is inert otherwise.
    if (p.startsWith("/api/pstn-vm/stream/") && req.headers.get("Upgrade") === "websocket") {
      return await pstnVoicemailStream(req, env, p);
    }

    // [RECEPT-BACKEND-TOGGLES-1] (owner decision 2026-07-23): VOICEMAIL IS RETIRED.
    // The VoicemailRoom DO entrypoint is now GONE — voicemailStart() returns 410 so no
    // rtc token/KV init blob is ever minted, and the AI receptionist is the sole
    // unanswered-call handler. Refuse the upgrade with 410 instead of spinning up a DO
    // so a lingering old client can never open a voicemail session. (Recorded voicemail
    // PLAYBACK stays available via /api/voicemail/recording — an Inbox read path.)
    if (p === "/api/voicemail/rtc" && req.headers.get("Upgrade") === "websocket") {
      return new Response("voicemail retired", { status: 410 });
    }

    // Ava AI Voice Agent bridge → AgentVoiceRoom DO (WP4, plan §4/§7 item 7).
    // Same thin-router pattern as voicemail/receptionist above. Dark unless a
    // session was started via POST /api/agent/call/start (which itself 503s
    // when voiceAgent is off).
    if (p === "/api/agent/call/rtc" && req.headers.get("Upgrade") === "websocket") {
      const sid = url.searchParams.get("session") || "";
      if (!sid) return new Response("session required", { status: 400 });
      const hint = continentHint(req);
      return env.AGENT_VOICE_ROOMS.get(env.AGENT_VOICE_ROOMS.idFromName(sid), hint ? { locationHint: hint } : undefined).fetch(req);
    }

    try {
      // --- messaging (Cloudflare-native; Clerk-JWT auth, server-readable) ---
      // [MSG-CTX-WAITUNTIL-1] ctx threaded through so post-response work (archive/
      // analytics queue sends, delegateScan, guardianScan, brainIngest, auto-reply,
      // Party events) rides ctx.waitUntil instead of a detached promise the
      // runtime can reap after the response is written (J3).
      if (p === "/api/msg/send" && req.method === "POST") return await sendMsg(req, env, ctx);
      if (p === "/api/msg/sync" && req.method === "GET") return await syncMsg(req, env);
      // Phase 3 (ABLY-R2-3): deep history from R2/D1 (older than Ably's window).
      if (p === "/api/msg/archive" && req.method === "GET") return await archiveList(req, env);
      if (p === "/api/archive/page" && req.method === "GET") return await archivePage(req, env); // P8 Stage 2: batched-jsonl pager
      if (p === "/api/msg/receipt" && req.method === "POST") return await receiptMsg(req, env);
      // [AVAGRP-SEENBY-1] Group "Info → seen by": per-message batch receipts +
      // on-demand read-back. Dark behind groupReceiptsEnabled (worker/src/routes/config.ts).
      if (p === "/api/msg/receipts" && req.method === "POST") return await msgReceiptBatch(req, env);
      if (p === "/api/msg/seen" && req.method === "GET") return await msgSeenState(req, env);
      if (p === "/api/msg/read" && req.method === "POST") return await readMsg(req, env);
      if (p === "/api/msg/hide" && req.method === "POST") return await hideMsg(req, env);
      // Phase 4 (ABLY-R2-4): persist a per-message reaction (live ride is Ably).
      if (p === "/api/msg/react" && req.method === "POST") return await reactMsg(req, env, ctx);
      // [AVA-REACT-1] Thread-open hydrate for durably-stored reactions (mirrors
      // /api/poll/state). The read half of the message_reactions table.
      if (p === "/api/msg/reactions" && req.method === "GET") return await reactionsState(req, env);
      // Phase 5 (ABLY-R2-5): owner-private state from D1 (read/hidden/call-log).
      if (p === "/api/msg/state" && req.method === "GET") return await stateMsg(req, env);
      // 2026-07-04: server-persisted poll votes (survive reinstall/backup).
      if (p === "/api/poll/vote" && req.method === "POST") return await pollVote(req, env);
      if (p === "/api/poll/state" && req.method === "GET") return await pollState(req, env);
      // Call-log multi-device sync (owner's own InboxDO; delete/clear wake asleep devices).
      if (p === "/api/call-log/append" && req.method === "POST") return await callLogAppend(req, env, ctx);
      if (p === "/api/call-log/delete" && req.method === "POST") return await callLogDelete(req, env, ctx);
      if (p === "/api/call-log/clear" && req.method === "POST") return await callLogClear(req, env, ctx);
      if (p === "/api/conversations" && req.method === "GET") return await convList(req, env);
      if (p === "/api/conversations" && req.method === "POST") return await convCreate(req, env);
      if (p === "/api/conversations/adopt" && req.method === "POST") return await convAdopt(req, env);
      // --- v4 server-authoritative routing path (ARCH-ROUTING-V2) — ADDITIVE and
      //     DORMANT behind the routingV2Enabled kill switch. Strangler pattern: this
      //     coexists with the legacy /api/conversations + /api/msg/send path above
      //     and NOTHING here executes until the flag is flipped ON in KV per-cohort.
      //     Frozen architecture: Specs/ROUTING-IDENTITY-PRESENCE-ARCH.md.
      if (p.startsWith("/api/v2/")) {
        const cfg = await readConfig(env);
        if (!cfg.routingV2Enabled) return json({ error: "v2_disabled" }, 404);
        if (p === "/api/v2/conversations" && req.method === "POST") return await createConversation(req, env);
        if (p === "/api/v2/conversations" && req.method === "GET") return await listConversations(req, env);
        if (p === "/api/v2/conversations/participants" && req.method === "GET") return await getParticipants(req, env);
        return json({ error: "not found" }, 404);
      }
      // Group membership management (Group Info screen).
      if (p === "/api/conversations/members" && req.method === "GET") return await convMembers(req, env);
      if (p === "/api/conversations/members/add" && req.method === "POST") return await convAddMembers(req, env);
      if (p === "/api/conversations/invites" && req.method === "GET") return await convInvites(req, env);
      if (p === "/api/conversations/invite/respond" && req.method === "POST") return await convInviteRespond(req, env);
      if (p === "/api/conversations/members/remove" && req.method === "POST") return await convRemoveMember(req, env);
      if (p === "/api/conversations/members/role" && req.method === "POST") return await convSetRole(req, env);
      // [GROUP-AVATAR-1] Set/clear a group photo (admins only; '' clears).
      if (p === "/api/conversations/avatar" && req.method === "POST") return await convSetAvatar(req, env);
      if (p === "/api/conversations/leave" && req.method === "POST") return await convLeave(req, env);
      if (p === "/api/conversations/delete" && req.method === "POST") return await convDelete(req, env);
      // [AVA-GROUP-COMPANION-1] Group Ava state + member prefs (I1/I2). Auth +
      // membership/role checks live inside each handler (requireUser +
      // convRoleOf/convIsGroup), same idiom as the group-membership routes above.
      if (p === "/api/conversations/ava/state" && req.method === "GET") return await convAvaGroupStateGet(req, env);
      if (p === "/api/conversations/ava/state" && req.method === "PUT") return await convAvaGroupStatePut(req, env);
      if (p === "/api/conversations/ava/member-prefs" && req.method === "GET") return await convAvaMemberPrefsGet(req, env);
      if (p === "/api/conversations/ava/member-prefs" && req.method === "PUT") return await convAvaMemberPrefsPut(req, env);
      // [AVA-TOGGLE-DM-1] Per-thread Ava toggle for 1:1. Unlike the group pair
      // above, these are gated on remote-config avaDmToggleEnabled (false in
      // production today): GET reports enabled:false, PUT refuses 403 and
      // writes nothing, so the feature is fully inert until the flag is flipped.
      if (p === "/api/conversations/ava/dm-state" && req.method === "GET") return await convAvaDmStateGet(req, env);
      if (p === "/api/conversations/ava/dm-state" && req.method === "PUT") return await convAvaDmStatePut(req, env, ctx);
      // --- AI Messenger Batch 2026-07-03 route mounts ---
      // STREAM I: unlimited forwarding (no-copy fan-out; requires liveness when gate ON)
      if (p === "/api/msg/forward" && req.method === "POST") return await forwardMsg(req, env, ctx);
      // STREAM B: stranger safety gate (accept/block/report + accept-state)
      if (p === "/api/conversations/accept" && req.method === "POST") return await convAccept(req, env);
      if (p === "/api/conversations/block" && req.method === "POST") return await convBlock(req, env);
      if (p === "/api/conversations/accept-state" && (req.method === "GET" || req.method === "POST")) return await convAcceptState(req, env);
      if (p === "/api/safety/report" && req.method === "POST") return await safetyReport(req, env);
      // STREAM A: marketplace agent settings
      if (p === "/api/marketplace/agent-settings" && req.method === "GET") return await marketplaceAgentSettingsGet(req, env);
      if (p === "/api/marketplace/agent-settings" && req.method === "PUT") return await marketplaceAgentSettingsPut(req, env);
      // STREAM K: marketplace favorites
      if (p === "/api/marketplace/favorites" && req.method === "POST") return await addFavorite(req, env);
      if (p === "/api/marketplace/favorites" && req.method === "DELETE") return await removeFavorite(req, env);
      if (p === "/api/marketplace/favorites" && req.method === "GET") return await listFavorites(req, env);
      // [FAV-TRUTH-1] "Have I hearted this, and how many others have?" — the one
      // authenticated read the public, edge-cached listing page cannot do for
      // itself at render time. Optional auth: a guest gets the count, not a 401.
      if (p === "/api/marketplace/favorites/state" && req.method === "GET") return await favoriteState(req, env);
      // STREAM C: server-side link unfurl (zero recipient-side fetch)
      if (p === "/api/unfurl" && req.method === "GET") return await unfurl(req, env);
      // STREAM E: Tenor GIF proxy (key stays server-side)
      if (p === "/api/gif/search" && req.method === "GET") return await gifSearch(req, env);
      if (p === "/api/gif/trending" && req.method === "GET") return await gifTrending(req, env);
      // STREAM F: auto-responder settings
      if (p === "/api/auto-responder" && req.method === "GET") return await getAutoResponder(req, env);
      if (p === "/api/auto-responder" && req.method === "PUT") return await putAutoResponder(req, env);
      // STREAM G: AI-in-chats (catchup / smart-replies / translate / group-translate / safety score)
      if (p === "/api/ai/catchup" && req.method === "POST") return await aiCatchup(req, env);
      if (p === "/api/ai/smart-replies" && req.method === "POST") return await aiSmartReplies(req, env);
      if (p === "/api/ai/translate" && req.method === "POST") return await aiTranslate(req, env);
      if (p === "/api/ai/group-translate" && req.method === "POST") return await aiGroupTranslate(req, env);
      if (p === "/api/safety/score" && req.method === "POST") return await safetyScore(req, env);
      // Profile: AI "write my bio" (moderated in + out)
      if (p === "/api/ai/bio" && req.method === "POST") return await aiBio(req, env);
      // Profile: AI gender-from-name (prefill + lock the pronoun field)
      if (p === "/api/ai/gender" && req.method === "POST") return await aiGender(req, env);

      // STREAM F — auto-responder ("Ava replies while you're away") per-user settings.
      if (p === "/api/auto-responder" && req.method === "GET") return await getAutoResponder(req, env);
      if (p === "/api/auto-responder" && req.method === "PUT") return await putAutoResponder(req, env);

      // [AVA-VOICE-STYLE-1] WS-14 — per-user "how Ava speaks" (Hinglish Gen-Z by
      // default). Must be registered BEFORE the /api/ava/* handlers below only
      // in the sense of readability; the checks are exact-path so order is not
      // load-bearing here.
      if (p === "/api/ava/voice-style" && req.method === "GET") return await getAvaVoiceStyle(req, env);
      if (p === "/api/ava/voice-style" && req.method === "PUT") return await putAvaVoiceStyle(req, env);

      // --- Ava in-chat AI (Phase 0 registered routes; handlers filled by the
      // owner phases — master-plan §4). Order: most-specific first. ---
      if (p === "/api/ava/gemini" && req.method === "POST") return await avaGemini(req, env);          // P2
      if (p === "/api/ava/gemini/stream" && req.method === "POST") return await avaGeminiStream(req, env); // P2 streaming
      if (p === "/api/ava/live/token" && req.method === "POST") return await avaLiveToken(req, env);   // fast online voice call
      // [AVABRAIN-VOICE-BILL-1] session-lease heartbeat/close — see routes/ava_live.ts
      // header + worker/src/lib/voice_billing.ts. No-ops while avaBrainVoiceBillingEnabled is off.
      if (p === "/api/ava/live/heartbeat" && req.method === "POST") return await avaLiveHeartbeat(req, env);
      if (p === "/api/ava/live/close" && req.method === "POST") return await avaLiveClose(req, env);
      if (p === "/api/ava/thread/turn" && req.method === "POST") return await avaThreadTurn(req, env, ctx); // P3
      if (p === "/api/ava/rag/ingest" && req.method === "POST") return await avaRagIngest(req, env);   // RAG
      if (p === "/api/ava/rag/store" && req.method === "GET") return await avaRagStore(req, env);      // RAG
      if (p === "/api/ava/rag/search" && req.method === "POST") return await avaRagSearch(req, env);   // RAG
      if (p === "/api/ava/rag/backfill" && req.method === "POST") return await avaRagBackfill(req, env); // RAG backfill (history → AI Search)
      if (p === "/api/brain/thread-search" && req.method === "POST") return await avaThreadSearch(req, env); // in-thread smart (semantic) search
      if (p === "/api/ava/apps/catalog" && req.method === "GET") return await avaAppsCatalog(req, env);  // AvaApps
      if (p === "/api/ava/apps/connect" && req.method === "POST") return await avaAppsConnect(req, env); // AvaApps
      if (p === "/api/ava/apps/disconnect" && req.method === "POST") return await avaAppsDisconnect(req, env); // AvaApps
      if (p === "/api/ava/apps/status" && req.method === "GET") return await avaAppsStatus(req, env);    // AvaApps
      if (p === "/api/ava/apps/run" && req.method === "POST") return await avaAppsRun(req, env, ctx);    // AvaApps ([DYNW-CODEMODE-1]: ctx enables Code Mode)
      if (p === "/api/ava/genui/action" && req.method === "POST") return await avaGenuiAction(req, env); // GenUI card action (Composio)
      if (p === "/api/ava/genui/thumb" && req.method === "GET") return await avaGenuiThumb(req, env);   // GenUI preview thumbnail (signed-URL proxy)
      if (p === "/api/ava/email/list" && req.method === "POST") return await avaEmailList(req, env);    // in-chat email
      if (p === "/api/ava/email/get" && req.method === "POST") return await avaEmailGet(req, env);      // in-chat email
      if (p === "/api/ava/email/spam" && req.method === "POST") return await avaEmailSpam(req, env);    // in-chat email
      if (p === "/api/ava/email/trash" && req.method === "POST") return await avaEmailTrash(req, env);  // in-chat email
      if (p === "/api/ava/email/reply" && req.method === "POST") return await avaEmailReply(req, env);  // in-chat email
      // AvaTOK own-file storage in the user's Google Drive (connect reuses the
      // Google OAuth — same consent grants calendar.events + drive.file).
      if (p === "/api/ava/drive/connect" && req.method === "POST") return await gcalConnect(req, env);
      if (p === "/api/ava/drive/status" && req.method === "GET") return await driveStatus(req, env);
      if (p === "/api/ava/drive/list" && req.method === "GET") return await driveListRoute(req, env);
      if (p === "/api/ava/drive/upload" && req.method === "POST") return await driveUploadRoute(req, env);
      if (p === "/api/ava/drive/backup/ensure" && req.method === "POST") return await driveBackupEnsureRoute(req, env);
      if (p === "/api/ava/drive/backup/upload" && req.method === "POST") return await driveBackupUploadRoute(req, env);
      if (p === "/api/ava/drive/backup/download" && req.method === "GET") return await driveBackupDownloadRoute(req, env);
      if (p === "/api/ava/drive/backup/list" && req.method === "GET") return await driveBackupListRoute(req, env);
      if (p === "/api/ava/chat/history/meta" && req.method === "POST") return await avaChatHistoryMeta(req, env);
      if (p === "/api/ava/chat/history" && req.method === "POST") return await avaChatHistorySave(req, env);
      if (p === "/api/ava/chat/history" && req.method === "GET") return await avaChatHistoryGet(req, env);
      if (p === "/api/ava/guardian/scan" && req.method === "POST") return await avaGuardianScan(req, env); // P8
      if (p === "/api/moderate" && req.method === "POST") return await moderateText(req, env);         // save-time content validation (Nemotron)
      // P9 — [AVA-IMG-KEEPALIVE-1] ctx is REQUIRED here: image generation runs
      // detached after the response, and only ctx.waitUntil keeps it alive.
      if (p === "/api/ava/image" && req.method === "POST") return await avaImage(req, env, ctx);
      if (p === "/api/ava/delegate") return await delegateHandler(req, env); // P7 (GET reads prefs, POST writes)
      if (p === "/api/ava/doc/summarize" && req.method === "POST") return await avaDocSummarize(req, env);        // Copilot A+B
      if (p === "/api/ava/doc/translate" && req.method === "POST") return await avaDocTranslate(req, env);        // Copilot A+B
      if (p === "/api/ava/doc/translate-file" && req.method === "POST") return await avaDocTranslateFile(req, env); // Copilot A+B
      if (p === "/api/ava/chat-toggle" && (req.method === "GET" || req.method === "POST")) return await avaChatToggle(req, env); // D29 per-chat Ava toggle
      if (p === "/api/ava/triggers" && req.method === "GET") return await avaTriggersGet(req, env);        // ODL: on-device trigger bank sync (D31)
      if (p === "/api/ava/ledger" && req.method === "GET") return await avaLedgerGet(req, env);            // ODL: capability cost ledger snapshot (D25)
      if (p === "/api/ava/moment-outcome" && req.method === "POST") return await avaMomentOutcome(req, env); // ODL: learning loop outcome (Constitution 11)
      // [AVA-MEDIA-JOB-1] durable AI media job state machine (image/doc/audio jobs)
      if (p === "/api/ai/jobs" && req.method === "POST") return await aiMediaJobsCreate(req, env, ctx);
      if (p === "/api/ai/jobs" && req.method === "GET") return await aiMediaJobsList(req, env);
      { const m = p.match(/^\/api\/ai\/jobs\/([A-Za-z0-9_-]{1,128})\/share$/); if (m && req.method === "POST") return await aiMediaJobSongShare(req, env, m[1]); }
      { const m = p.match(/^\/api\/ai\/jobs\/([A-Za-z0-9_-]{1,128})\/video-share$/); if (m && req.method === "POST") return await aiMediaJobVideoShare(req, env, m[1]); }
      { const m = p.match(/^\/api\/ai\/jobs\/([A-Za-z0-9_-]{1,128})\/cancel$/); if (m && req.method === "POST") return await aiMediaJobsCancel(req, env, m[1]); }
      { const m = p.match(/^\/api\/ai\/jobs\/([A-Za-z0-9_-]{1,128})$/); if (m && req.method === "GET") return await aiMediaJobsGet(req, env, m[1]); }
      { const m = p.match(/^\/s\/song\/([A-Za-z0-9_-]{10,128})$/); if (m && req.method === "GET") return await aiMediaSongSharePage(req, env, m[1]); }
      { const m = p.match(/^\/s\/song\/([A-Za-z0-9_-]{10,128})\/(cover|audio)$/); if (m && req.method === "GET") return await aiMediaSongShareAsset(req, env, m[1], m[2] as "cover" | "audio"); }
      { const m = p.match(/^\/s\/video\/([A-Za-z0-9_-]{10,128})$/); if (m && (req.method === "GET" || req.method === "HEAD")) return await aiMediaVideoSharePage(req, env, m[1]); }
      { const m = p.match(/^\/s\/video\/([A-Za-z0-9_-]{10,128})\/(thumbnail|video)$/); if (m && (req.method === "GET" || req.method === "HEAD")) return await aiMediaVideoShareAsset(req, env, m[1], m[2] as "thumbnail" | "video"); }
      // [AVABRAIN-COMPANION-2] group Companion mode + effective policy + draft approval (routes/ava_group.ts)
      if (p === "/api/ava/group/mode" && req.method === "GET") return await avaGroupModeGet(req, env);
      if (p === "/api/ava/group/mode" && req.method === "POST") return await avaGroupModePost(req, env);
      if (p.startsWith("/api/ava/group/policy/") && req.method === "GET") {
        return await avaGroupPolicyGet(req, env, decodeURIComponent(p.slice("/api/ava/group/policy/".length)));
      }
      if (p.startsWith("/api/ava/group/draft/") && p.endsWith("/approve") && req.method === "POST") {
        const id = p.slice("/api/ava/group/draft/".length, p.length - "/approve".length);
        return await avaGroupDraftApprove(req, env, decodeURIComponent(id));
      }
      if (p.startsWith("/api/ava/group/draft/") && p.endsWith("/reject") && req.method === "POST") {
        const id = p.slice("/api/ava/group/draft/".length, p.length - "/reject".length);
        return await avaGroupDraftReject(req, env, decodeURIComponent(id));
      }
      // [AVABRAIN-COMPANION-UI-1] pending-draft list for the draft-card UI (member-only)
      if (p.startsWith("/api/ava/group/drafts/") && req.method === "GET") {
        return await avaGroupDraftsGet(req, env, decodeURIComponent(p.slice("/api/ava/group/drafts/".length)));
      }
      // Backup & sync (P10): GET pull, PUT push, GET status.
      if (p === "/api/backup/status" && req.method === "GET") return await backupStatus(req, env);
      if (p === "/api/backup" && req.method === "GET") return await backupGet(req, env);
      if (p === "/api/backup" && req.method === "PUT") return await backupPut(req, env);

      // AI Ringback Tones + Busy Tone — generation + 5-item library.
      // /api/ringtone/{generate|list|user/<uid>/default|<id>/default|<id>}
      if (p.startsWith("/api/ringtone/")) return await ringtone(req, env, p.slice("/api/ringtone/".length));

      // --- AvaDial community spam shield (Phase 2a; DARK behind spamShield) ---
      if (p === "/api/spam/report" && req.method === "POST") return await spamReport(req, env);
      if (p.startsWith("/api/spam/lookup/") && req.method === "GET") return await spamLookup(req, env, ctx, p.slice("/api/spam/lookup/".length));
      if (p === "/api/spam/bloom" && req.method === "GET") return await spamBloom(req, env);
      if (p === "/api/spam/rescore" && req.method === "POST") return await spamRescore(req, env);

      // --- Home dashboard card aggregates (Phase 3; DARK behind shellV2) ---
      if (p === "/api/home/cards" && req.method === "GET") return await homeCards(req, env, ctx);

      // --- directory ---
      if (p === "/api/profile" && req.method === "POST") return await api.profileUpsert(req, env);
      if (p === "/api/me" && req.method === "GET") return await api.me(req, env);
      if (p === "/api/vault" && req.method === "POST") return await api.vaultPut(req, env);
      if (p === "/api/vault" && req.method === "GET") return await api.vaultGet(req, env);
      // Account key escrow — makes the aek (and thus every uid-keyed vault blob)
      // recoverable on reinstall / new phone. See routes/keybackup.ts.
      if (p === "/api/keybackup" && req.method === "POST") return await keybk.keyBackupPut(req, env);
      if (p === "/api/keybackup" && req.method === "GET") return await keybk.keyBackupGet(req, env);
      // Two-tier cache: L1 = 60s per-colo edge response cache; L2 = 30-min KV
      // read-through (survives across requests/colos, keyed by hashed query). The
      // DB query behind a miss is now index-only. Hot entities → instant.
      if (p === "/api/resolve" && req.method === "GET") return await cached(req, ctx, () => api.withSearchCache(req, env, () => api.resolve(req, env)), 60);
      if (p === "/api/search" && req.method === "GET") return await cached(req, ctx, () => api.withSearchCache(req, env, () => api.search(req, env)), 60);
      if (p === "/api/handle/check" && req.method === "GET") return await cached(req, ctx, () => api.handleCheck(req, env), 10);

      // --- AvaTOK Number (virtual in-network number; Specs/AVATOK-NUMBER-FEATURE-SPEC.md) ---
      if (p === "/api/number/countries" && req.method === "GET") return num.countries();
      if (p === "/api/number/available" && req.method === "GET") return await num.available(req, env);
      if (p === "/api/number/reserve" && req.method === "POST") return await num.reserve(req, env);
      if (p === "/api/number/assign" && req.method === "POST") return await num.assign(req, env);
      if (p === "/api/number/assign-own" && req.method === "POST") return await num.assignOwn(req, env);
      // [PIVOT-PAID-NUMBER-1] Buy a vanity/short AvaTOK number with tokens.
      // Without this line purchaseVanity is unreachable dead code — the endpoint
      // equivalent of the fake-flag problem CLAUDE.md documents, where a feature
      // is fully built, looks correct in review, and can never actually fire.
      if (p === "/api/number/purchase" && req.method === "POST") return await num.purchaseVanity(req, env);
      if (p === "/api/number/me" && req.method === "GET") return await num.me(req, env);
      if (p === "/api/number/release" && req.method === "POST") return await num.release(req, env);
      if (p === "/api/number/share-card" && req.method === "POST") return await num.shareCardPut(req, env);
      if (p === "/api/number/privacy" && req.method === "GET") return await num.privacyGet(req, env);
      if (p === "/api/number/privacy" && req.method === "POST") return await num.privacySet(req, env);
      if (p === "/api/number/private" && req.method === "POST") return await num.privateNumberSet(req, env);
      if (p === "/api/add" && req.method === "GET") return await cached(req, ctx, () => num.addResolve(req, env), 30);

      // AvaCalls universal classifier and Virtual Numbers multi-line domain.
      // These are separate from the legacy singular AvaTOK number routes above.
      if (p === "/api/avacalls/resolve" && req.method === "POST") return await avacallsResolve(req, env);
      if (p === "/api/virtual-lines" || p.startsWith("/api/virtual-lines/")) return await virtualLinesRoute(req, env, p);

      // --- Team Receptionist (IVR / auto-attendant; Specs/TEAM-RECEPTIONIST-IVR-SPEC.md) ---
      if (p === "/api/team" && req.method === "POST") return await team.teamCreate(req, env);
      if (p === "/api/team" && req.method === "GET") return await team.teamGet(req, env);
      if (p === "/api/team" && req.method === "PUT") return await team.teamUpdate(req, env);
      if (p === "/api/team/members" && req.method === "POST") return await team.teamMemberAdd(req, env);
      if (p.startsWith("/api/team/members/") && req.method === "PUT") return await team.teamMemberUpdate(req, env, p.slice("/api/team/members/".length));
      if (p.startsWith("/api/team/members/") && req.method === "DELETE") return await team.teamMemberRemove(req, env, p.slice("/api/team/members/".length));
      if (p === "/api/team/invite/accept" && req.method === "POST") return await team.teamInviteAccept(req, env);
      if (p === "/api/team/invite/decline" && req.method === "POST") return await team.teamInviteDecline(req, env);
      if (p === "/api/team/messages" && req.method === "GET") return await team.teamMessages(req, env);
      if (p === "/api/team/ivr" && req.method === "GET") return await team.teamIvrMenu(req, env);
      if (p === "/api/team/ivr/audio" && req.method === "GET") return await team.teamIvrAudio(req, env);
      if (p === "/api/team/ivr/route" && req.method === "POST") return await team.teamIvrRoute(req, env);

      // --- push / calls ---
      if (p === "/api/register" && req.method === "POST") return await api.register(req, env);
      // [MULTIACCT-2] flip an account's device mapping on switch/logout (device token stays)
      if (p === "/api/account/device" && req.method === "POST") return await api.accountDevice(req, env);
      // [CALL-PRESENCE-1 2026-08-07] The device heartbeat. Cheapest authed route
      // in the Worker (one Upstash SET, no D1, no DO) because it runs every
      // presenceHeartbeatSec on every connected device. /api/call reads what it
      // writes, BEFORE the DO round-trips.
      if (p === "/api/presence/beat" && req.method === "POST") return await presenceBeat(req, env, ctx);
      if (p === "/api/call" && req.method === "POST") return await api.call(req, env, ctx);
      if (p === "/api/notify" && req.method === "POST") return await api.notify(req, env);
      if (p === "/api/call-status" && req.method === "POST") return await api.callStatus(req, env);
      // Short-lived call capability; usable by Android's native notification
      // action when the Flutter process has been swiped away.
      if (p === "/api/call/native-decline" && req.method === "POST") return await api.callNativeDecline(req, env);
      // [CALL-QUICK-REPLY-1 2026-08-01] Callee dismissed a ringing call with a
      // canned "Message" reply -> deliver it to the caller. Server owns the text.
      if (p === "/api/call/quick-reply" && req.method === "POST") return await api.callQuickReply(req, env);
      // [CALL-SPAM-REPORT-1 2026-08-01] Report an AvaTOK CALLER as spam (uid-keyed).
      // Distinct from /api/spam/report (E.164-keyed) and /api/safety/report (conv-keyed).
      if (p === "/api/calls/report" && req.method === "POST") return await api.callReportSpam(req, env);
      // [CALL-FSM-1 2026-08-01] THE single command endpoint. Every call outcome
      // (accept/decline/quick reply/receptionist/voicemail/spam/block/cancel)
      // enters here and is executed by the state machine in lib/call_state.ts.
      if (p === "/api/call/command" && req.method === "POST") return await api.callCommand(req, env);
      if (p === "/api/call-state" && req.method === "GET") return await api.callState(req, env);
      if (p === "/api/call/ringing" && req.method === "POST") return await api.callRinging(req, env);
      if (p === "/api/call/notify-register" && req.method === "POST") return await api.callNotifyRegister(req, env);
      // [WP3-ACT-1] After-ring routing decision (plan §3 step 4) — 503 unless businessCallUx is on.
      if (p === "/api/call/no-answer" && req.method === "POST") return await api.callNoAnswer(req, env);
      // Legacy paid-human-call compatibility/refund routes. Human calling is
      // permanently free; server policy prevents these from creating charges.
      if (p === "/api/call/paid/offer" && req.method === "GET") return await getPaidCallOfferRoute(req, env);
      if (p === "/api/call/paid/settings" && req.method === "GET") return await getPaidCallSettingsRoute(req, env);
      if (p === "/api/call/paid/settings" && req.method === "PUT") return await putPaidCallSettingsRoute(req, env);
      if (p === "/api/call/paid/prepare" && req.method === "POST") return await preparePaidCallRoute(req, env);
      if (p === "/api/call/paid/confirm" && req.method === "POST") return await confirmPaidCallRoute(req, env);
      if (p === "/api/call/paid/cancel" && req.method === "POST") return await cancelPaidCallRoute(req, env);
      // [WP3] Voicemail bot session start — 503 unless voicemailBot flag is on.
      if (p === "/api/voicemail/start" && req.method === "POST") return await voicemailStart(req, env);
      // GAP-3: owner-authed voicemail recording playback (mirrors /api/receptionist/recording).
      if (p === "/api/voicemail/recording" && req.method === "GET") return await voicemailRecording(req, env);
      // [CALLREC-SERVER-1] On-demand call recording (Specs/FEASIBILITY-CALL-RECORDING-
      // 2026-08-04.md §5.1). Bytes are captured on-device and land here AFTER the call;
      // storage/quota/dedup all ride registerArtifactMedia. Gated on callRecordingEnabled.
      if (p === "/api/callrec/finalize" && req.method === "POST") return await callRecFinalize(req, env, ctx);
      // [CALLREC-UPLOAD-1] Resumable lane for long recordings — a 3-hour call is
      // ~33 MB, which does not survive a single-shot base64 POST on mobile. R2
      // multipart; ownership rides on the key's `u/<uid>/` prefix (callrec.ts).
      if (p === "/api/callrec/upload/begin" && req.method === "POST") return await callRecUploadBegin(req, env, ctx);
      if (p === "/api/callrec/upload/part" && req.method === "PUT") return await callRecUploadPart(req, env, ctx);
      if (p === "/api/callrec/upload/complete" && req.method === "POST") return await callRecUploadComplete(req, env, ctx);
      if (p === "/api/callrec/upload/abort" && req.method === "POST") return await callRecUploadAbort(req, env, ctx);
      // PATCH is the contract; POST is accepted as an alias because util.ts's shared
      // CORS header advertises GET,POST,PUT,DELETE,OPTIONS only — a browser client
      // would fail the PATCH preflight, and util.ts is not this issue's file to change.
      if (p === "/api/callrec/meta" && (req.method === "PATCH" || req.method === "POST")) return await callRecMeta(req, env, ctx);
      if (p === "/api/callrec/delete" && req.method === "POST") return await callRecDelete(req, env, ctx);
      if (p === "/api/callrec/playback" && req.method === "GET") return await callRecPlayback(req, env, ctx);
      // [ADDCALL-1-SRV] Add-to-call room creation/extension. Exact-string matches
      // on their own /api/adhoc-room/ prefix: they cannot shadow, or be shadowed
      // by, the /api/groupcall/<id>/<verb> regex above (different first segment,
      // and that regex's <verb> group is a closed list). Both handlers gate on
      // addToCallEnabled themselves and 403 while it is off.
      if (p === "/api/adhoc-room/create" && req.method === "POST") return await adhocRoomCreate(req, env, ctx);
      if (p === "/api/adhoc-room/add" && req.method === "POST") return await adhocRoomAdd(req, env, ctx);
      // PSTN gateway + voicemail execution mode (Canonical Architecture v1.0,
      // Specs/PLAN-2026-07-16-ava-receptionist-guardian-FINAL.md). Single
      // startsWith dispatcher — routes/pstn.ts parses the sub-path itself.
      if (p.startsWith("/api/pstn/")) return await pstnRoute(req, env, p);
      // [AVA-CAMP-B2-WIRE] Outbound AI calling campaigns (dark behind
      // campaignDialerEnabled). campaign-pstn (per-call PSTN bridge) is checked
      // before the broader campaigns CRUD matcher — the two prefixes never
      // actually collide ("/api/campaign-pstn/" vs "/api/campaigns" diverge at
      // the 15th char), but ordering the more specific path first keeps the
      // precedence obviously correct as routes are added later.
      if (p.startsWith("/api/campaign-pstn/")) return await campaignPstnRoute(req, env, p);
      // [AVA-CAMP-C-WIRE] Campaign KB (per-campaign upload/list/clear) — checked
      // before the broader /api/campaigns CRUD matcher so it isn't swallowed.
      if (/^\/api\/campaigns\/[^/]+\/kb(\/|$|\?|#)/.test(p)) return await campaignKbRoute(req, env, p);
      // [AVA-CAMP-Q-VOICES] AI-voice catalog + preview — fixed literal segment
      // ("/voices"), so it must precede the /:id/... patterns just like /dids
      // and /analytics/account below, and must precede the generic
      // /api/campaigns CRUD matcher so it isn't swallowed.
      if (/^\/api\/campaigns\/voices(\/|$|\?|#)/.test(p)) return await campaignVoicesRoute(req, env, p);
      // [AVA-CAMP-D-*] specific campaign sub-routes, all checked before the
      // generic /api/campaigns CRUD matcher so they aren't swallowed. Note
      // /dids and /analytics/account use fixed literal segments (never a :id),
      // so they must precede the /:id/... patterns.
      if (/^\/api\/campaigns\/dids(\/|$|\?|#)/.test(p)) return await campaignDidsRoute(req, env, p);
      if (/^\/api\/campaigns\/analytics\/account(\/|$|\?|#)/.test(p)) return await campaignAnalyticsRoute(req, env, p);
      if (/^\/api\/campaigns\/[^/]+\/analytics(\/|$|\?|#)/.test(p)) return await campaignAnalyticsRoute(req, env, p);
      if (/^\/api\/campaigns\/[^/]+\/contacts(\/|$|\?|#)/.test(p)) return await campaignContactsRoute(req, env, p);
      if (p.startsWith("/api/campaigns")) return await campaignsRoute(req, env, p);
      // [TEL-TIERS-1] Telephony subscription tiers (Phase 4, Specs/PLAN-2026-07-19-
      // tokens-cockpit-pstn-master.md): ₹700 Tier-1 / ₹2,500 Tier-2 / ₹700 add-on,
      // token-charged, lazy monthly renewal. Concurrency gauges live in pstn.ts.
      if (p === "/api/telephony/subscribe" && req.method === "POST") return await telephonySubscribe(req, env);
      if (p === "/api/telephony/addon" && req.method === "POST") return await telephonyAddon(req, env);
      if (p === "/api/telephony/cancel" && req.method === "POST") return await telephonyCancel(req, env);
      if (p === "/api/telephony/status" && req.method === "GET") return await telephonyStatus(req, env);
      // [WP3] Agent Profiles + service numbers (plan §4/§7/§8b/§12.5/§12.8/§12.10).
      // Mode A (primary number) settings — 403 unless voiceAgent flag is on.
      if (p === "/api/agent/settings" && req.method === "GET") return await getAgentSettings(req, env);
      if (p === "/api/agent/settings" && req.method === "PUT") return await putAgentSettings(req, env);
      // Mode B (service numbers) — 403 unless serviceNumbers flag is on.
      if (p === "/api/agent/services" && req.method === "GET") return await listAgentServices(req, env);
      if (p === "/api/agent/services" && req.method === "POST") return await createAgentService(req, env);
      if (p === "/api/agent/services" && req.method === "PUT") return await updateAgentService(req, env);
      if (p === "/api/agent/services" && req.method === "DELETE") return await deleteAgentService(req, env);
      // Caller-side "My AI calls" style read for the OWNER (plan §12.11 covers
      // the caller's own view; this is the owner's call log).
      if (p === "/api/agent/my-calls" && req.method === "GET") return await listAgentCalls(req, env);
      // GAP-2: caller-side full transcript for one of MY calls (§12.11 detail
      // view). Path-segment route — mirrors the /api/team/members/<id> pattern
      // above (startsWith + slice), since call_id is a UUID, not a query param.
      if (p.startsWith("/api/agent/my-calls/") && req.method === "GET") {
        return await getAgentCallTranscript(req, env, decodeURIComponent(p.slice("/api/agent/my-calls/".length)));
      }

      // [WP4] Ava AI Voice Agent — call start + RAG document pipeline (plan §4/§5/§8/§9).
      if (p === "/api/agent/call/start" && req.method === "POST") return await agentCallStart(req, env);
      if (p === "/api/agent/docs" && req.method === "POST") return await uploadAgentDoc(req, env);
      if (p === "/api/agent/docs" && req.method === "GET") return await listAgentDocs(req, env);
      if (p === "/api/agent/docs" && req.method === "DELETE") return await deleteAgentDoc(req, env);
      // [DIALPAD-BIZ-CALLS] Account-level silent block (plan §15.2). The
      // Flutter BlockingApi posts {uid} here; reuse the SAME `blocks` table
      // messaging already writes (routes/safety.ts convBlock) — one blocklist
      // for messaging AND business calls (voicemail/agent/ring all read it).
      if (p === "/api/block" && req.method === "POST") return await convBlock(req, env);
      // [LASTSEEN-SERVER-1] WhatsApp-style last seen (InboxDO socket truth).
      if (p === "/api/user/last-seen" && req.method === "GET") return await api.userLastSeen(req, env);

      // --- contacts ---
      if (p === "/api/contacts/sync" && req.method === "POST") return await api.contactsSync(req, env);
      if (p === "/api/contacts/match" && req.method === "POST") return await api.contactsMatch(req, env);
      // [AVA-MISSEDCALL-1] device-token lane so the overlay can confirm AvaTOK membership
      // while the app is dead (no Clerk JWT). Dark behind missedCallOverlay.
      if (p === "/api/missedcall/token" && req.method === "POST") return await missedCallToken(req, env);
      if (p === "/api/missedcall/lookup" && req.method === "POST") return await missedCallLookup(req, env);
      if (p === "/api/contacts/list" && req.method === "GET") return api.contactsList();
      // Contact-book backup/restore — AvaTOK's own encrypted backup lane (no Gmail
      // needed, server-side encrypted, free). See routes/contacts_backup.ts.
      if (p === "/api/contacts/book/status" && req.method === "GET") return await cbook.contactBookStatus(req, env);
      if (p === "/api/contacts/book" && req.method === "GET") return await cbook.contactBookGet(req, env);
      if (p === "/api/contacts/book" && req.method === "POST") return await cbook.contactBookPut(req, env, ctx);
      if (p === "/api/contacts/call-policy" && req.method === "POST") return await cbook.contactCallPolicyPut(req, env);

      // --- communities ---
      if (p === "/api/community" && req.method === "POST") return await api.communityUpsert(req, env);
      if (p === "/api/community/join" && req.method === "POST") return await api.communityJoin(req, env);
      if (p === "/api/communities" && req.method === "GET") return await api.communities(req, env);

      // --- media (NIP-98) ---
      if (p === "/api/media/private-read" && req.method === "GET") return await privateMediaRead(req, env);
      if (p === "/upload/public" && req.method === "POST") return await uploadPublic(req, env, ctx);
      if (p === "/upload/private" && req.method === "POST") return await uploadPrivate(req, env, ctx);
      if (p === "/api/media/commit" && req.method === "POST") return await mediaCommit(req, env, ctx);
      if (p === "/api/library" && req.method === "GET") return await getLibrary(req, env);
      if (p === "/api/library/tree" && req.method === "GET") return await getLibraryTree(req, env);
      if (p === "/api/library/folders/move" && req.method === "POST") return await libraryFolderMove(req, env);
      if (p === "/api/library/folders/copy" && req.method === "POST") return await libraryFolderCopy(req, env);
      if (p === "/api/library/folders") return await libraryFolders(req, env);
      if (p === "/api/library/move" && req.method === "POST") return await libraryMove(req, env);
      if (p === "/api/library/copy" && req.method === "POST") return await libraryCopy(req, env);
      if (p === "/api/library/delete" && req.method === "POST") return await libraryDelete(req, env, ctx);
      if (p === "/api/library/record" && req.method === "POST") return await libraryRecord(req, env, ctx);
      if (p === "/api/storage" && req.method === "GET") return await getStorage(req, env);
      if (p === "/api/storage/summary" && req.method === "GET") return await getStorageSummary(req, env);

      // --- backup ---
      if (p === "/api/backup" && req.method === "POST") return await api.backup(req, env);

      // --- AvaID ---
      if (p === "/api/id/status" && req.method === "GET") return await idStatus(req, env);
      // Onboarding contact verification — email (server OTP) + password.
      // PHONE OTP REMOVED 2026-07-10 (/api/id/phone/confirm) — see LEGACY_GONE below.
      if (p === "/api/id/email/start" && req.method === "POST") return await idEmailStart(req, env);
      if (p === "/api/id/email/verify" && req.method === "POST") return await idEmailVerify(req, env);
      if (p === "/api/id/password/start" && req.method === "POST") return await idPasswordStart(req, env);
      if (p === "/api/id/password/set" && req.method === "POST") return await idPasswordSet(req, env);

      // [AVA-IDGATE-1] LEGACY TRUST-MINTING ROUTES — CLOSED 2026-07-10.
      //
      // Each of these called setVerifiedCache(uid, true), i.e. each was a door onto
      // the SAME "this user is verified" switch that the whole deterrence model rests
      // on. Didit replaced them as the liveness provider, but they stayed registered:
      // an old client, a bug, or a direct request could mark a user verified WITHOUT
      // any liveness check ever running. That is a bypass, not dead code.
      //
      //   /api/id/session,  /api/id/result          → id.ts        (Rekognition)
      //   /api/id/liveness/{start,upload,verify,result} → liveness.ts   (Workers AI)
      //   /api/liveness/v3/{session,upload,verify,result} → liveness_v3.ts
      //   /api/id/phone/confirm                     → id.ts        (phone OTP, removed)
      //
      // 410 Gone, not 404 — an old client deserves a distinguishable answer, and the
      // telemetry tells us whether anyone is still calling. `legacy_liveness_route_called`
      // MUST be zero in PostHog. Non-zero ⇒ an old client in the wild, or someone
      // probing. Alert on it; do not batch.
      if (LEGACY_GONE.has(p)) {
        void hooks.track(env, "anon", "legacy_liveness_route_called", "avatok", { path: p, method: req.method });
        return new Response(JSON.stringify({ error: "gone", reason: "liveness_provider_migrated" }), {
          status: 410, headers: { "content-type": "application/json" },
        });
      }

      // [LIVE-DIDIT-1] didit.me-powered liveness (owner decision 2026-07-09) —
      // the ONLY liveness path. v2/v3/Rekognition are closed above.
      // [AVA-IDGATE-1] BIPA consent — MUST precede a capture session (spec §10.4).
      if (p === "/api/liveness/consent" && req.method === "POST") return await livenessConsent(req, env);
      if (p === "/api/liveness/didit/session" && req.method === "POST") return await diditSession(req, env);
      if (p === "/api/liveness/didit/result" && req.method === "GET") return await diditResult(req, env);
      if (p === "/api/liveness/didit/done" && req.method === "GET") return diditDone();
      if (p === "/api/liveness/didit/webhook" && req.method === "POST") return await diditWebhook(req, env);
      // [CONNECT-RETURN-1] Composio OAuth return → deep-links back into the app.
      if (p === "/api/connectors/done" && req.method === "GET") return connectorsDone(req);
      // Progressive Identity ladder — guest tier (no auth) + level (Clerk auth).
      if (p === "/api/identity/guest" && req.method === "POST") return await guestCreate(req, env);
      if (p === "/api/identity/guest/check" && req.method === "GET") return await guestHandleCheck(req, env);
      if (p === "/api/identity/upgrade" && req.method === "POST") return await guestUpgrade(req, env);
      if (p === "/api/identity/level" && req.method === "GET") return await getIdentityLevel(req, env);
      // Phase 3 — Stripe Identity webhook (second KYC provider, same gateway)
      // + A1 agreement acceptance (creator agreement before first withdrawal).
      if ((p === "/webhooks/stripe-identity" || p === "/api/identity/stripe-webhook") && req.method === "POST") return await stripeIdentityWebhook(req, env);
      if (p === "/api/agreements/status" && req.method === "GET") return await agreementStatus(req, env);
      if (p === "/api/agreements/doc" && req.method === "GET") return await agreementDoc(req, env);
      if (p === "/api/agreements/accept" && req.method === "POST") return await agreementAccept(req, env);

      // --- AvaWallet (Phase 2; balance authority = WalletDO) ---
      // --- Subscribe (Phase 1 tiers: Free/Plus/Pro/Max) — gated by billingEnabled.
      // Stripe subscription events land on the shared /webhooks/stripe endpoint.
      if (p === "/api/subscribe/plans" && req.method === "GET") return await getPlans(req, env);
      if (p === "/api/subscribe/checkout" && req.method === "POST") return await subscribeCheckout(req, env);
      if (p === "/api/subscribe/android/verify" && req.method === "POST") return await subscribeAndroidVerify(req, env);
      if (p === "/api/subscribe/cancel" && req.method === "POST") return await subscribeCancel(req, env);
      if (p === "/api/wallet/topup/intent" && req.method === "POST") return await walletTopupIntent(req, env);
      if (p === "/api/wallet/topup/play/verify" && req.method === "POST") return await walletTopupPlayVerify(req, env);
      if (p === "/api/wallet/topup" && req.method === "POST") return await walletTopup(req, env);
      // [PAY-CASHFREE-1] Inbound UPI — pay for a ticket in rupees with no wallet top-up.
      // The webhook is deliberately NOT under requireUser: Cashfree authenticates with a
      // signature over the raw body, which cashfreeWebhook verifies before parsing it.
      if (p === "/api/pay/cashfree/order" && req.method === "POST") return await cashfreeCreateOrder(req, env);
      if (p === "/api/pay/cashfree/webhook" && req.method === "POST") return await cashfreeWebhook(req, env);
      if (p === "/api/pay/cashfree/status" && req.method === "GET") return await cashfreeStatus(req, env);
      // [PAY-RAIL-1] Generic multi-gateway routes — Razorpay, Paytm, Stripe (intl), and
      // Cashfree wired for completeness (lib/payments/registry.ts). Placed AFTER the
      // literal /api/pay/cashfree/* checks above, so those keep taking priority for that
      // exact path and this generic form never shadows the dedicated Cashfree lane.
      // The webhook is deliberately NOT under requireUser, same reasoning as Cashfree's:
      // each gateway authenticates with its own signature over the raw body, verified by
      // the adapter's verifyWebhook() before anything parses it.
      if (p === "/api/pay/methods" && req.method === "GET") return await payMethods(req, env);
      {
        const pm = p.match(/^\/api\/pay\/([a-z]+)\/order$/);
        if (pm && req.method === "POST") return await payCreateOrder(req, env, pm[1]);
        const pw = p.match(/^\/api\/pay\/([a-z]+)\/webhook$/);
        if (pw && req.method === "POST") return await payWebhook(req, env, pw[1]);
        const ps = p.match(/^\/api\/pay\/([a-z]+)\/status$/);
        if (ps && req.method === "GET") return await payStatus(req, env, ps[1]);
      }
      if ((p === "/webhooks/stripe" || p === "/api/wallet/stripe-webhook") && req.method === "POST") return await stripeWebhook(req, env);
      if (p === "/api/wallet/spend" && req.method === "POST") return await walletSpend(req, env);
      // --- AvaReferral (invite → coins; inviter-only, server-priced reward) ---
      if (p === "/api/referral/claim" && req.method === "POST") return await referralClaim(req, env);
      if (p === "/api/referral/summary" && req.method === "GET") return await referralSummary(req, env);
      if (p === "/api/invite/email" && req.method === "POST") return await inviteEmail(req, env);
      if (p === "/api/feature/costs" && req.method === "GET") return await featureCostsRoute(req, env);
      if (p === "/api/auth/google" && req.method === "POST") return await googleAuth(req, env, ctx);
      if (p === "/api/wallet/balance" && req.method === "GET") return await walletBalance(req, env);
      if (p === "/api/wallet/transactions" && req.method === "GET") return await walletTransactions(req, env);
      // [WALLET-COCKPIT-1] Cockpit wallet reads: labeled statement + aggregates.
      if (p === "/api/wallet/statement" && req.method === "GET") return await walletStatement(req, env);
      if (p === "/api/wallet/activity" && req.method === "GET") return await walletActivity(req, env); // [WALLET-ACTIVITY-DETAIL-1]
      // [WALLET-REDESIGN-1] CSV export of the statement (share/save from the app).
      if (p === "/api/wallet/statement/export" && req.method === "GET") return await walletStatementExport(req, env);
      if (p === "/api/wallet/summary" && req.method === "GET") return await walletSummary(req, env);
      // [TOKENS-FX-1] Region-aware top-up quote (INR fixed 1:1 for India; USD elsewhere).
      if (p === "/api/wallet/topup-quote" && req.method === "GET") return await walletTopupQuote(req, env);
      if (p === "/api/wallet/earnings" && req.method === "GET") return await walletEarnings(req, env);
      if (p === "/api/wallet/live" && req.headers.get("Upgrade") === "websocket") return await walletLive(req, env);
      // Double-entry ledger reads + receipts (Phase 2 marketplace plan).
      if (p === "/api/wallet/ledger" && req.method === "GET") return await walletLedger(req, env);
      {
        const lr = p.match(/^\/api\/wallet\/ledger\/([A-Za-z0-9:._-]{1,240})\/receipt$/); // [WALLET-ACTIVITY-DETAIL-1] commercial ids are ~99 chars
        if (lr && req.method === "POST") return await walletReceiptResend(req, env, lr[1]);
        const ld = p.match(/^\/api\/wallet\/ledger\/([A-Za-z0-9:._-]{1,240})$/);
        if (ld && req.method === "GET") return await walletLedgerDetail(req, env, ld[1]);
      }
      // Money ops console (Phase 2 A2; admin-only, audit-logged).
      if (p === "/api/admin/ledger" && req.method === "GET") return await adminLedger(req, env);
      if (p === "/api/admin/refund" && req.method === "POST") return await adminRefund(req, env);
      if (p === "/api/admin/adjust" && req.method === "POST") return await adminAdjust(req, env);
      if (p === "/api/admin/recon" && req.method === "GET") return await adminRecon(req, env);
      if (p === "/api/admin/commercial/diagnostics" && req.method === "GET") return await commercialDiagnostics(req, env);
      // [STREAM-CALLTYPES-1] Idempotently create avatok_livestream / avatok_consult_1to1
      // on the GetStream app. Admin-only; creates nothing that already exists.
      if (p === "/api/admin/stream/calltypes/ensure" && req.method === "POST") return await ensureStreamCallTypes(req, env);
      // [COMM-REFUND-POL-1] The screen behind review_pending. Before this there was no
      // route anywhere that could move a commercial settlement job out of that state.
      if (p === "/api/admin/commercial/claims" && req.method === "GET") return await adminCommercialClaims(req, env);
      {
        const cc = p.match(/^\/api\/admin\/commercial\/claims\/([A-Za-z0-9:_-]{1,128})$/);
        if (cc && req.method === "POST") return await adminResolveCommercialClaim(req, env, cc[1]);
      }
      if (p === "/api/admin/tax-export" && req.method === "GET") return await adminTaxExport(req, env);
      if (p === "/api/admin/escrow/hold" && req.method === "POST") return await adminEscrowHold(req, env);
      if (p === "/api/admin/escrow/release" && req.method === "POST") return await adminEscrowRelease(req, env);
      // [WELCOME-100-1] One-time retroactive welcome-bonus backfill (idempotent
      // per uid). Bare path = ADMIN_UIDS Clerk bearer; trailing segment = the
      // WELCOME_BACKFILL_SECRET shared secret (fails closed when unset).
      if (p === "/api/admin/welcome-backfill" && req.method === "POST") return await welcomeBackfill(req, env);
      {
        const wb = p.match(/^\/api\/admin\/welcome-backfill\/([A-Za-z0-9_-]{16,128})$/);
        if (wb && req.method === "POST") return await welcomeBackfill(req, env, wb[1]);
      }
      // [TOKENS-100-GRANT-1] One-time DESTRUCTIVE token hard reset (every user → 100,
      // idempotent per uid). Same auth scheme as welcome-backfill: bare path =
      // ADMIN_UIDS Clerk bearer; trailing segment = TOKEN_RESET_SECRET (fails closed).
      if (p === "/api/admin/token-hard-reset" && req.method === "POST") return await tokenHardResetBackfill(req, env);
      {
        const tr = p.match(/^\/api\/admin\/token-hard-reset\/([A-Za-z0-9_-]{16,128})$/);
        if (tr && req.method === "POST") return await tokenHardResetBackfill(req, env, tr[1]);
      }

      // --- AvaAdmin dashboard (Phase 6) — read-mostly aggregation + alerts/roles. requireAdmin enforced inside. ---
      if (p === "/api/admin/overview" && req.method === "GET") return await adminOverview(req, env);
      if (p === "/api/admin/listings" && req.method === "GET") return await adminListings(req, env);
      // [WEB-ACCOUNT-1] The row a web signup never created, plus the phone.
      // Idempotent; safe to call repeatedly. [WEB-APP-ONBOARD-1] It no longer
      // assigns an AvaTOK number — the app's gate does, so the free number
      // survives for the user to actually choose.
      if (p === "/api/account/bootstrap" && req.method === "POST") return await webAccountBootstrap(req, env);
      // [WEB-PHONE-OTP-1 2026-09-10] SMS OTP (2Factor) for web sign-up phone verification.
      if (p === "/api/account/phone/send" && req.method === "POST") return await phoneOtpSend(req, env);
      if (p === "/api/account/phone/verify" && req.method === "POST") return await phoneOtpVerify(req, env);
      if (p === "/api/account/phone/status" && req.method === "GET") return await phoneOtpStatus(req, env);
      // [WEB-APP-ONBOARD-1] The app reporting that a web-born account has now
      // been through onboarding. This is the only thing that lifts the gate.
      if (p === "/api/account/app-onboarded" && req.method === "POST") return await webAccountAppOnboarded(req, env);
      { const m = p.match(/^\/api\/admin\/listings\/([A-Za-z0-9-]{1,64})$/); if (m && req.method === "GET") return await adminListingDetail(req, env, m[1]); if (m && req.method === "POST") return await adminListingAction(req, env, m[1]); if (m && req.method === "PUT") return await adminEditListing(req, env, m[1]); if (m && req.method === "DELETE") return await adminPurgeListing(req, env, m[1]); }
      // [REVIEW-MOD-1] Review moderation queue. Reviews land 'pending' and are
      // invisible to the public until approved here — see routes/admin_reviews.ts.
      if (p === "/api/admin/reviews" && req.method === "GET") return await adminReviews(req, env);
      { const rm = p.match(/^\/api\/admin\/reviews\/([A-Za-z0-9-]{1,64})$/); if (rm && req.method === "POST") return await adminReviewAction(req, env, rm[1]); }
      if (p === "/api/admin/live" && req.method === "GET") return await adminLive(req, env);
      if (p === "/api/admin/agents" && req.method === "GET") return await adminAgents(req, env);
      if (p === "/api/admin/health" && req.method === "GET") return await adminHealth(req, env);
      if (p === "/api/admin/analytics" && req.method === "GET") return await adminAnalytics(req, env);
      if (p === "/api/admin/audit" && req.method === "GET") return await adminAuditLog(req, env);
      if (p === "/api/admin/users/search" && req.method === "GET") return await adminUserSearch(req, env);
      if (p === "/api/admin/alerts" && req.method === "GET") return await adminAlerts(req, env);
      if (p === "/api/admin/alerts/evaluate" && req.method === "POST") return await adminAlertEvaluate(req, env);
      { const m = p.match(/^\/api\/admin\/alerts\/([A-Za-z0-9-]{1,64})\/ack$/); if (m && req.method === "POST") return await adminAlertAck(req, env, m[1]); }
      { const m = p.match(/^\/api\/admin\/alerts\/([A-Za-z0-9-]{1,64})\/resolve$/); if (m && req.method === "POST") return await adminAlertResolve(req, env, m[1]); }
      if (p === "/api/admin/alert-rules" && (req.method === "GET" || req.method === "POST")) return await adminAlertRules(req, env);
      { const m = p.match(/^\/api\/admin\/alert-rules\/([A-Za-z0-9-]{1,64})$/); if (m && (req.method === "PUT" || req.method === "DELETE")) return await adminAlertRuleMutate(req, env, m[1]); }
      if (p === "/api/admin/roles" && req.method === "GET") return await adminRoles(req, env);
      { const m = p.match(/^\/api\/admin\/roles\/([A-Za-z0-9_-]{1,64})$/); if (m && req.method === "PUT") return await adminRoleSet(req, env, m[1]); }
      {
        const aa = p.match(/^\/api\/admin\/account\/([A-Za-z0-9_-]{1,64})$/);
        if (aa && req.method === "GET") return await adminAccount(req, env, aa[1]);
      }

      // --- AvaCalendar + AvaBooking (Phase 5: conflict engine, gcal sync,
      // policies, reschedule flow, public join links) ---
      if (p === "/api/time" && req.method === "GET") return getTime();
      // [AVAILABILITY-1] One listing-aware schedule shared by web and native.
      if (p === "/api/calendar/schedule" && req.method === "GET") return await getAvailabilitySchedule(req, env);
      if (p === "/api/calendar/schedule" && req.method === "PUT") return await putAvailabilitySchedule(req, env);
      if (p === "/api/calendar/conflicts/preview" && req.method === "POST") return await previewAvailabilityConflicts(req, env);
      const availabilityListing = p.match(/^\/api\/listings\/([A-Za-z0-9-]{1,64})\/availability$/);
      if (availabilityListing && req.method === "GET") return await getListingAvailability(req, env, availabilityListing[1]);
      if (p === "/api/calendar/slots" && req.method === "POST") return await createSlot(req, env);
      if (p === "/api/calendar/slots" && req.method === "GET") return await listSlots(req, env);
      const cs = p.match(/^\/api\/calendar\/slots\/([A-Za-z0-9-]{1,64})$/);
      if (cs && req.method === "DELETE") return await cancelSlot(req, env, cs[1]);
      if (p === "/api/calendar/book" && req.method === "POST") return await bookSlot(req, env);
      if (p === "/api/calendar/cancel" && req.method === "POST") return await cancelBooking(req, env);
      if (p === "/api/calendar/events" && req.method === "GET") return await listEvents(req, env);
      if (p === "/api/calendar/blocks" && req.method === "GET") return await listBlocks(req, env);
      if (p === "/api/calendar/rules" && req.method === "GET") return await getRules(req, env);
      if (p === "/api/calendar/rules" && req.method === "PUT") return await putRules(req, env);
      if (p === "/api/calendar/gcal/connect" && req.method === "GET") return await gcalConnect(req, env);
      if (p === "/api/calendar/gcal/callback" && req.method === "GET") return await gcalCallback(req, env);
      if (p === "/api/calendar/gcal/calendars" && req.method === "GET") return await gcalCalendars(req, env);
      if (p === "/api/calendar/gcal/calendars" && req.method === "PUT") return await gcalSaveCalendars(req, env);
      if (p === "/api/calendar/gcal/status" && req.method === "GET") return await gcalStatus(req, env);
      if (p === "/api/calendar/gcal" && req.method === "DELETE") return await gcalDisconnect(req, env);
      if (p === "/webhooks/gcal" && req.method === "POST") return await gcalWebhook(req, env);
      if (p === "/api/booking/list" && req.method === "GET") return await listBookings(req, env);
      if (p === "/api/booking/policies" && req.method === "GET") return await getPolicies(req, env);
      if (p === "/api/booking/policies" && req.method === "PUT") return await putPolicies(req, env);
      if (p === "/api/booking/reschedules" && req.method === "GET") return await listReschedules(req, env);
      {
        const rr = p.match(/^\/api\/booking\/reschedule\/([A-Za-z0-9-]{1,64})\/respond$/);
        if (rr && req.method === "POST") return await respondReschedule(req, env, rr[1]);
        const pr = p.match(/^\/api\/booking\/([A-Za-z0-9-]{1,64})\/reschedule$/);
        if (pr && req.method === "POST") return await proposeReschedule(req, env, pr[1]);
        const ji = p.match(/^\/api\/join-info\/([A-Za-z0-9._-]{1,512})$/);
        if (ji && req.method === "GET") return await joinInfo(req, env, ji[1]);
        // [JOIN-LINK-1] The emailed link's own entry point: verify the signed
        // token and hand back a Clerk sign-in ticket + the room path, so the
        // customer is never asked to log in (RULEBOOK-PAID-SESSIONS §7).
        const jl = p.match(/^\/api\/join-link\/([A-Za-z0-9._-]{1,512})\/session$/);
        if (jl && req.method === "POST") return await joinLinkSession(req, env, jl[1]);
      }

      // [AGENT-LIVE-1] AI voice agent listings on GPT-Live-1 — one dispatcher
      // owns everything under /api/agents (Specs/SPEC-2026-09-12-AGENT-LIVE-1-
      // BUILD.md §3/§9). Checked early so its own regex table doesn't have to
      // compete with the generic routes below.
      if (p.startsWith("/api/agents")) {
        const agentLiveResp = await routeAgentLive(req, env, ctx, url);
        if (agentLiveResp) return agentLiveResp;
      }

      // --- AvaPayout (Phase 4; production transfers flag-gated pending legal) ---
      if (p === "/api/payout/setup" && req.method === "POST") return await payoutSetup(req, env);
      if (p === "/api/payout/accounts" && req.method === "GET") return await payoutAccounts(req, env);
      if (p === "/api/payout/request" && req.method === "POST") return await payoutRequest(req, env);
      if (p === "/api/payout/status" && req.method === "GET") return await payoutStatus(req, env);
      if (p === "/api/payout/upi/account" && req.method === "POST") return await upiAccount(req, env);
      if (p === "/api/payout/upi/account" && req.method === "GET") return await upiAccountGet(req, env);
      if (p === "/api/payout/upi/quote" && req.method === "GET") return await upiPayoutQuote(req, env);
      if (p === "/api/payout/upi/request" && req.method === "POST") return await upiPayoutRequest(req, env);
      if (p === "/api/payout/upi/requests" && req.method === "GET") return await upiPayoutRequests(req, env);
      if (p === "/api/admin/payouts/upi" && req.method === "GET") return await adminUpiPayouts(req, env);
      { const m = p.match(/^\/api\/admin\/payouts\/upi\/account\/([A-Za-z0-9-]{8,64})\/verify$/); if (m && req.method === "POST") return await adminUpiAccountVerify(req, env, m[1]); }
      { const m = p.match(/^\/api\/admin\/payouts\/upi\/([A-Za-z0-9-]{8,64})\/(approve|reject|paid|reconcile)$/); if (m && req.method === "POST") {
        const fn: any = { approve: adminUpiApprove, reject: adminUpiReject, paid: adminUpiPaid, reconcile: adminUpiReconcile }[m[2]];
        return await fn(req, env, m[1]);
      } }
      if (p === "/webhooks/wise" && req.method === "POST") return await wiseWebhook(req, env);

      // --- AvaOLX (Phase 5; browse open, list/sell Tier-2) ---
      if (p === "/api/olx/listings" && req.method === "POST") return await olxCreate(req, env);
      if (p === "/api/olx/listings" && req.method === "GET") return await olxBrowse(req, env);
      if (p === "/api/olx/buy" && req.method === "POST") return await olxBuy(req, env);
      if (p === "/api/olx/refund" && req.method === "POST") return await olxRefund(req, env);
      if (p === "/api/olx/downloads" && req.method === "GET") return await olxDownloads(req, env);
      const odl = p.match(/^\/api\/olx\/downloads\/([A-Za-z0-9-]{1,64})\/file$/);
      if (odl && req.method === "GET") return await olxDownloadFile(req, env, odl[1]);
      const olf = p.match(/^\/api\/olx\/listings\/([A-Za-z0-9-]{1,64})\/file$/);
      if (olf && req.method === "POST") return await olxUploadFile(req, env, olf[1]);
      const olm = p.match(/^\/api\/olx\/listings\/([A-Za-z0-9-]{1,64})$/);
      if (olm && req.method === "GET") return await olxGet(req, env, olm[1]);
      if (olm && req.method === "PUT") return await olxUpdate(req, env, olm[1]);
      if (olm && req.method === "DELETE") return await olxDelete(req, env, olm[1]);

      // --- AvaBrain Agentic layer (Phase 7) ---
      if (p === "/api/agent/personas" && req.method === "GET") return await listPersonas(req, env);
      const ap = p.match(/^\/api\/agent\/personas\/([a-z0-9]{1,32})$/);
      if (ap && req.method === "PUT") return await upsertPersona(req, env, ap[1]);
      if (p === "/api/agent/converse" && req.method === "POST") return await converse(req, env);
      if (p === "/api/agent/inbox" && req.method === "GET") return await getInbox(req, env);
      const ai = p.match(/^\/api\/agent\/inbox\/([A-Za-z0-9-]{1,64})$/);
      if (ai && req.method === "GET") return await getInboxItem(req, env, ai[1]);
      if (p === "/api/agent/approve" && req.method === "POST") return await approveInbox(req, env);
      if (p === "/api/agent/task" && req.method === "POST") return await agentTask(req, env);
      if (p === "/api/agent/tts" && req.method === "POST") return await agentTts(req, env);
      const aa = p.match(/^\/api\/agent\/audio\/([A-Za-z0-9-]{1,64})$/);
      if (aa && req.method === "GET") return await agentAudio(req, env, aa[1]);

      // --- account deletion (right-to-erasure; 30-day grace → queue cascade) ---
      if (p === "/api/account/delete" && (req.method === "POST" || req.method === "DELETE")) return await deleteAccount(req, env);
      if (p === "/api/account/delete/cancel" && req.method === "POST") return await cancelDeletion(req, env);
      // [ADMIN-DELETE-USER-1] Admin deletes ANOTHER user, IMMEDIATELY (no 30-day grace):
      // same 15-store cascade for a target {uid}. Bare path = ADMIN_UIDS Clerk bearer;
      // trailing segment = ADMIN_DELETE_SECRET (fails closed). Refuses to delete admins.
      if (p === "/api/admin/delete-user" && req.method === "POST") return await adminDeleteUser(req, env);
      {
        const du = p.match(/^\/api\/admin\/delete-user\/([A-Za-z0-9_-]{16,128})$/);
        if (du && req.method === "POST") return await adminDeleteUser(req, env, du[1]);
      }
      // [AVADIAL-CALL-INTEL-1] Batched call records from the native dialer, uploaded
      // after each call ends (or on next app boot when the user never opened it).
      if (p === "/api/telemetry/calls" && req.method === "POST") return await ingestCallTelemetry(req, env);
      if (p === "/api/account/deletion-status" && (req.method === "POST" || req.method === "GET")) return await deletionStatus(req, env);

      // --- Phase 8: AvaVerse dashboard (aggregation only, no new stores) ---
      if (p === "/api/verse/summary" && req.method === "GET") return await verseSummary(req, env);
      if (p === "/api/verse/announce" && req.method === "POST") return await verseAnnounce(req, env);
      if (p === "/api/verse/statement" && req.method === "GET") return await verseStatement(req, env);
      {
        // [LIST-CONTENT-2] replyReview/helpfulReview supersede the old Phase 8
        // reviewReply on this same path — see routes/reviews.ts header.
        const rr = p.match(/^\/api\/reviews\/([A-Za-z0-9-]{1,64})\/(reply|helpful)$/);
        if (rr) {
          const reviewId = rr[1], act = rr[2];
          if (act === "reply" && req.method === "POST") return await replyReview(req, env, reviewId);
          if (act === "helpful" && req.method === "POST") return await helpfulReview(req, env, reviewId);
        }
      }
      {
        // [LIST-ASK-1] "Ask the host" — creator answer + promote-to-FAQ (the
        // create/list routes live under /api/listings/:id/questions below, next
        // to the sibling reviews routes).
        const qa = p.match(/^\/api\/questions\/([A-Za-z0-9-]{1,64})\/(answer|promote)$/);
        if (qa) {
          const qid = qa[1], act = qa[2];
          if (act === "answer" && req.method === "POST") return await answerQuestion(req, env, qid);
          if (act === "promote" && req.method === "POST") return await promoteToFaq(req, env, qid);
        }
        if (p === "/api/questions/mine" && req.method === "GET") return await listMyQuestions(req, env);
        if (p === "/api/questions/inbox" && req.method === "GET") return await listCreatorQuestions(req, env);
      }

      // --- in-app notifications feed ---
      if (p === "/api/notifications" && req.method === "GET") return await listNotifications(req, env);
      if (p === "/api/notifications/unread" && req.method === "GET") return await unreadCount(req, env);
      if (p === "/api/notifications/read" && req.method === "POST") return await markRead(req, env);
      // [NOTIF-CLEAR-1] "Clear all" — destructive, so DELETE (never GET).
      if (p === "/api/notifications" && req.method === "DELETE") return await clearNotifications(req, env);

      // --- AvaBrain (dual auth; routes to the caller's UserBrain DO) ---
      // [ONEBRAIN-B0] Registry contract for the Settings UI (must precede the
      // generic /api/brain/:op matcher below, which would 404 a GET 'domains').
      if (p === "/api/brain/domains" && req.method === "GET") return await brainDomains(req, env);
      // [AVABRAIN-EXPORT-1] (Bible §6.1, §9.2) — must precede the generic
      // /api/brain/:op matcher below: 'export' would otherwise match that
      // single-segment pattern and 404 inside brain()'s switch (which has no
      // 'export' case, and must not gain one — this is its own opt-in-consent
      // producer, not a generic brain op).
      if (p === "/api/brain/export" && req.method === "POST") return await brainExport(req, env);
      const bm = p.match(/^\/api\/brain\/([a-z_]+)$/);
      if (bm) {
        const op = bm[1];
        const readOp = op === "entities" || op === "timeline" || op === "history";
        if ((op === "consent" || op === "settings") && (req.method === "GET" || req.method === "POST" || req.method === "PUT")) return await brain(req, env, op);
        if ((readOp && req.method === "GET") || (!readOp && req.method === "POST") || (op === "forget" && req.method === "DELETE")) {
          return await brain(req, env, op);
        }
      }

      // --- [AVABRAIN-MEDIA-1] daily audio/video "remember this" recordings ---
      // (Bible §9.2). Precede nothing else — these paths have an extra segment so
      // they never collide with the generic /api/brain/:op matcher above.
      if (p === "/api/brain/media/prepare" && req.method === "POST") return await brainMediaPrepare(req, env);
      if (p === "/api/brain/media/complete" && req.method === "POST") return await brainMediaComplete(req, env, ctx);
      {
        const bmm = p.match(/^\/api\/brain\/media\/([A-Za-z0-9-]{1,64})$/);
        if (bmm) {
          if (req.method === "GET") return await brainMediaStatus(req, env, bmm[1]);
          if (req.method === "DELETE") return await brainMediaDelete(req, env, bmm[1]);
        }
      }

      // --- [AVABRAIN-EXPORT-1] memory review/correction/forget/export screens ---
      // (Bible §P1.5, §9.3). Exact matches for the fixed-name sub-paths MUST
      // precede the /:id regex below, or "list"/"confirm"/"correct"/"export"
      // would themselves be captured as an :id.
      if (p === "/api/brain/memory/list" && req.method === "GET") return await brainMemoryList(req, env);
      if (p === "/api/brain/memory/confirm" && req.method === "POST") return await brainMemoryConfirm(req, env);
      if (p === "/api/brain/memory/correct" && req.method === "POST") return await brainMemoryCorrect(req, env);
      if (p === "/api/brain/memory/export" && req.method === "POST") return await brainMemoryExport(req, env);
      {
        const bmem = p.match(/^\/api\/brain\/memory\/([A-Za-z0-9-]{1,64})$/);
        if (bmem && req.method === "DELETE") return await brainMemoryDelete(req, env, bmem[1]);
      }

      // --- ICE (public read) ---
      if (p === "/api/ice" || p === "/ice") return await getIce(env);

      // --- Stream webhook (Cloudflare Stream Live events) ---
      if (p === "/webhooks/stream" && req.method === "POST") return await streamWebhook(req, env, ctx);
      // --- GetStream Video pilot (independent from Cloudflare Stream Live) ---
      if (p === "/webhooks/stream-video" && req.method === "POST") return await streamVideoWebhook(req, env, ctx);
      if (p === "/api/stream-video/token" && req.method === "GET") return await streamVideoToken(req, env);
      if (p === "/api/stream-video/prepare" && req.method === "POST") return await streamVideoPrepare(req, env, ctx);
      // [STREAM-AUTH-1 2026-08-21] Server authorisation for a streamlane 1:1
      // call. Stream carries the media; this route decides whether the call may
      // happen at all and mints the call id. See plan §8.1.
      if (p === "/api/stream-calls/place" && req.method === "POST") return await streamCallPlace(req, env, ctx);
      if (p === "/api/stream-calls/cancel" && req.method === "POST") return await streamCallCancel(req, env);

      // --- Phase 2 commercial GetStream lane (independent, all flags dark) ---
      if (/^\/api\/commercial\/orders\/[A-Za-z0-9-]{1,160}\/resend-confirmation$/.test(p)
          && (req.method === "POST" || req.method === "GET")) {
        return await resendCommercialConfirmation(req, env);
      }
      if ((/^\/api\/commercial\/consult\/[A-Za-z0-9-]{1,64}\/hold$/.test(p) || /^\/api\/listings\/[A-Za-z0-9-]{1,64}\/hold$/.test(p)) && req.method === "POST") return await commercialHold(req, env);
      if (/^\/api\/commercial\/(live|consult)\/[A-Za-z0-9-]{1,64}\/checkout$/.test(p) && req.method === "POST") {
        return await commercialCheckout(req, env);
      }
      if (/^\/api\/commercial\/(live|consult)\/[A-Za-z0-9-]{1,96}\/(cancel|reschedule|calendar)$/.test(p) && req.method === "POST") {
        return await commercialLifecycle(req, env);
      }
      // Commercial live admission returns short-lived GetStream credentials;
      // POST-only keeps provider tokens out of cacheable GET semantics.
      if (commercialRoutePattern("live", "join").test(p) && req.method === "POST") {
        return await commercialLiveJoin(req, env);
      }
      if (commercialRoutePattern("live", "prepare-host").test(p) && req.method === "POST") {
        return await commercialLivePrepareHost(req, env);
      }
      if (commercialRoutePattern("live", "go-live").test(p) && req.method === "POST") {
        return await commercialLiveGoLive(req, env);
      }
      if (commercialRoutePattern("live", "end").test(p) && req.method === "POST") {
        return await commercialLiveEnd(req, env);
      }
      if (commercialRoutePattern("live", "state").test(p) && req.method === "GET") {
        return await commercialLiveState(req, env);
      }
      if (commercialRoutePattern("consult", "prejoin").test(p) && req.method === "GET") {
        return await commercialConsultPrejoin(req, env);
      }
      if (commercialRoutePattern("consult", "join").test(p) && req.method === "POST") {
        return await commercialConsultJoin(req, env);
      }
      if (commercialRoutePattern("consult", "end").test(p) && req.method === "POST") {
        return await commercialConsultEnd(req, env);
      }
      if (commercialRoutePattern("consult", "state").test(p) && req.method === "GET") {
        return await commercialConsultState(req, env);
      }
      if (commercialRoutePattern("consult", "extend/quote").test(p) && req.method === "POST") {
        return await commercialConsultExtensionQuote(req, env);
      }
      if (commercialRoutePattern("consult", "extend/confirm").test(p) && req.method === "POST") {
        return await commercialConsultExtensionConfirm(req, env);
      }
      if (/^\/api\/commercial\/session\/[A-Za-z0-9_:-]{1,160}\/receipt$/.test(p) && req.method === "GET") {
        return await commercialReceipt(req, env);
      }
      // [APP-ONLY-TX-WORKER-RELAY-1] Session chat file upload (RULEBOOK §7) --
      // accepts a normal account OR the session's own room token (see the
      // route file's header comment for why that is today's guest lane).
      if (/^\/api\/commercial\/session\/(live|consult)\/[A-Za-z0-9][A-Za-z0-9-]{0,159}\/attachment$/.test(p) && req.method === "POST") {
        return await commercialSessionAttachmentUpload(req, env);
      }
      if (/^\/api\/commercial\/refund-receipt\/[A-Za-z0-9_:-]{1,160}$/.test(p) && req.method === "GET") {
        return await commercialRefundReceipt(req, env);
      }
      if (p === "/api/commercial/sessions/mine" && req.method === "GET") {
        return await commercialSessionsMine(req, env);
      }

      // --- Phase 7: AvaLive delivery (Stream Live + interaction room) ---
      {
        const lv = p.match(/^\/api\/live\/[A-Za-z0-9-]{1,64}\/(start|stop|join|room|donate|mod|state)$/);
        if (lv) {
          const act = lv[1];
          if (act === "start" && req.method === "POST") return await liveStart(req, env);
          if (act === "stop" && req.method === "POST") return await liveStop(req, env);
          if (act === "join" && req.method === "GET") return await liveJoin(req, env);
          if (act === "room") return await liveRoom(req, env);
          if (act === "donate" && req.method === "POST") return await liveDonate(req, env);
          if (act === "mod" && req.method === "POST") return await liveMod(req, env);
          if (act === "state" && req.method === "GET") return await liveState(req, env);
        }
      }

      // --- AvaVoice: creator-built AI voice agents (Specs/AVAVOICE-PROPOSAL.md) ---
      if (p === "/api/avavoice/voices" && req.method === "GET") return avavoiceVoices();
      if (p === "/api/avavoice/marketplace" && req.method === "GET") return await avavoiceMarketplace(req, env);
      if (p === "/api/avavoice/agents/mine" && req.method === "GET") return await avavoiceMine(req, env);
      if (p === "/api/avavoice/agents" && req.method === "POST") return await avavoiceCreateAgent(req, env);
      if (p === "/api/avavoice/bookings" && req.method === "POST") return await avavoiceBook(req, env);
      if (p === "/api/avavoice/bookings/mine" && req.method === "GET") return await avavoiceMyBookings(req, env);
      if (p === "/api/avavoice/calls/now" && req.method === "POST") return await avavoiceCallNow(req, env);
      if (p === "/api/avavoice/sessions/start" && req.method === "POST") return await avavoiceSessionStart(req, env);
      if (p === "/api/avavoice/sessions/heartbeat" && req.method === "POST") return await avavoiceHeartbeat(req, env);
      if (p === "/api/avavoice/sessions/stop" && req.method === "POST") return await avavoiceSessionStop(req, env);

      // --- Ava Receptionist: premium "Ava answers after 5 rings" (Specs/PROPOSAL-AI-RECEPTIONIST.md) ---
      if (p === "/api/receptionist/settings" && req.method === "GET") return await receptionistGetSettings(req, env);
      if (p === "/api/receptionist/settings" && req.method === "PUT") return await receptionistPutSettings(req, env);
      if (p === "/api/receptionist/config" && req.method === "GET") return await receptionistConfigFor(req, env);
      if (p === "/api/receptionist/start" && req.method === "POST") return await receptionistStart(req, env);
      if (p === "/api/receptionist/finish" && req.method === "POST") return await receptionistFinish(req, env);
      if (p === "/api/receptionist/recording" && req.method === "GET") return await receptionistRecording(req, env);
      if (p === "/api/receptionist/analytics" && req.method === "GET") return await receptionistAnalytics(req, env); // [RECEPT-STATS-1]
      if (p === "/api/receptionist/kb" && req.method === "POST") return await receptionistKbUpload(req, env);
      if (p === "/api/receptionist/kb" && req.method === "DELETE") return await receptionistKbClear(req, env);
      {
        const bk = p.match(/^\/api\/avavoice\/bookings\/([A-Za-z0-9-]{1,64})\/cancel$/);
        if (bk && req.method === "POST") return await avavoiceCancelBooking(req, env, bk[1]);
        const af = p.match(/^\/api\/avavoice\/agents\/([A-Za-z0-9-]{1,64})\/files\/([A-Za-z0-9-]{1,64})$/);
        if (af && req.method === "DELETE") return await avavoiceDeleteFile(req, env, af[1], af[2]);
        const aa = p.match(/^\/api\/avavoice\/agents\/([A-Za-z0-9-]{1,64})\/(publish|unpublish|files|availability|stats)$/);
        if (aa) {
          if (aa[2] === "publish" && req.method === "POST") return await avavoicePublish(req, env, aa[1], true);
          if (aa[2] === "unpublish" && req.method === "POST") return await avavoicePublish(req, env, aa[1], false);
          if (aa[2] === "files" && req.method === "POST") return await avavoiceUploadFile(req, env, aa[1]);
          if (aa[2] === "availability" && req.method === "GET") return await avavoiceAvailability(req, env, aa[1]);
          if (aa[2] === "stats" && req.method === "GET") return await avavoiceStats(req, env, aa[1]);
        }
        const ag = p.match(/^\/api\/avavoice\/agents\/([A-Za-z0-9-]{1,64})$/);
        if (ag) {
          if (req.method === "GET") return await avavoiceGetAgent(req, env, ag[1]);
          if (req.method === "PUT") return await avavoiceUpdateAgent(req, env, ag[1]);
          if (req.method === "DELETE") return await avavoiceDeleteAgent(req, env, ag[1]);
        }
      }

      // --- AvaVision: creator-built AI VISION coaching agents (Specs/AVAVISION-PROPOSAL.md) ---
      if (p === "/api/avavision/templates" && req.method === "GET") return avavisionTemplates(req, env);
      if (p === "/api/avavision/voices" && req.method === "GET") return avavisionVoices();
      if (p === "/api/avavision/marketplace" && req.method === "GET") return await avavisionMarketplace(req, env);
      if (p === "/api/avavision/agents/mine" && req.method === "GET") return await avavisionMine(req, env);
      if (p === "/api/avavision/agents" && req.method === "POST") return await avavisionCreateAgent(req, env);
      if (p === "/api/avavision/bookings" && req.method === "POST") return await avavisionBook(req, env);
      if (p === "/api/avavision/bookings/mine" && req.method === "GET") return await avavisionMyBookings(req, env);
      if (p === "/api/avavision/calls/now" && req.method === "POST") return await avavisionCallNow(req, env);
      if (p === "/api/avavision/sessions/start" && req.method === "POST") return await avavisionSessionStart(req, env);
      if (p === "/api/avavision/sessions/token" && req.method === "POST") return await avavisionSessionToken(req, env);
      if (p === "/api/avavision/sessions/heartbeat" && req.method === "POST") return await avavisionHeartbeat(req, env);
      if (p === "/api/avavision/sessions/stop" && req.method === "POST") return await avavisionSessionStop(req, env);
      if (p === "/api/avavision/snapshot" && req.method === "POST") return await avavisionSnapshot(req, env);
      {
        const bk = p.match(/^\/api\/avavision\/bookings\/([A-Za-z0-9-]{1,64})\/cancel$/);
        if (bk && req.method === "POST") return await avavisionCancelBooking(req, env, bk[1]);
        const af = p.match(/^\/api\/avavision\/agents\/([A-Za-z0-9-]{1,64})\/files\/([A-Za-z0-9-]{1,64})$/);
        if (af && req.method === "DELETE") return await avavisionDeleteFile(req, env, af[1], af[2]);
        const aa = p.match(/^\/api\/avavision\/agents\/([A-Za-z0-9-]{1,64})\/(publish|unpublish|files|availability|stats)$/);
        if (aa) {
          if (aa[2] === "publish" && req.method === "POST") return await avavisionPublish(req, env, aa[1], true);
          if (aa[2] === "unpublish" && req.method === "POST") return await avavisionPublish(req, env, aa[1], false);
          if (aa[2] === "files" && req.method === "POST") return await avavisionUploadFile(req, env, aa[1]);
          if (aa[2] === "availability" && req.method === "GET") return await avavisionAvailability(req, env, aa[1]);
          if (aa[2] === "stats" && req.method === "GET") return await avavisionStats(req, env, aa[1]);
        }
        const ag = p.match(/^\/api\/avavision\/agents\/([A-Za-z0-9-]{1,64})$/);
        if (ag) {
          if (req.method === "GET") return await avavisionGetAgent(req, env, ag[1]);
          if (req.method === "PUT") return await avavisionUpdateAgent(req, env, ag[1]);
          if (req.method === "DELETE") return await avavisionDeleteAgent(req, env, ag[1]);
        }
      }

      // --- Speech-to-text (OpenAI Whisper via OpenRouter; replaced on-device sherpa) ---
      if (p === "/api/stt/transcribe" && req.method === "POST") return await sttTranscribe(req, env);

      // --- Live voice translation (Gemini 3.5 Live Translate; $3/h Tokens) ---
      if (p === "/api/translate/quote" && req.method === "GET") return translateQuote(req);
      if (p === "/api/translate/start" && req.method === "POST") return await translateStart(req, env);
      if (p === "/api/translate/call/start" && req.method === "POST") return await callTranslationStart(req, env);
      {
        const ctr = p.match(/^\/api\/translate\/call\/([A-Za-z0-9-]{1,64})\/(activate|renew|stop|token|language)$/);
        if (ctr && req.method === "POST") {
          if (ctr[2] === "activate") return await callTranslationActivate(req, env, ctr[1]);
          if (ctr[2] === "renew") return await callTranslationRenew(req, env, ctr[1]);
          if (ctr[2] === "stop") return await callTranslationStop(req, env, ctr[1]);
          // [CALL-TRANSLATE-2C-1] Mid-call switch: same session row, same billing.
          if (ctr[2] === "language") return await callTranslationLanguage(req, env, ctr[1]);
          return await callTranslationToken(req, env, ctr[1]);
        }
      }
      {
        const tr = p.match(/^\/api\/translate\/([A-Za-z0-9-]{1,64})\/(beat|stop|token)$/);
        if (tr && req.method === "POST") {
          if (tr[2] === "beat") return await translateBeat(req, env, tr[1]);
          if (tr[2] === "stop") return await translateStop(req, env, tr[1]);
          if (tr[2] === "token") return await translateToken(req, env, tr[1]);
        }
      }

      // --- Phase 7: AvaConsult delivery (P2P + Realtime SFU + refund engine) ---
      if (p === "/api/consult/probe" && req.method === "GET") return consultProbe();
      if (p === "/api/consult/probe/blob" && req.method === "GET") return consultProbeBlob();
      {
        if (/^\/api\/consult\/[A-Za-z0-9-]{1,64}\/sfu(\/|$)/.test(p)) return await consultSfu(req, env);
        // [WAITROOM-1] Commercial booking ids are `commercial-booking-<sha256hex>`
        // (worker/src/routes/commercial_checkout.ts) — up to 96 chars, longer than
        // the plain crypto.randomUUID() ids the legacy 1:1 consult path uses.
        // [WAITROOM-2 / W4] The wide {1,96} id length is for `room` ONLY — that's
        // the waiting-room DO socket, which a commercial booking legitimately
        // opens. join/complete/cancel/extend are the legacy money/P2P path and
        // must stay {1,64} (the legacy crypto.randomUUID() id length) so a
        // commercial booking id can never match them; consultJoin/consultCancel/
        // consultExtend/consultComplete additionally 409 on bk.kind==='consult_1to1'
        // as a second, independent guard (see consult.ts).
        const cnRoom = p.match(/^\/api\/consult\/[A-Za-z0-9-]{1,96}\/room$/);
        if (cnRoom) return await consultRoom(req, env);
        const cn = p.match(/^\/api\/consult\/[A-Za-z0-9-]{1,64}\/(join|complete|cancel|extend)$/);
        if (cn) {
          const act = cn[1];
          if (act === "join" && req.method === "GET") return await consultJoin(req, env);
          if (act === "complete" && req.method === "POST") return await consultComplete(req, env);
          if (act === "cancel" && req.method === "POST") return await consultCancel(req, env);
          if (act === "extend" && req.method === "POST") return await consultExtend(req, env);
        }
      }

      // --- Phase 7 admin: test clock (staging only) + DLQ console ---
      if (p === "/api/admin/test-clock" && req.method === "POST") {
        // Admin gate first (same ADMIN_UIDS list), then the staging-only check.
        const a = await requireAdmin(req, env);
        if (a instanceof Response) return a;
        return await setTestClock(req, env);
      }
      if (p === "/api/admin/settlements" && req.method === "GET") return await adminFailedSettlements(req, env);
      // Manual engine pass (acceptance tests with the test clock): runs inline
      // and returns the exact actions that fired. Idempotent like every pass.
      if (p === "/api/admin/money/evaluate" && req.method === "POST") {
        const a = await requireAdmin(req, env);
        if (a instanceof Response) return a;
        const b = (await req.json().catch(() => ({}))) as any;
        const r = await runMoney(env, { type: b.type === "cancel" ? "cancel" : "evaluate", sid: String(b.sid || ""), kind: b.kind === "consult" ? "consult" : "live_event", phase: b.phase, orderId: b.orderId });
        return json(r);
      }
      {
        const sr = p.match(/^\/api\/admin\/settlements\/([A-Za-z0-9-]{1,64})\/retry$/);
        if (sr && req.method === "POST") return await adminRetrySettlement(req, env, sr[1]);
      }

      // --- permanent redirect for any cached/shared legacy media URLs ---
      if (/^\/media\/[a-f0-9]{64}$/.test(p) && req.method === "GET") return mediaRedirect(p, env);

      // --- Phase 6: listings pipeline + AvaExplore + creator channels ---
      // Marketplace reads are PUBLIC (A3 guest browsing — no auth required).
      if (p === "/api/explore" && req.method === "GET") return await exploreBrowse(req, env);
      if (p === "/api/explore/live-now" && req.method === "GET") return await exploreLiveNow(req, env);
      if (p === "/api/explore/search" && req.method === "GET") return await exploreSearch(req, env);
      if (p === "/api/explore/categories" && req.method === "GET") return await cached(req, ctx, () => exploreCategories(env), 300);
      // [WEB-SEO-3] Dynamic sitemap feeds — public, 1h edge cache.
      if (p === "/api/sitemap/listings" && req.method === "GET") return await cached(req, ctx, () => sitemapListings(env), 3600);
      if (p === "/api/sitemap/creators" && req.method === "GET") return await cached(req, ctx, () => sitemapCreators(env), 3600);
      if (p === "/api/listings" && req.method === "POST") return await createListing(req, env);
      if (p === "/api/listings/mine" && req.method === "GET") return await myListings(req, env);
      // [CARD-AI-REVIEW-1] Suggest-only copy review for the creator wizard. Must
      // be matched BEFORE the /api/listings/:id patterns further down — "copy-review"
      // is a valid [A-Za-z0-9-]{1,64} id as far as that regex is concerned.
      if (p === "/api/listings/copy-review" && req.method === "POST") return await listingCopyReview(req, env);
      // --- AvaMarketplace (buy/sell/social + agent negotiation) ---
      // [MKT1-CATAPI] Category engine (PLAN-2026-07-17 §2.0-2.4). Categories are DATA,
      // not code: adding "Boats for sale" is a D1 insert, not a release. `vertical`
      // (commerce|connect) defaults to commerce so every existing caller is unaffected.
      // Cached 300s like /api/explore/categories — cached() keys on the full URL, so
      // ?vertical=connect caches separately. /proposed is NOT cached (admin, per-bearer).
      if (p === "/api/marketplace/categories" && req.method === "GET") return await cached(req, ctx, () => marketplaceCategories(req, env), 300);
      if (p === "/api/marketplace/categories/proposed" && req.method === "GET") return await proposedCategories(req, env);
      // [MKT2-CORE] AI-chat listing creation (PLAN-2026-07-17 §3). Server owns the draft;
      // the LLM only proposes validated tool calls and can NEVER publish — publish is a
      // separate explicit user action on a review card. /turn is SSE, so it must NOT be
      // wrapped in cached(). Whole surface is dark behind aiComposeEnabled (default false).
      if (p === "/api/marketplace/compose/session" && req.method === "POST") return await composeSession(req, env);
      if (p === "/api/marketplace/compose/turn" && req.method === "POST") return await composeTurn(req, env);
      if (p === "/api/marketplace/compose/publish" && req.method === "POST") return await composePublish(req, env);
      if (p === "/api/marketplace/ai-assist" && req.method === "POST") return await marketplaceAiAssist(req, env);
      if (p === "/api/marketplace/listing-quote" && req.method === "GET") return await listingFeeQuote(req, env);
      if (p === "/api/marketplace/negotiate" && req.method === "POST") return await marketplaceNegotiate(req, env, ctx);
      if (p === "/api/marketplace/negotiate/state" && req.method === "GET") return await marketplaceNegotiateState(req, env);
      if (p === "/api/marketplace/search" && req.method === "GET") return await marketplaceSearch(req, env);
      if (p === "/api/marketplace/precheck" && req.method === "POST") return await marketplacePrecheck(req, env);
      if (p === "/api/marketplace/audio" && req.method === "GET") return await marketplaceAudio(req, env);
      if (p === "/api/marketplace/deal/approve" && req.method === "POST") return await marketplaceDealDecision(req, env, "approve");
      if (p === "/api/marketplace/deal/reject" && req.method === "POST") return await marketplaceDealDecision(req, env, "reject");
      {
        const md = p.match(/^\/api\/marketplace\/negotiate\/([A-Za-z0-9-]{1,96})\/decision$/);
        if (md && req.method === "POST") return await marketplaceDealDecision(req, env, undefined, md[1]);
      }
      if (p === "/api/report" && req.method === "POST") return await report(req, env);
      if (p === "/api/creators/me" && req.method === "PUT") return await updateMyChannel(req, env);
      // Creator insights dashboards (owner-gated).
      if (p === "/api/creators/me/stats" && req.method === "GET") return await creatorStats(req, env);
      {
        const ls = p.match(/^\/api\/listings\/([A-Za-z0-9-]{1,64})\/stats$/);
        if (ls && req.method === "GET") return await listingStats(req, env, ls[1]);
        const la = p.match(/^\/api\/listings\/([A-Za-z0-9-]{1,64})\/(publish|submit|status|duplicate|repeat|book|reviews|promotions|questions)$/);
        if (la) {
          const lid = la[1], act = la[2];
          if (act === "publish" && req.method === "POST") return await publishListing(req, env, lid);
          // [LISTING-BLOCKERS-1] Read-only: everything standing between this
          // listing and being live, so the wizard and the admin queue can show
          // the SERVER's answer instead of each keeping their own checklist.
          if (act === "blockers" && req.method === "GET") return await listingBlockersRoute(req, env, lid);
          // [LISTING-REVIEW-1] The honest review: deterministic blockers plus an
          // advisory model pass, with a verdict the wizard can actually gate on.
          if (act === "review" && req.method === "POST") return await listingReview(req, env, lid);
          // ctx is threaded in so auto poster generation can run under
          // ctx.waitUntil() — a bare detached promise is not guaranteed to
          // finish once the response is sent, which would strand the poster
          // on `generating` forever. [MKT-POSTER-AUTO-1]
          if (act === "submit" && req.method === "POST") return await submitListingForApproval(req, env, lid, ctx);
          if (act === "status" && req.method === "POST") return await setListingStatus(req, env, lid);
          if (act === "duplicate" && req.method === "POST") return await duplicateListing(req, env, lid);
          // [CARD-SLOTS-1] "repeat weekly for N weeks" -> N standalone drafts sharing a series_id.
          if (act === "repeat" && req.method === "POST") return await repeatListing(req, env, lid);
          if (act === "book" && req.method === "POST") return await bookListing(req, env, lid);
          // [LIST-CONTENT-2] createReview replaced (verified_attendee, photo_keys —
          // see routes/reviews.ts); listReviews (GET) is new, paginated, §4.6-aware.
          if (act === "reviews" && req.method === "POST") return await createReview(req, env, lid);
          if (act === "reviews" && req.method === "GET") return await listReviews(req, env, lid);
          // NOTE: /reviews/eligibility is TWO segments and cannot ride this
          // single-segment `la` matcher — it is routed separately just below.
          if (act === "promotions" && (req.method === "GET" || req.method === "POST")) return await listingPromotions(req, env, lid);
          // [LIST-ASK-1] "Ask the host" — one question per user per listing.
          if (act === "questions" && req.method === "POST") return await askQuestion(req, env, lid);
        }
        // [REVIEW-MOD-1] "May I review this, and what did I already write?" —
        // optional auth (a guest gets reason:'signed_out', not a 401).
        const rel = p.match(/^\/api\/listings\/([A-Za-z0-9-]{1,64})\/reviews\/eligibility$/);
        if (rel && req.method === "GET") return await reviewEligibility(req, env, rel[1]);
        const lpd = p.match(/^\/api\/listings\/([A-Za-z0-9-]{1,64})\/promotions\/([A-Za-z0-9-]{1,64})$/);
        if (lpd && req.method === "DELETE") return await deletePromotion(req, env, lpd[1], lpd[2]);
        // [LIST-SLOTS-1] C.3 calendar-1:1 booking slots — dark behind listingSlotsEnabled.
        const lsl = p.match(/^\/api\/listings\/([A-Za-z0-9-]{1,64})\/slots$/);
        if (lsl && req.method === "GET") return await listListingSlots(req, env, lsl[1]);
        if (lsl && req.method === "POST") return await createListingSlot(req, env, lsl[1]);
        const sid = p.match(/^\/api\/slots\/([A-Za-z0-9-]{1,64})$/);
        if (sid && req.method === "PATCH") return await patchListingSlot(req, env, sid[1]);
        if (sid && req.method === "DELETE") return await deleteListingSlot(req, env, sid[1]);
        // [LIST-PAGE-2] Pretty-URL resolution for /<handle>/<slug> — see
        // routes/listings.ts getListingBySlug header. Must be matched before `lm`
        // below, which only matches a single path segment after /api/listings/.
        const lbs = p.match(/^\/api\/listings\/by-slug\/([A-Za-z0-9._-]{1,64})\/([A-Za-z0-9._-]{1,80})$/);
        if (lbs && req.method === "GET") return await getListingBySlug(req, env, lbs[1], lbs[2]);
        const lm = p.match(/^\/api\/listings\/([A-Za-z0-9-]{1,64})$/);
        if (lm && req.method === "GET") return await getListing(req, env, lm[1]);
        if (lm && req.method === "PUT") return await updateListing(req, env, lm[1]);
        if (lm && req.method === "DELETE") return await cancelListing(req, env, lm[1]);
        const cf = p.match(/^\/api\/creators\/([A-Za-z0-9_-]{1,64})\/(follow|block)$/);
        if (cf) {
          const cid = cf[1], act = cf[2];
          if (act === "follow" && req.method === "POST") return await followCreator(req, env, cid);
          if (act === "follow" && req.method === "DELETE") return await unfollowCreator(req, env, cid);
          if (act === "block" && (req.method === "POST" || req.method === "DELETE")) return await blockCreator(req, env, cid);
        }
        const cm = p.match(/^\/api\/creators\/([A-Za-z0-9_-]{1,64})$/);
        if (cm && req.method === "GET") return await getCreator(req, env, cm[1]);
      }

      // --- AvaAffiliate (Specs/proposals/PROPOSAL-AVA-AFFILIATE.md) ---
      // Public click route: telemetry → pending-attribution KV → preview/deep link.
      {
        const ac = p.match(/^\/a\/([A-Za-z0-9_-]{4,32})$/);
        if (ac && req.method === "GET") return await affiliateClick(req, env, ac[1]);
      }
      if (p === "/api/affiliate/register" && req.method === "POST") return await affiliateRegister(req, env);
      if (p === "/api/affiliate/me" && req.method === "GET") return await affiliateMe(req, env);
      if (p === "/api/affiliate/listings" && req.method === "GET") return await affiliateListings(req, env);
      if (p === "/api/affiliate/links" && req.method === "POST") return await affiliateLinkCreate(req, env);
      if (p === "/api/affiliate/links" && req.method === "GET") return await affiliateLinks(req, env);
      if (p === "/api/affiliate/bind" && req.method === "POST") return await affiliateBind(req, env);
      {
        const al = p.match(/^\/api\/affiliate\/links\/([A-Za-z0-9_-]{4,32})\/(stats|subscribers|pause|assets)$/);
        if (al) {
          if (al[2] === "stats" && req.method === "GET") return await affiliateLinkStats(req, env, al[1]);
          if (al[2] === "subscribers" && req.method === "GET") return await affiliateLinkSubscribers(req, env, al[1]);
          if (al[2] === "pause" && req.method === "POST") return await affiliateLinkPause(req, env, al[1]);
          // v2 marketing-asset kit (Nano Banana 2; flag affiliateAssetKitEnabled)
          if (al[2] === "assets" && req.method === "POST") return await affiliateAssetsGenerate(req, env, al[1]);
          if (al[2] === "assets" && req.method === "GET") return await affiliateAssetsList(req, env, al[1]);
        }
        if (p === "/api/admin/affiliates" && req.method === "GET") return await adminAffiliates(req, env);
        const as = p.match(/^\/api\/admin\/affiliates\/([A-Za-z0-9_:-]{1,64})\/suspend$/);
        if (as && req.method === "POST") return await adminAffiliateSuspend(req, env, as[1]);
      }

      // --- creator-marketplace URL-space reservation (Phase 1) — 501 stubs ---
      const stub = marketplaceStub(p);
      if (stub) return stub;
    } catch (e: any) {
      return json({ error: "internal", detail: String(e?.message ?? e) }, 500);
    }
    return json({ error: "not found", path: p }, 404);
}

// Cache API wrapper for public GET reads (Rulebook: Cache API before KV/D1).
async function cached(req: Request, ctx: ExecutionContext, build: () => Promise<Response>, ttl: number): Promise<Response> {
  const cache = caches.default;
  const hit = await cache.match(req);
  if (hit) return hit;
  const res = await build();
  if (res.status === 200) {
    const toCache = new Response(res.clone().body, res);
    toCache.headers.set("cache-control", `public, max-age=${ttl}`);
    ctx.waitUntil(cache.put(req, toCache));
  }
  return res;
}
