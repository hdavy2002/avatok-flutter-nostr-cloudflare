/** Bindings for the AvaTok API Worker. See wrangler.toml. */
export interface Env {
  // [STAGING-ISOLATION-1] "prod" | "staging" — set via wrangler.toml [vars] (prod)
  // and [env.staging.vars] (staging). Read ONLY by hooks.ts track()/trackException()
  // to stamp `environment` on every PostHog event/exception so staging traffic can
  // be filtered out of prod dashboards. Optional + hooks.ts falls back to "prod" so
  // this compiles/deploys safely even before the wrangler.toml var lands.
  ENVIRONMENT_NAME?: string;
  // [DYNW-CORE-1] Dynamic Workers loader. ONLY lib/dynw/host.ts may touch this —
  // it enforces the master kill switch, no-network default, timeout + telemetry.
  LOADER: import("./lib/dynw/types").WorkerLoaderBinding;
  // [DYNW-CORE-1] STAGING-ONLY secret for the dynw acceptance battery
  // (routes/dynw_test.ts). Never set in prod — absent = header auth disabled.
  DYNW_TEST_SECRET?: string;
  AI_MEDIA_INPUT_KEY?: string;
  VENICE_API_KEY?: string;
  JWT_SECRET?: string;
  // [DYNW-FLOWS-1] Cloudflare Workflows binding for the DARK PARALLEL account-
  // deletion cascade (worker/src/workflows/deletion.ts). The LIVE path is still
  // Q_DELETE below → consumers/src/deletion.ts; this binding is only ever called
  // behind `deletionWorkflowEnabled` (routes/config.ts, default false). Instance
  // id convention: `deletion:<uid>` (deterministic — doubles as the idempotency
  // key). `Workflow` is an ambient global type from @cloudflare/workers-types
  // (declare abstract class Workflow<PARAMS>), no import needed.
  WF_DELETION: Workflow<{ uid: string }>;

  // D1 — the database (Golden Rule 1)
  DB_META: D1Database;
  DB_MEDIA: D1Database;
  DB_MODERATION: D1Database;
  DB_BRAIN: D1Database;  // AvaBrain knowledge graph + memory
  DB_WALLET: D1Database; // AvaWallet audit trail (balance authority is WalletDO)

  // R2 — writes only; reads go to blossom.avatok.ai (public bucket)
  BLOBS: R2Bucket;
  VERIFICATION: R2Bucket;
  DIGITAL: R2Bucket;     // avatok-digital — PRIVATE; OLX digital goods (signed reads)
  AGENT_AUDIO: R2Bucket; // avatok-agent-audio — lazy agent-conversation TTS cache
  BACKUP_R2: R2Bucket;   // avatok-backup — Ava premium cross-device sync + gen-image store (P9/P10)

  // KV — ephemeral tokens ONLY (Golden Rule 5)
  TOKENS: KVNamespace;

  // Queues — all async work
  Q_MODERATION: Queue;
  Q_PUSH: Queue;
  Q_EMAIL: Queue;
  Q_ANALYTICS: Queue;
  Q_BRAIN: Queue;
  Q_DELETE: Queue;   // account-deletions (30-day-grace 15-store cascade, Phase 1)
  Q_WALLET: Queue;   // wallet-transactions (DO → D1 audit trail, Phase 2)
  Q_AGENT: Queue;    // agent-tasks (agent conversations + per-app hooks, Phase 7)
  Q_MONEY: Queue;    // money-settlements (refund/settlement engine, marketplace Phase 7)
  Q_ARCHIVE?: Queue; // chat-archive (Phase 1 ABLY-R2: message body → R2 + D1 index)
  Q_MKT_AUDIO?: Queue; // marketplace negotiation VOICE render (async → avatok-consumers)
  Q_AUTO_REPLY?: Queue; // STREAM F auto-responder job (incoming DM → away auto-reply, async → avatok-consumers)
  // [LIVE-QUEUE-1] liveness-verify — SELF-consumed by avatok-api (see wrangler.toml
  // [[queues.consumers]] for "liveness-verify"). Optional/typed-loose because the
  // queue must be created (`wrangler queues create liveness-verify`) before this
  // binding resolves at deploy time; livenessVerify() falls back to ctx.waitUntil
  // when .send() throws (binding missing or queue not yet created).
  LIVENESS_QUEUE?: Queue;
  // Contact-book chunking (2026-07-14). Optional: the queue is not yet provisioned,
  // so scheduleChunk() falls back to ctx.waitUntil (same pattern as LIVENESS_QUEUE).
  // Bind "contacts-chunk" (producer + self-consumer) once created to move the
  // chunk job off the request lifecycle for very large books at 1M-user scale.
  Q_CONTACTS?: Queue;
  // Durable derived-media work. Required when aiMediaJobsEnabled is flipped;
  // unlike short local bookkeeping this must never fall back to waitUntil.
  Q_AI_MEDIA: Queue<{ job_id: string; kind: string }>;

  // Workers AI — image moderation (public uploads)
  AI: Ai;

  // AI Search (managed RAG) namespace binding — premium memory & file search.
  // Per-user instances created at runtime (get/create); typed loosely (the
  // platform types vary by runtime version). See routes/ava_rag.ts.
  AI_SEARCH: any;

  // Analytics Engine — operational metrics (writeDataPoint)
  ANALYTICS: AnalyticsEngineDataset;

  // Vectorize — semantic search (populated Phase 4)
  VECTOR_INDEX: VectorizeIndex;

  // Durable Object — 1:1 call signaling rooms
  CALL_ROOMS: DurableObjectNamespace;
  // Durable Object — free-tier P2P mesh group-call signaling rooms (≤5)
  MESH_ROOMS: DurableObjectNamespace;
  // Durable Object — CF Realtime SFU group-AUDIO rooms (≤32, active-speaker).
  // Roster + active-speaker fan-out over hibernatable WS; one per group id.
  // Gated by groupAudioSfuEnabled (dormant until built+CI-verified).
  GROUP_CALL_ROOMS: DurableObjectNamespace;
  CONFERENCE_ROOMS: DurableObjectNamespace;
  // Durable Object — per-user AvaBrain reasoning
  USER_BRAIN: DurableObjectNamespace;
  // Durable Object — per-user atomic coin balance (Phase 2)
  WALLET_DO: DurableObjectNamespace;
  // Durable Object — one fail-closed connected-time authority per Messenger
  // authorization. Dark until messengerCallBillingEnabled is explicitly on.
  MESSENGER_CALL_BILLING: DurableObjectNamespace;
  // Durable Object — per-stream gift aggregation (Phase 2)
  STREAM_SESSION_DO: DurableObjectNamespace;
  // Durable Object — per-user agent coordinator (rate-limit + neuron budget, Phase 7)
  AGENT_DO: DurableObjectNamespace;
  // Durable Object — per agent↔agent conversation (turn loop, Phase 7)
  CONVERSATION_DO: DurableObjectNamespace;
  // Durable Object — per-user messaging inbox (Cloudflare-native pivot; Nostr
  // deprecated). Hibernatable WS + DO-local SQLite message log. Keyed by uid.
  INBOX: DurableObjectNamespace;

  // Durable Object — per-account call-state control-plane authority (Phase A
  // plumbing only — dormant). Single writer for call/receptionist state
  // (epoch CAS + lease + reservations). Specs/CALL-CONTROL-PLANE-UNIFIED-PLAN.md.
  // Not read/written by any route yet; gated by authorityShadowEnabled /
  // authorityReadEnabled / authorityWriteEnabled / authorityEnforced (all off).
  CALL_STATE_AUTHORITY: DurableObjectNamespace;

  // Durable Object — Guardian Sentinel per-user HOT CACHE (S1). Velocity windows,
  // last-N event-id dedup ring, per-bucket score cache. NEVER a system of record —
  // rehydrates from D1 (the append-only sentinel_evidence log). Keyed by uid. DARK
  // behind sentinelEnabled. Specs/GUARDIAN-SENTINEL-FINAL-PLAN-2026-07-06.md §S1.
  SENTINEL: DurableObjectNamespace;

  // Durable Object — PartyKit realtime layer (ephemeral; replaces Ably). One DO
  // per ROOM (thread:<conv>, listing:<id>, neg:<negId>, user:<uid>, conf:<gid>).
  // Holds the room's hibernatable WebSockets; broadcast-only, no persistence.
  PARTY: DurableObjectNamespace;

  // ---- Ava in-chat AI bindings (Phase 0 — Foundations; part of the bindings
  // contract). The DO CLASSES are implemented by later phases (AvaAgentDO = P3,
  // BackupDO = P10), so the worker will not fully typecheck until those classes
  // are exported from index.ts — expected & accepted (see INTEGRATION-NOTES.md).
  // Durable Object — per-user in-thread Ava agent loop (P3).
  AVA_AGENT: DurableObjectNamespace;
  // Durable Object — per-user backup/sync coordinator (P10).
  BACKUP: DurableObjectNamespace;
  // Durable Object — Ava Receptionist call bridge (one per session id). Relays
  // caller audio ↔ Gemini Live (through AI Gateway) for "Ava answers after 5
  // rings". Specs/PROPOSAL-AI-RECEPTIONIST.md.
  RECEPTION_ROOM: DurableObjectNamespace;
  // Ava Receptionist — Cloudflare-native engine DO (separate from the Gemini
  // bridge above). Workers AI STT→LLM→TTS. Specs/RECEPTIONIST-CF-PIPELINE.md.
  RECEPTION_ROOM_CF: DurableObjectNamespace;
  // Voicemail bot DO (WP3, plan §7 item 5 / §15.5) — carrier-style "leave a
  // 25s voicemail after the tone" bridge. Forked from RECEPTION_ROOM_CF's
  // Workers AI STT→TTS pipeline but simpler (no dialog loop). One instance
  // per session id. Specs/PLAN-2026-07-11-dialpad-business-calls-ava-voice-agent.md.
  VOICEMAIL_ROOM: DurableObjectNamespace;
  // Ava AI Voice Agent DO (WP4, plan §4/§7 item 7) — one instance per call
  // session id. Bridges the caller's WebRTC audio to a Grok Voice Agent
  // realtime session (RAG via Grok Collections `file_search`, Composio tool
  // calls, booking-authority gated writes). Dark behind `voiceAgent`.
  // Specs/PLAN-2026-07-11-dialpad-business-calls-ava-voice-agent.md.
  AGENT_VOICE_ROOMS: DurableObjectNamespace;
  // Durable Object — [AVA-PSTN-AGENT-1] live Gemini agent on CELL (Vobiz DID)
  // calls via bidirectional media streams. One instance per PSTN agent session
  // (`pstn-<CallUUID>`); speaks the Vobiz JSON frame protocol to the caller and
  // Gemini Live upstream. DARK behind pstnAgentEnabled (routes/config.ts).
  // Specs/PLAN-2026-07-19-vobiz-media-stream-agent.md.
  VOBIZ_AGENT_ROOM: DurableObjectNamespace;
  // [AVA-VM-SELFREC-1] Durable Object — self-recorded PSTN voicemail over a
  // Vobiz bidirectional <Stream> WebSocket (do/voicemail_stream_room.ts),
  // replacing Vobiz's billed <Record> verb. One instance per voicemail session
  // (`pstn-vm-<CallUUID>`); captures caller PCM, encodes MP3 to R2, and delivers
  // the SAME InboxDO voicemail envelope as routes/pstn.ts handleRecordCb. DARK
  // behind pstnVoicemailSelfRecord (routes/config.ts).
  VOICEMAIL_STREAM_ROOM: DurableObjectNamespace;
  // [AVA-CAMP-B1-GATE] Durable Object — per-user outbound-dial admission gate
  // for AI calling campaigns (channel pool + token-bucket rate limit + round-
  // robin fairness across a user's running campaigns). One instance per owner
  // uid. Phase B1 scaffolding — DARK, nothing calls it yet (campaignDialerEnabled
  // defaults false). Specs/OUTBOUND-AI-CALLING-CAMPAIGNS.md §2, §6.3.
  DIALER_GATE: DurableObjectNamespace;
  // [AVA-CAMP-B2-WIRE] Per-campaign SQLite-backed DO (call_fsm state, pacing).
  CAMPAIGN_DO: DurableObjectNamespace;
  // [AGENT-LIVE-1] Single global seat/capacity authority (idFromName('global'))
  // for AI voice agent bookings — per-agent max_concurrent + platform-wide
  // agentPlatformMaxConcurrent. worker/src/do/agent_seat_authority.ts.
  AGENT_SEAT_AUTHORITY: DurableObjectNamespace;
  // [AGENT-LIVE-1] Per-booking live room DO (idFromName(bookingId)) bridging
  // the browser WebSocket to the OpenAI gpt-live-1 realtime session.
  // worker/src/do/agent_live_room.ts. DO migration tag v24.
  AGENT_LIVE_ROOMS: DurableObjectNamespace;

  // vars
  BLOSSOM_BASE_URL: string;
  // [AVA-MEDIA-AUTHZ-1] R2 bucket name for the private DIGITAL bucket's SigV4
  // presigned-read path (media.ts). MUST match the env's DIGITAL r2_buckets
  // bucket_name in wrangler.toml — prod = "avatok-digital", staging =
  // "avatok-digital-staging". A hardcoded prod fallback here previously let
  // staging presign against PRODUCTION's bucket.
  DIGITAL_BUCKET_NAME: string;
  FCM_PROJECT: string;
  // Comma-separated Clerk uids allowed to PUT /api/admin/config (Phase 1, A2).
  ADMIN_UIDS?: string;
  // [TEST-FAILURE-INJECT-1] Comma-separated fault-injection point names, ENV-ONLY
  // (never a KV/config flag — see worker/src/lib/fault_inject.ts). Unset in every
  // deployed environment today.
  FAULT_INJECT?: string;
  BRAIN_REASONER_MODEL?: string;
  BRAIN_EMBED_MODEL?: string;
  // Phase 9 — "1" → toggling a guardrail OFF also retro-deletes already-indexed
  // items from that source (vectors, transcripts, derived facts).
  BRAIN_RETRO_DELETE?: string;
  POSTHOG_QUERY_HOST?: string;
  POSTHOG_PROJECT_ID?: string;

  // secret — investigate() reads PostHog (personal key; gated)
  POSTHOG_PERSONAL_API_KEY?: string;

  // secrets (wrangler secret put)
  CLERK_JWKS_URL?: string;
  CLERK_ISSUER?: string;
  // AvaApps (PREMIUM) — Composio tool-calling for the user's Google apps
  // (Gmail/Docs/Sheets/Drive/Calendar). Unset → AvaApps routes return 503.
  COMPOSIO_API_KEY?: string;
  TURN_KEY_ID?: string;
  TURN_KEY_API_TOKEN?: string;
  // Cloudflare Realtime SFU (group AUDIO). App id + bearer token for the
  // rtc.live.cloudflare.com sessions/tracks API. Unset → /api/groupcall/* 503s,
  // so the new path is a safe no-op until these are set.
  CF_RT_SFU_APP_ID?: string;
  CF_RT_SFU_APP_TOKEN?: string;
  // [CALL-RTK-2 2026-08-08] Cloudflare RealtimeKit (Specs/CALL-REALTIMEKIT-MIGRATION.md).
  // CF_RTK_ORG_ID holds the RealtimeKit **App ID** and CF_RTK_API_KEY the API
  // token; the account id is reused from CF_ACCOUNT_ID below. The names follow
  // the spec (Dyte-era "org id"/"api key" vocabulary) even though the current
  // REST surface is the Cloudflare account API with a Bearer token. Unset →
  // /api/callrtk/* 503s `rtk_unavailable`, so the route is a safe no-op until
  // the secrets are set per environment via scripts/cf.sh.
  CF_RTK_ORG_ID?: string;
  CF_RTK_API_KEY?: string;
  FCM_SERVICE_ACCOUNT?: string;
  // Cloudflare Stream webhook HMAC secret (AvaLive). Gated.
  STREAM_WEBHOOK_SECRET?: string;
  // GetStream Video pilot. API key is public-safe; API secret is a wrangler
  // secret and is never committed. Both are unused while the pilot flag is off.
  STREAM_VIDEO_API_KEY?: string;
  STREAM_VIDEO_API_SECRET?: string;
  // GetStream Chat. Reuses the same Stream app when available. Optional
  // dedicated aliases support future split-app setups; the route prefers the
  // chat-specific pair when present and otherwise falls back to the video pair.
  STREAM_CHAT_API_KEY?: string;
  STREAM_CHAT_API_SECRET?: string;
  // Comma-separated staging account ids allowed into the dark Stream pilot.
  // Unset/empty means nobody can use the pilot even if its config flag is on.
  STREAM_VIDEO_PILOT_UIDS?: string;

  // AvaID — AWS Rekognition Face Liveness (Phase 1). Flag-gated: unset → 503.
  AWS_ACCESS_KEY_ID?: string;
  AWS_SECRET_ACCESS_KEY?: string;
  AWS_SESSION_TOKEN?: string;
  AWS_REGION?: string;

  // Clerk Backend API (account deletion cascade, Phase 1). Gated.
  CLERK_SECRET_KEY?: string;

  // Guardian Sentinel S2 — mem0 managed-cloud behaviour memory (derived cache).
  // `wrangler secret put MEM0_API_KEY` (also note in secrets/secret-values.env).
  // Unset → the mem0 summariser/purge code cleanly no-ops (fail-open). Everything
  // is additionally DARK behind sentinelMem0Enabled. mem0 is NEVER an owner of
  // truth — every memory carries derived_from event ids and regenerates from the
  // append-only sentinel_evidence log. Specs/GUARDIAN-SENTINEL-FINAL-PLAN §S2.
  MEM0_API_KEY?: string;

  // Ava AI Voice Agent (WP4, plan §4) — Grok Voice Agent realtime API +
  // Collections RAG. `wrangler secret put GROK_API_KEY` — set SEPARATELY per
  // environment (staging + prod each get their own x.ai key, plan §15.6 "no
  // staging data ever promotes to prod"). Unset → do/agent_voice_room.ts fails
  // fast at session start (GROK_SESSION_FAIL, refund, voicemail fallback) —
  // the constructor itself never throws, so a bare deploy with no key set is
  // safe as long as `voiceAgent` stays off in KV.
  GROK_API_KEY?: string;
  // x.ai MANAGEMENT API key (separate secret from GROK_API_KEY, separate host
  // management-api.x.ai) — needed for Collections CRUD + document add/remove
  // (lib/grok.ts). Create in the x.ai console with the "AddFileToCollection"
  // + "Collections Endpoint" permissions. `wrangler secret put
  // GROK_MANAGEMENT_KEY`. Unset → collection create/update/delete and
  // document add/remove return {ok:false, reason:"MANAGEMENT_KEY_MISSING"}
  // (never throws) — routes/agent_docs.ts still stores uploads in R2 so
  // owners can upload before the key exists, and reindexes once it's set.
  GROK_MANAGEMENT_KEY?: string;

  // Store-review login bypass (routes/review.ts). When set, the allowlisted
  // reviewer account signs in with email+password and NO email OTP. Unset →
  // the route returns 404 and the bypass is fully disabled.
  REVIEW_PASSWORD?: string;

  // Phase 5 — AvaCalendar/AvaBooking. Google Calendar OAuth (gated; unset →
  // /api/calendar/gcal/* returns 503), token-encryption key, join-link signer.
  GOOGLE_CLIENT_ID?: string;
  GOOGLE_CLIENT_SECRET?: string;
  GCAL_TOKEN_KEY?: string;         // AES-GCM key material for gcal refresh tokens
  // [WEB-PHONE-OTP-1 2026-09-10] 2Factor.in SMS OTP for web sign-up phone
  // verification (routes/phone_otp.ts). Secret — `scripts/cf.sh worker secret put
  // TWOFACTOR_API_KEY`. Unset => /api/account/phone/send answers 503 otp_unavailable.
  TWOFACTOR_API_KEY?: string;
  // Optional DLT-approved OTP template name on the 2Factor account. Unset => 2Factor's default.
  TWOFACTOR_OTP_TEMPLATE?: string;
  JOIN_LINK_SECRET?: string;       // HMAC for https://avatok.ai/j/<token>
  // [AGENT-LIVE-1] OpenAI API key for the gpt-live-1 realtime WebSocket relay,
  // the gpt-6-astra backend/vision calls and the RAG Files/Vector Store APIs.
  // Never reaches the browser. Unset ⇒ laneGate/talkGate fail closed (503
  // agent_live_unavailable). `wrangler secret put OPENAI_API_KEY`.
  OPENAI_API_KEY?: string;
  // [AGENT-LIVE-1] Comma-separated Clerk uid(s) allowed to create/edit/publish
  // AI voice agent listings and upload knowledge (D2). MUST resolve to exactly
  // one uid at runtime (worker/src/lib/agent_live/gate.ts requireAgentAdmin) —
  // never an email allowlist. Prod value filled in at rollout via
  // `wrangler.toml` var (see [AGENT-LIVE-1] AGENT_ADMIN_UIDS).
  AGENT_ADMIN_UIDS?: string;
  // [AVADIAL-CALL-INTEL-1] HMAC key for the call-intelligence phone identifier
  // (routes/telemetry_calls.ts). phone_id = HMAC-SHA256(this, E.164), and it is the
  // ONLY form of a caller's number that ever reaches PostHog.
  //
  // MUST stay server-side. The whole reason the Worker does the hashing instead of
  // the dialer is that a key shipped in an APK is not a key — anyone who unpacks the
  // app could hash every number in a range and reverse the ids. Set per environment
  // with `wrangler secret put CALL_ID_HMAC_SECRET`; until it is set, the ingest route
  // returns 503 (fail-loud) and devices keep their buffer and retry.
  CALL_ID_HMAC_SECRET?: string;

  // [AVA-MISSEDCALL-1] HMAC secret for the long-lived device token the missed-call
  // overlay's native receiver uses to look up AvaTOK membership while the app is dead
  // (no Clerk JWT available cold-start). Falls back to JOIN_LINK_SECRET.
  MISSEDCALL_TOKEN_SECRET?: string;

  // [CF-CALL-001] HMAC secret for the short-lived Cloudflare Realtime group-call
  // join ticket (routes/groupcall.ts mintJoinTicket/verifyJoinTicket). Dedicated —
  // does NOT fall back to any other secret. Unset ⇒ ticket minting fails closed
  // (503 from /join) and do/group_call_room.ts refuses every WS upgrade, so the
  // whole authenticated call-authority path is a safe no-op until this is set.
  // `wrangler secret put CONF_TICKET_SECRET`.
  CONF_TICKET_SECRET?: string;

  // Progressive Identity ladder (PROPOSAL-PROGRESSIVE-IDENTITY.md).
  GUEST_TOKEN_SECRET?: string;     // HMAC for L0 guest tokens (falls back to JOIN_LINK_SECRET)
  // [M-D1 2026-07-17 / M-D11 2026-07-18] TWILIO_ACCOUNT_SID / TWILIO_AUTH_TOKEN removed.
  // Their only consumer was the Twilio Lookup v2 line-type check inside idPhoneConfirm
  // (routes/id.ts), deleted when phone OTP was removed app-wide. Nothing else in worker/,
  // consumers/ or app/ references Twilio — AvaDial/PSTN uses a different provider
  // (routes/pstn.ts → Vobiz). The Worker SECRETS still exist in the deployed environments
  // and must be unbound separately (ops step). Do NOT reintroduce.

  // AvaStorage (universal per-account pool). Free quota in GB (default 5);
  // over-quota metered price in Tokens per GB per month (default 20 — billed
  // by the consumers monthly cron, ledger type storage_charge).
  STORAGE_FREE_GB?: string;
  STORAGE_COINS_PER_GB?: string;

  // Messaging KYC gate. "1" enforces verified KYC on /api/msg/send; default OFF
  // (Stripe Identity paused) so 1:1 chat works without verification for now.
  KYC_REQUIRED?: string;
  // Stripe Identity (KYC). Gated; unset → /api/kyc/* returns 503.
  STRIPE_IDENTITY_WEBHOOK_SECRET?: string;
  // A1 compliance — current agreement-doc versions, CSV "doc_id:version,…"
  // (e.g. "creator-agreement:2,tos:1"). Unlisted docs default to "1".
  AGREEMENT_VERSIONS?: string;

  // AvaWallet (Phase 2). Real money-in flag-gated OFF pending legal (§10.1).
  WALLET_TOPUP_ENABLED?: string;   // "1" enables Stripe top-up (set ONLY after legal)
  WALLET_RETURN_URL?: string;      // Checkout success/cancel return base
  STRIPE_SECRET_KEY?: string;
  STRIPE_WEBHOOK_SECRET?: string;
  STRIPE_PUBLISHABLE_KEY?: string; // public pk_test/pk_live — returned to the app for the in-app PaymentSheet

  // [PAY-CASHFREE-1] Inbound UPI. Cashfree, not Stripe: Stripe India requires a
  // registered company and avaTOK is an unregistered business (CLAUDE.md, "THERE IS NO
  // COMPANY"). Cashfree onboards unregistered merchants.
  //
  // Scope these PER ENVIRONMENT in wrangler.toml — sandbox keys in the staging block,
  // production keys in the top-level block. Bare `wrangler` resolves the TOP-LEVEL
  // block, which is production; everything goes through scripts/cf.sh.
  //
  // Absent ⇒ the routes 503. There is no test-key fallback: a payment rail that silently
  // works against the wrong environment is worse than one that is plainly off.
  CASHFREE_APP_ID?: string;
  CASHFREE_SECRET_KEY?: string;
  CASHFREE_WEBHOOK_SECRET?: string;
  CASHFREE_ENV?: string;           // "sandbox" | "production"
  CASHFREE_RETURN_URL?: string;    // where the browser lands after paying

  // [PAY-RAIL-1] The generic multi-gateway layer (lib/payments/*, routes/pay.ts).
  // Absent ⇒ that adapter's `configured(env)` is false and it simply does not appear in
  // `/api/pay/methods` — same "half-configured is off, not degraded" discipline as
  // Cashfree above. STRIPE_SECRET_KEY / STRIPE_WEBHOOK_SECRET already exist above (used
  // by the wallet top-up rail) and are REUSED for the international, non-INR adapter —
  // no new Stripe secret names, per spec §2.7.
  RAZORPAY_KEY_ID?: string;
  RAZORPAY_KEY_SECRET?: string;
  RAZORPAY_WEBHOOK_SECRET?: string;
  PAYTM_MID?: string;
  PAYTM_MERCHANT_KEY?: string;
  PAYTM_WEBSITE?: string;
  PAYTM_ENV?: string;              // "staging" | "production" — mirrors CASHFREE_ENV
  /** Overrides the host entirely. Set it when Paytm moves a domain again — they
   *  went paytm.in → paytmpayments.com mid-2026 and the docs' Production tab is
   *  the only authority on where production lives now. */
  PAYTM_HOST?: string;
  /** Where to send a buyer whose gateway returned them here by browser redirect.
   *  Defaults to the production site; set it to a preview origin when testing. */
  WEB_BASE_URL?: string;
  /** Where Paytm posts the transaction result. Defaults to this Worker's own
   *  /api/pay/paytm/webhook. Without a callbackUrl Paytm falls back to the
   *  static URL registered against websiteName, which for a staging merchant is
   *  Paytm's demo page — the payment succeeds and we never hear about it. */
  PAYTM_CALLBACK_URL?: string;

  // AvaPayout (Phase 4). Production transfers flag-gated OFF pending legal (§10.3).
  PAYOUT_ENABLED?: string;         // "1" enables Wise transfers (ONLY after legal)
  WISE_API_KEY?: string;
  // [TOKENS-FX-1] OPTIONAL Wise token for the FX RATES endpoint (lib/fx_rates.ts).
  // Separate from WISE_API_KEY (payout rail). Unset → free open.er-api.com is used.
  WISE_API_TOKEN?: string;
  WISE_PROFILE_ID?: string;
  WISE_ENV?: string;               // "production" | (default sandbox)

  // AvaTalk group conferencing — LiveKit REMOVED [CF-CALL-007A] (2026-07-24).
  // The Env interface no longer declares LIVEKIT_URL / LIVEKIT_API_KEY /
  // LIVEKIT_API_SECRET / LIVEKIT_REGIONS; group calls run on the Cloudflare
  // Realtime SFU path instead (CF_RT_SFU_APP_ID/CF_RT_SFU_APP_TOKEN, declared
  // above, consumed by routes/groupcall.ts). The underlying wrangler secrets/vars are
  // intentionally left orphaned in each environment (not git-recoverable once
  // deleted) — see Specs/CF-CUTOVER-AND-LIVEKIT-REMOVAL-RUNBOOK-2026-07-24.md
  // §4.4 for the deliberate later `wrangler secret delete` cleanup step.

  // R2-archive rollout flag (Specs/ABLY-TRANSPORT-R2-ARCHIVE-PROPOSAL.md).
  CHAT_ARCHIVE?: string;     // "1" → enqueue every sent message to R2 + D1 message_index (Phase 1)
  CHAT_ARCHIVE_V2?: string;  // "1" → InboxDO batched R2 jsonl cold archive (P8 chatArchiveV2)
  PARTY_ENABLED?: string;    // "1" → PartyKit realtime layer on (client opens party sockets); dark otherwise
  MSG_STATE_STORE?: string;  // "d1" → owner-private state (read/hide/call-log) reads+writes go to D1 (Phase 5)

  // Account key-escrow master (SECRET: `wrangler secret put KEY_WRAP_MASTER`). Wraps
  // each account's aek in key_backup so a D1 dump alone never exposes a usable key.
  KEY_WRAP_MASTER?: string;

  // Cloudflare AI Gateway (2026-06-18). When set, all Workers-AI + Google image
  // calls route through this gateway for cost logging, caching, and a hard spend
  // cap. AI_GATEWAY_ID = the gateway name/id; AI_GATEWAY_TOKEN = optional
  // cf-aig-authorization for authenticated gateways (Google image path).
  AI_GATEWAY_ID?: string;
  AI_GATEWAY_TOKEN?: string;   // cf-aig-authorization (authed gateway) — secret
  CF_ACCOUNT_ID?: string;      // for the gateway.ai.cloudflare.com base URL

  // OpenRouter — content-safety moderation (nvidia/nemotron-3.5-content-safety:free)
  // and the GenUI planner. Secret; set in secrets/secret-values.env.
  OPENROUTER_API_KEY?: string;
  OPENROUTER_MOD_MODEL?: string;        // override the field-moderation model id (Nemotron)
  OPENROUTER_SECURITY_MODEL?: string;   // LEGACY guardian model pin (honored; empty = reasoner ladder)
  OPENROUTER_STT_MODEL?: string;        // override the speech-to-text model id (default openai/whisper-large-v3)

  // AVA CORE Phase 0 (AVA-CORE-1): the ONE reasoner behind avaReason() (lib/ava_reason.ts).
  AVA_REASONER?: string;       // Workers-AI primary (default @cf/google/gemma-4-26b-a4b-it)
  AVA_REASONER_ALT?: string;   // OpenRouter fallback (default google/gemini-2.5-flash-lite)
  GUARDIAN_DEEP_MODEL?: string; // force a specific OpenRouter model for guardian deep pass (optional)

  // InboxDO retention (cost control). Days to keep messages in the per-user inbox
  // DO before pruning (the device keeps history locally + in Drive/R2 backup, so
  // the DO is a relay + offline buffer, not a permanent archive). UNSET/0 =
  // disabled (keep forever). Enable (e.g. "90") ONLY after confirming backups run.
  INBOX_RETENTION_DAYS?: string;

  // Live voice translation (Gemini 3.5 Live Translate). Unset → /api/translate/*
  // returns 503. The key never leaves the Worker — clients get ephemeral tokens.
  // Also powers the AvaAffiliate v2 marketing-asset kit (Nano Banana 2 images).
  GEMINI_API_KEY?: string;

  // Dedicated Gemini key for the AI Receptionist Live (speech-to-speech) calls +
  // its summary call, so receptionist spend is isolated to its own Google Cloud
  // project (avatok-live-receptionist-2026, project #7456307191, owner
  // hdavy2005@gmail.com). Falls back to GEMINI_API_KEY when unset. The key never
  // leaves the Worker (the caller only gets a DO WebSocket URL).
  RECEPTIONIST_GEMINI_API_KEY?: string;

  // Cloud Text-to-Speech service-account JSON (project avatok-avaglobal, SA
  // ava-tts@…), used by the CF receptionist engine to voice Ava in Hindi with the
  // natural WaveNet voice (hi-IN-Wavenet-E) via lib/google_tts.ts. Cloud TTS needs
  // an OAuth principal, not an API key — the Worker mints a token from this SA.
  // Absent → cfSpeak() falls back to the Deepgram/melotts path (nothing breaks).
  GOOGLE_TTS_SA_JSON?: string;
  RECEPT_CF_GOOGLE_VOICE?: string;   // override the hi-IN Google voice (default hi-IN-Wavenet-E)

  // [VERTEX-1] Vertex AI (aiplatform.googleapis.com) as the transport for the REST
  // Gemini calls — the surface with production quota for an India-scale user base.
  // Auth REUSES GOOGLE_TTS_SA_JSON above (its cloud-platform scope already covers
  // aiplatform), so there is NO new secret. Both are required for Vertex to engage:
  // unset VERTEX_PROJECT and every call falls back to generativelanguage.googleapis.com
  // exactly as before — that is the kill switch. See lib/vertex.ts for what is
  // deliberately NOT migrated (all Live/WebSocket lanes, File Search stores).
  VERTEX_PROJECT?: string;
  VERTEX_LOCATION?: string;          // default "global"; a region only for data residency
  AVA_VERTEX_TEXT_MODEL?: string;    // interactive Ava text + tool reasoning (default gemini-3.7-flash)

  // GenUI global template cache (Upstash Redis REST). URL is a [var]; TOKEN is a
  // secret. Absent → cache no-ops (compose every time; nothing breaks).
  UPSTASH_REDIS_REST_URL?: string;
  UPSTASH_REDIS_REST_TOKEN?: string;
  // GenUI kill-switch: "1" disables generative in-chat UI for everyone (else ON
  // for premium users with a connected app).
  GENUI_OFF?: string;

  // Ava Receptionist — override the Gemini Live model.
  // Defaults to gemini-3.1-flash-live-preview (verified on the Developer API).
  RECEPTIONIST_MODEL?: string;

  // App-store links on the /a/:linkId web preview (AvaAffiliate). Android-only
  // launch: APP_STORE_ID stays UNSET until a real App Store listing exists —
  // unset/empty ⇒ the App Store badge is not rendered at all. PLAY_PACKAGE_ID
  // is the Android applicationId (app/android/app/build.gradle.kts).
  APP_STORE_ID?: string;
  PLAY_PACKAGE_ID?: string;

  // Google Play Billing — server-side purchase-token verification (routes/
  // subscribe.ts → play.ts). PLAY_SERVICE_ACCOUNT_JSON is the full service-account
  // key JSON (secret). Unset → /api/subscribe/android/verify fails CLOSED (503,
  // reason:"play_unconfigured") so a forged token can never grant a tier. The
  // package the token is checked against is PLAY_PACKAGE_ID (above).
  PLAY_SERVICE_ACCOUNT_JSON?: string;
  AFFILIATE_TOKEN_SECRET?: string;
  AFFILIATE_PAYOUT_ALLOWLIST?: string;
  // [FREE-ENTRY-GATE-1 2026-09-04] Comma-separated Clerk uids, ADDITIVE to
  // ADMIN_UIDS, allowed to create/hold a free_entry listing while
  // freeEntryAllowlistOnly is true (config.ts) — same shape as
  // AFFILIATE_PAYOUT_ALLOWLIST above. See lib/free_entry_gate.ts.
  FREE_ENTRY_ALLOWLIST?: string;

  // R2 S3 API creds for presigned digital-download URLs (Phase 5). Unset → the
  // OLX download route streams bytes through the Worker as a fallback.
  R2_ACCOUNT_ID?: string;
  R2_ACCESS_KEY_ID?: string;
  R2_SECRET_ACCESS_KEY?: string;

  // Marketplace Phase 7 — AvaLive (Cloudflare Stream Live) + AvaConsult group
  // (Cloudflare Realtime SFU). All gated: unset → 503.
  STREAM_ACCOUNT_ID?: string;      // Cloudflare account id for Stream Live Inputs
  STREAM_API_TOKEN?: string;       // API token with Stream:Edit (secret)
  CALLS_APP_ID?: string;           // Cloudflare Realtime (Calls) SFU app
  CALLS_APP_SECRET?: string;       // (secret)
  // Refund-engine test clock (A2). TEST_CLOCK_ALLOWED="1" ONLY in staging vars;
  // production hard-refuses any offset.
  TEST_CLOCK_ALLOWED?: string;
  TEST_CLOCK_OFFSET_MS?: string;
  // DLQ alert recipient (defaults to hdavy2005@gmail.com).
  ALERT_EMAIL?: string;

  // PSTN voicemail platform (Canonical Architecture v1.0, Specs/PLAN-2026-07-16-
  // ava-receptionist-guardian-FINAL.md). Long random secret Vobiz's webhook URLs
  // carry as a trailing path segment (routes/pstn.ts). Unset → falls back to a
  // fixed probe-grade constant in pstn.ts (fine for the Phase-0 wiring probe;
  // production should set this via `wrangler secret put VOBIZ_WEBHOOK_SECRET`).
  VOBIZ_WEBHOOK_SECRET?: string;
  // [WELCOME-100-1] Shared secret for the one-time welcome-bonus backfill route
  // (`POST /api/admin/welcome-backfill/<secret>` — same trailing-path-segment
  // scheme as VOBIZ_WEBHOOK_SECRET). Fails CLOSED when unset; set via
  // `wrangler secret put WELCOME_BACKFILL_SECRET`.
  WELCOME_BACKFILL_SECRET?: string;
  // [TOKENS-100-GRANT-1] Shared secret for the one-time DESTRUCTIVE token hard-reset
  // route (`POST /api/admin/token-hard-reset/<secret>` — same trailing-path-segment
  // scheme as WELCOME_BACKFILL_SECRET). Fails CLOSED when unset; set via
  // `wrangler secret put TOKEN_RESET_SECRET` only for the one-time run, then unset.
  TOKEN_RESET_SECRET?: string;
  // [ADMIN-DELETE-USER-1] Shared secret for the admin "delete ANOTHER user" route
  // (`POST /api/admin/delete-user/<secret>` — same trailing-path-segment scheme as
  // TOKEN_RESET_SECRET). Fails CLOSED when unset; set via
  // `wrangler secret put ADMIN_DELETE_SECRET`.
  ADMIN_DELETE_SECRET?: string;
  // Vobiz account API credentials — required to fetch recording files from
  // media.vobiz.ai (401 without them; verified 2026-07-16). Set via
  // `wrangler secret put VOBIZ_AUTH_ID` / `VOBIZ_AUTH_TOKEN`.
  VOBIZ_AUTH_ID?: string;
  VOBIZ_AUTH_TOKEN?: string;
}

/** Stable async marketplace replay job.  The negotiation id is the durable
 * identity; listing/version remains as a human/debugging lookup only. */
export interface MktAudioMsg {
  negotiationId: string;
  artifactId: string;
  conv: string;
  sellerUid: string;
  buyerUid: string;
  listingId: string;
  contentVersion: number;
  outcome: string;
  bubble: string;
  agreed: number;
  currency: string;
  transcript: Array<{ speaker: string; text: string }>;
  persona?: string;
  lang?: string;
  buyerVoice?: string | null;
  transcriptEn?: Array<{ speaker: string; text: string }>;
  transcriptI18n?: Record<string, Array<{ speaker: string; text: string }>>;
  summary?: string;
  pendingOwnerApproval?: boolean;
  enqueuedAt?: number;
}
