// Double-entry ledger + escrow primitives (Phase 2, marketplace plan §4).
//
// Balance authority for USER accounts = WalletDO (idempotent on op_id; emits the
// ledger row to Q_WALLET itself — single writer). Escrow + platform buckets are
// LEDGER-ONLY accounts in D1 (avatok-wallet `wallet_accounts`) — nothing races on
// them, the Q_WALLET consumer recomputes their balances from the ledger.
//
//   hold(uid, orderId, amount)        user → escrow:<orderId>   purchase_hold
//   release(orderId, creatorId)       escrow → user (80%)       escrow_release
//                                     escrow → platform:fees    fee (20%)
//   refund(orderId, uid, amount)      escrow → user             refund (partial OK)
//
// Consumed by Phases 6–7 (bookings/events) + the admin money console.
import type { Env } from "./types";
import { walletOp } from "./routes/wallet";

export const PLATFORM_FEE_RATE = 0.20; // §4: 80% creator / 20% platform
export const ACCT_PLATFORM_FEES = "platform:fees";
export const acctUser = (uid: string) => `user:${uid}`;
export const acctEscrow = (orderId: string) => `escrow:${orderId}`;

export interface LedgerResult { ok: boolean; status: number; body: any; }

/** Ledger-only row (no user-account side → no DO op), e.g. escrow→platform fee. */
async function sendLedgerRow(env: Env, id: string, debit: string, credit: string, amount: number, type: string, ref: string | null, meta: object | null): Promise<void> {
  await env.Q_WALLET.send({ id, ts: Date.now(), amount, ledger: { debit, credit, type, ref, meta: meta ? JSON.stringify(meta) : null } });
}

/** Escrow bucket state: prefer the consumer-maintained account row; fall back to a live ledger Σ (covers queue lag). */
export async function escrowBalance(env: Env, orderId: string): Promise<number> {
  const id = acctEscrow(orderId);
  const acct = await env.DB_WALLET.prepare("SELECT balance FROM wallet_accounts WHERE id=?1").bind(id).first<{ balance: number }>();
  if (acct) return Number(acct.balance);
  const sum = await env.DB_WALLET.prepare(
    "SELECT COALESCE((SELECT SUM(amount) FROM wallet_ledger WHERE credit=?1),0) - COALESCE((SELECT SUM(amount) FROM wallet_ledger WHERE debit=?1),0) AS bal",
  ).bind(id).first<{ bal: number }>();
  return Number(sum?.bal ?? 0);
}

/**
 * hold — move coins from the buyer's wallet into the order's escrow bucket.
 * Fails 402 if the buyer's spendable balance is insufficient. Idempotent on
 * opId (defaults to `hold:<orderId>` — one hold per order).
 */
export async function hold(env: Env, uid: string, orderId: string, amount: number, opts?: { opId?: string; title?: string; app?: string }): Promise<LedgerResult> {
  amount = Math.trunc(Number(amount));
  if (!(amount > 0)) return { ok: false, status: 400, body: { error: "amount>0 required" } };
  const opId = opts?.opId ?? `hold:${orderId}`;
  const r = await walletOp(env, uid, {
    op: "spend", uid, amount, type: "spend", app_name: opts?.app ?? "escrow", ref: orderId, op_id: opId,
    ledger: { debit: acctUser(uid), credit: acctEscrow(orderId), type: "purchase_hold", ref: orderId, meta: JSON.stringify({ title: opts?.title ?? null, gross: amount }) },
  });
  // A4: purchase receipt on every successful (non-duplicate) hold. Best-effort.
  if (r.status === 200 && !r.body?.duplicate) {
    try { await sendReceipt(env, uid, "purchase", { orderId, title: opts?.title ?? `Order ${orderId}`, lines: [{ label: opts?.title ?? `Order ${orderId}`, amount }], total: amount }); } catch { /* best-effort */ }
  }
  return { ok: r.status === 200, status: r.status, body: r.body };
}

/**
 * [PAY-CASHFREE-1] Gateway-funded escrow. Money the buyer paid at a payment gateway,
 * moved straight into the order's escrow bucket WITHOUT ever being a wallet balance.
 *
 * WHY THIS EXISTS. `hold()` debits `user:<uid>` through the WalletDO, so it can only
 * spend a balance the buyer already funded — the top-up-then-spend two-step the whole
 * Cashfree lane exists to remove. This debits `external:cashfree` instead and credits
 * the SAME `escrow:<orderId>`, so everything downstream — release(), the 80/20 split,
 * commercial_settlement.ts, refund() — works unchanged. That is the entire reason to
 * shape it this way rather than inventing a parallel settlement path.
 *
 * REJECTED ALTERNATIVE: credit the wallet with the ticket price on `PAID`, then call
 * the existing hold(). It reuses more code, but it makes the money briefly the buyer's
 * SPENDABLE BALANCE — so a failure between the two steps leaves them holding tokens
 * instead of a ticket, and a reverse-to-source refund then has to claw back a balance
 * they may already have spent elsewhere. Direct charge has no such window.
 *
 * LEDGER-ONLY, so there is no DO to enforce idempotency for us. The `id` on the queue
 * message is the idempotency key (the consumer's INSERT is ON CONFLICT DO NOTHING), so
 * a replayed webhook cannot double-credit escrow. Callers MUST pass a stable opId
 * derived from the gateway's own order id, never a random one.
 *
 * `uid` is recorded in meta, not in the debit account: the buyer's wallet is not party
 * to this movement, but their statement still needs to show the purchase.
 */
export const ACCT_EXTERNAL = (source: string) => `external:${source}`;

export async function holdExternal(
  env: Env,
  orderId: string,
  amount: number,
  opts: { opId: string; uid?: string | null; source?: string; title?: string; ref?: string | null },
): Promise<LedgerResult> {
  amount = Math.trunc(Number(amount));
  if (!(amount > 0)) return { ok: false, status: 400, body: { error: "amount>0 required" } };
  if (!opts.opId) return { ok: false, status: 400, body: { error: "opId required" } };
  const source = opts.source ?? "cashfree";
  await sendLedgerRow(
    env,
    opts.opId,
    ACCT_EXTERNAL(source),
    acctEscrow(orderId),
    amount,
    "external_purchase_hold",
    orderId,
    { source, gateway_ref: opts.ref ?? null, uid: opts.uid ?? null, title: opts.title ?? null, gross: amount },
  );
  return { ok: true, status: 200, body: { ok: true, amount, source } };
}

/**
 * [PAY-REFUND-1] The mirror of holdExternal: escrow → back out to the gateway.
 *
 * Called ONLY after the gateway has confirmed it reversed the payment to the payer's
 * source (their UPI handle). This records where the money went; it does not move it at
 * the gateway. Refunding to a wallet instead uses the ordinary refund().
 */
export async function refundExternal(
  env: Env,
  orderId: string,
  amount: number,
  opts: { opId: string; uid?: string | null; source?: string; reason?: string; ref?: string | null },
): Promise<LedgerResult> {
  amount = Math.trunc(Number(amount));
  if (!(amount > 0)) return { ok: false, status: 400, body: { error: "amount>0 required" } };
  if (!opts.opId) return { ok: false, status: 400, body: { error: "opId required" } };
  const source = opts.source ?? "cashfree";
  const avail = await escrowBalance(env, orderId);
  // Refusing rather than clamping: a short escrow here means the queue consumer is
  // behind or the hold never landed, and silently reversing less than the buyer paid
  // is the worst possible way to discover that.
  if (avail < amount) {
    return { ok: false, status: 409, body: { error: "escrow below refund amount", available: avail, amount } };
  }
  await sendLedgerRow(
    env,
    opts.opId,
    acctEscrow(orderId),
    ACCT_EXTERNAL(source),
    amount,
    "external_refund",
    orderId,
    { source, gateway_ref: opts.ref ?? null, uid: opts.uid ?? null, reason: opts.reason ?? null },
  );
  return { ok: true, status: 200, body: { ok: true, amount, source } };
}

/**
 * release — settle a completed order: 80% to the creator (into the standard
 * 7-day earnings hold — shows as "pending" in the UI), 20% platform fee.
 * Gross defaults to the escrow bucket's full balance. Idempotent per order.
 */
export async function release(env: Env, orderId: string, creatorId: string, opts?: { title?: string; app?: string; feeRate?: number; gross?: number }): Promise<LedgerResult> {
  // Phase 7: pass opts.gross for a PARTIAL release (R2 pro-rata, R5 split);
  // default stays "everything left in the bucket".
  const avail = await escrowBalance(env, orderId);
  const gross = opts?.gross != null ? Math.min(Math.trunc(opts.gross), avail) : avail;
  if (!(gross > 0)) return { ok: false, status: 409, body: { error: "escrow empty or not yet settled", orderId } };
  const rate = opts?.feeRate ?? PLATFORM_FEE_RATE;
  const fee = Math.round(gross * rate);
  const net = gross - fee;
  const meta = { title: opts?.title ?? null, gross, fee, net, fee_rate: rate, counterpart: creatorId };

  const r = await walletOp(env, creatorId, {
    op: "earn", uid: creatorId, amount: net, commission: fee, app_name: opts?.app ?? "escrow", ref: orderId, op_id: `rel:${orderId}`,
    ledger: { debit: acctEscrow(orderId), credit: acctUser(creatorId), type: "escrow_release", ref: orderId, meta: JSON.stringify(meta) },
  });
  if (r.status !== 200) return { ok: false, status: r.status, body: r.body };
  if (fee > 0) {
    await sendLedgerRow(env, `fee:${orderId}`, acctEscrow(orderId), ACCT_PLATFORM_FEES, fee, "fee", orderId, { title: opts?.title ?? null, gross, fee_rate: rate });
  }
  return { ok: true, status: 200, body: { ok: true, orderId, gross, net, fee, ...r.body } };
}

/**
 * feeFromEscrow — [LIST-FREE-1] move `amount` from an escrow bucket to
 * platform:fees with NO user-account leg. Needed by the free lane, where the
 * creator's held cap is spent on platform usage and the creator earns nothing
 * from it: `release()` cannot express that because WalletDO `earn` refuses
 * amount<=0, so a feeRate of 1 always 400s. Ledger-only, so idempotent on the
 * row id (wallet_ledger PK) — pass a stable opId per settlement.
 */
export async function feeFromEscrow(env: Env, orderId: string, amount: number, opId: string, meta?: object): Promise<LedgerResult> {
  amount = Math.trunc(Number(amount));
  if (!(amount > 0)) return { ok: false, status: 400, body: { error: "amount>0 required" } };
  const avail = await escrowBalance(env, orderId);
  if (amount > avail) return { ok: false, status: 409, body: { error: "fee exceeds escrow balance", available: avail } };
  await sendLedgerRow(env, opId, acctEscrow(orderId), ACCT_PLATFORM_FEES, amount, "fee", orderId, meta ?? null);
  return { ok: true, status: 200, body: { ok: true, orderId, amount } };
}

/**
 * refund — return coins from escrow to the buyer (partial OK; spendable
 * immediately). opId must be unique per refund (`refund:<orderId>` default —
 * pass your own for multiple partials on one order).
 */
export async function refund(env: Env, orderId: string, uid: string, amount: number, opts?: { opId?: string; reason?: string; title?: string }): Promise<LedgerResult> {
  amount = Math.trunc(Number(amount));
  if (!(amount > 0)) return { ok: false, status: 400, body: { error: "amount>0 required" } };
  const avail = await escrowBalance(env, orderId);
  if (amount > avail) return { ok: false, status: 409, body: { error: "refund exceeds escrow balance", available: avail } };
  const opId = opts?.opId ?? `refund:${orderId}`;
  const r = await walletOp(env, uid, {
    op: "credit", uid, amount, type: "refund", app_name: "escrow", ref: orderId, op_id: opId,
    ledger: { debit: acctEscrow(orderId), credit: acctUser(uid), type: "refund", ref: orderId, meta: JSON.stringify({ title: opts?.title ?? null, reason: opts?.reason ?? null, amount }) },
  });
  return { ok: r.status === 200, status: r.status, body: r.body };
}

/**
 * [AGENT-LIVE-1 / M1] Read-only lookup of a previously recorded WalletDO op
 * result by opId — never mutates, never re-applies. Used by agent-live money
 * job recovery (refund/release retries) so a lost response is not mistaken
 * for "nothing happened" (R2 §2.6/§2.3: an empty escrow after a lost refund
 * response is not failure).
 */
export async function walletOpResult(env: Env, uid: string, opId: string): Promise<{ found: boolean; result: any }> {
  const r = await walletOp(env, uid, { op: "op_result", uid, op_id: opId });
  if (r.status !== 200) return { found: false, result: null };
  return { found: !!r.body?.found, result: r.body?.result ?? null };
}

export interface FrozenRelease {
  orderId: string;
  beneficiaryUid: string;
  gross: number;
  fee: number;
  net: number;
  title?: string;
}

/**
 * [AGENT-LIVE-1 / M1] Exact-settlement adapter for agent-live bookings. Unlike
 * `release()`, this NEVER reads `escrowBalance` and NEVER recomputes gross/
 * fee/net — every amount is frozen on the immutable `agent_live_decisions`
 * row and passed in by the caller (worker/src/lib/agent_live/money.ts). It
 * replays the SAME two legs `release()` uses (creator earn + platform fee),
 * with the SAME op ids (`rel:<orderId>` / `fee:<orderId>`), so a retry after a
 * partial success (creator leg landed, fee leg lost) reissues only the
 * missing leg with the ORIGINAL numbers rather than recomputing anything from
 * residual escrow. Idempotent: WalletDO's own op_id dedupe makes a repeated
 * `earn` call a no-op replay, and the fee leg's ledger row id is the queue
 * consumer's own dedupe key.
 */
export async function releaseExact(env: Env, d: FrozenRelease): Promise<LedgerResult> {
  if (!(d.gross > 0) || !(d.fee >= 0) || !(d.net >= 0) || d.fee + d.net !== d.gross) {
    return { ok: false, status: 400, body: { error: "invalid frozen release amounts", d } };
  }
  const relOpId = `rel:${d.orderId}`;
  const feeOpId = `fee:${d.orderId}`;
  const feeRate = d.gross > 0 ? d.fee / d.gross : 0;
  const meta = { title: d.title ?? null, gross: d.gross, fee: d.fee, net: d.net, fee_rate: feeRate, counterpart: d.beneficiaryUid };
  const r = await walletOp(env, d.beneficiaryUid, {
    op: "earn", uid: d.beneficiaryUid, amount: d.net, commission: d.fee, app_name: "agent_live", ref: d.orderId, op_id: relOpId,
    ledger: { debit: acctEscrow(d.orderId), credit: acctUser(d.beneficiaryUid), type: "escrow_release", ref: d.orderId, meta: JSON.stringify(meta) },
  });
  if (r.status !== 200) return { ok: false, status: r.status, body: r.body };
  if (d.fee > 0) {
    await sendLedgerRow(env, feeOpId, acctEscrow(d.orderId), ACCT_PLATFORM_FEES, d.fee, "fee", d.orderId, { title: d.title ?? null, gross: d.gross, fee_rate: feeRate });
  }
  return { ok: true, status: 200, body: { ok: true, orderId: d.orderId, gross: d.gross, net: d.net, fee: d.fee, ...r.body } };
}

/**
 * donation — Phase 7 live tips (universal §4): instant to the creator (NO
 * escrow, NO 7-day hold — it's a gift, not a deliverable), minus the 20%
 * platform fee. Three balanced rows: buyer→creator gross (type donation),
 * ledger-only creator→platform:fees fee, and the creator credit is the net.
 * Idempotent on `don:<donationId>:*` op_ids.
 */
export async function donation(env: Env, buyer: string, creator: string, amount: number, donationId: string, opts?: { title?: string; feeRate?: number }): Promise<LedgerResult & { net: number; fee: number }> {
  amount = Math.trunc(Number(amount));
  if (!(amount > 0)) return { ok: false, status: 400, body: { error: "amount>0 required" }, net: 0, fee: 0 };
  const rate = opts?.feeRate ?? PLATFORM_FEE_RATE;
  const fee = Math.round(amount * rate);
  const net = amount - fee;
  const ref = `don:${donationId}`;
  const meta = JSON.stringify({ title: opts?.title ?? "Live donation", gross: amount, fee, net, fee_rate: rate });
  // 1. Debit the buyer (gross) — carries the buyer→creator donation row.
  const d = await walletOp(env, buyer, {
    op: "spend", uid: buyer, amount, type: "spend", app_name: "avalive", counterparty_uid: creator, ref, op_id: `${ref}:spend`,
    ledger: { debit: acctUser(buyer), credit: acctUser(creator), type: "donation", ref, meta },
  });
  if (d.status !== 200) return { ok: false, status: d.status, body: d.body, net: 0, fee: 0 };
  // 2. Credit the creator the NET, spendable immediately (no hold).
  await walletOp(env, creator, { op: "credit", uid: creator, amount: net, type: "donation", app_name: "avalive", counterparty_uid: buyer, ref, op_id: `${ref}:credit` });
  // 3. Ledger-only fee row balances the creator's account (gross in − fee out = net).
  if (fee > 0) await sendLedgerRow(env, `${ref}:fee`, acctUser(creator), ACCT_PLATFORM_FEES, fee, "fee", ref, { title: "Donation fee", gross: amount, fee_rate: rate });
  return { ok: true, status: 200, body: { ok: true, gross: amount, net, fee, buyer_balance: d.body?.balance }, net, fee };
}

/**
 * adjust — admin-only correction. Positive amount credits the user
 * (platform:fees → user), negative debits (user → platform:fees). Always type
 * 'adjustment', always through WalletDO + ledger (never D1-only).
 */
export async function adjust(env: Env, uid: string, amount: number, reason: string, adminId: string, opId: string): Promise<LedgerResult> {
  amount = Math.trunc(Number(amount));
  if (!amount) return { ok: false, status: 400, body: { error: "non-zero amount required" } };
  const meta = JSON.stringify({ reason, admin: adminId, amount });
  const r = amount > 0
    ? await walletOp(env, uid, { op: "credit", uid, amount, type: "refund", app_name: "admin", ref: `adj:${opId}`, op_id: opId, ledger: { debit: ACCT_PLATFORM_FEES, credit: acctUser(uid), type: "adjustment", ref: `adj:${opId}`, meta } })
    : await walletOp(env, uid, { op: "spend", uid, amount: -amount, type: "spend", app_name: "admin", ref: `adj:${opId}`, op_id: opId, ledger: { debit: acctUser(uid), credit: ACCT_PLATFORM_FEES, type: "adjustment", ref: `adj:${opId}`, meta } });
  return { ok: r.status === 200, status: r.status, body: r.body };
}

// ---------------------------------------------------------------------------
// Receipts (A4) — Cloudflare Email Service (Brevo fallback) via Q_EMAIL. The
// user's email comes from Clerk (D1 stores only email hashes). Best-effort:
// failures never block money ops.
// ---------------------------------------------------------------------------
export async function clerkEmail(env: Env, uid: string): Promise<string | null> {
  if (!env.CLERK_SECRET_KEY) return null;
  try {
    const r = await fetch(`https://api.clerk.com/v1/users/${uid}`, { headers: { Authorization: `Bearer ${env.CLERK_SECRET_KEY}` } });
    if (!r.ok) return null;
    const u = (await r.json()) as any;
    const primary = (u.email_addresses ?? []).find((e: any) => e.id === u.primary_email_address_id) ?? (u.email_addresses ?? [])[0];
    return primary?.email_address ?? null;
  } catch { return null; }
}

export interface ReceiptLine { label: string; amount: number; } // coins (1 = $0.01)
const inr = (tokens: number) => `\u20b9${tokens}`;

export async function sendReceipt(env: Env, uid: string, kind: "topup" | "purchase", opts: { orderId: string; title: string; lines: ReceiptLine[]; total: number; date?: number }): Promise<boolean> {
  const email = await clerkEmail(env, uid);
  if (!email) return false;
  const when = new Date(opts.date ?? Date.now()).toUTCString();
  const rows = opts.lines.map((l) => `<tr><td style="padding:6px 12px 6px 0;color:#444">${l.label}</td><td style="padding:6px 0;text-align:right">${inr(l.amount)}</td></tr>`).join("");
  const html = `
  <div style="font-family:system-ui,-apple-system,sans-serif;max-width:480px;margin:0 auto;padding:24px">
    <h2 style="margin:0 0 4px">AvaTok receipt</h2>
    <p style="color:#666;margin:0 0 16px">${kind === "topup" ? "Wallet top-up" : "Purchase"} — ${when}</p>
    <p style="margin:0 0 16px;font-weight:600">${opts.title}</p>
    <table style="width:100%;border-collapse:collapse;border-top:1px solid #eee">${rows}
      <tr><td style="padding:10px 12px 0 0;font-weight:700;border-top:1px solid #eee">Total</td><td style="padding:10px 0 0;text-align:right;font-weight:700;border-top:1px solid #eee">${inr(opts.total)}</td></tr>
    </table>
    <p style="color:#999;font-size:12px;margin-top:20px">Payment source: ${kind === "topup" ? "card (Stripe)" : "AvaTok wallet"} · Order ${opts.orderId}<br>1 Token = $0.01</p>
  </div>`;
  try {
    await env.Q_EMAIL.send({ to: email, subject: `Your AvaTok receipt — ${opts.title}`, html });
    return true;
  } catch { return false; }
}
