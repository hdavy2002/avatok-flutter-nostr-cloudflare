// AvaWallet routes (Phase 2, §10.1). Balance math is delegated to the per-user
// WalletDO; D1 (avatok-wallet) is the audit trail / history. Top-up via Stripe is
// FLAG-GATED OFF in production pending legal (WALLET_TOPUP_ENABLED).
//
//   POST /api/wallet/topup        → create a Stripe Checkout session (flag-gated, legacy/web)
//   POST /api/wallet/topup/intent → create a Stripe PaymentIntent for the in-app
//                                   PaymentSheet (no browser redirect, native UI)
//   POST /webhooks/stripe         → credit coins on checkout.session.completed
//                                   OR payment_intent.succeeded (in-app top-ups)
//   POST /api/wallet/spend        → debit buyer, credit creator (−commission, 7d hold)
//   GET  /api/wallet/balance      → live balance (from DO)
//   GET  /api/wallet/transactions → ledger history (from D1)
//   GET  /api/wallet/earnings     → holds + released (from D1)
//   GET  /api/wallet/live         → WebSocket balance stream (DO)
import type { Env } from "../types";
import { json } from "../util";
import { requireUser, isFail } from "../authz";
import { track } from "../hooks";
import { brainIngest } from "../lib/brain_ingest";
import { notifyUser } from "../notify";
import { withIdempotency, rateLimit, RL } from "../money";
import { acctUser, sendReceipt } from "../ledger";
import { payAffiliateOnTopup, reverseAffiliate } from "./affiliate";
import { readConfig } from "./config";
import { getSub } from "./plans";
import { subscribeWebhookEvent } from "./subscribe";
import { listVoidedPlayPurchases, verifyPlayProduct } from "../play";
import type { MessengerMedia, MessengerQualitySku } from "../lib/messenger_call_billing";
// [WALLET-TXMETA-1] wallet_statement.ts already imports walletOp from here; this
// back-reference is only ever CALLED from inside an async handler (never at
// module-init), so the ESM cycle resolves safely — function declarations are
// hoisted before either module body runs.
import { txDetailFor, labelFor } from "./wallet_statement";

// Token economics — CANONICAL, site-wide (incl. AvaPayout): 1 token = \u20b91.
// This is an owner pricing decision, FIXED, not an FX conversion (see
// lib/fx_rates.ts). India is the only market for now.
//
// [TOKENS-INR-RAIL-1 2026-08-28, owner decision] THE RUPEE IS THE DEFAULT
// CURRENCY OF THE MONEY-IN RAIL, not just of the display layer.
//
// Before this change money-OUT was already INR (upi_payout.ts:
// gross_inr_paise = tokens * 100) and the app's PaymentIntent rail could ASK
// for INR, but the WEB Checkout rail (walletTopup, below) hard-wired
// `currency: "usd"`. So avatok.ai published "1 token = \u20b91" while Stripe
// actually charged $0.01 per token. A payment-gateway reviewer comparing the
// published price against a real charge fails you for exactly that, and it was
// also simply untrue. Both halves now speak rupees.
//
// TOKENS_PER_USD survives ONLY for the two rails genuinely denominated in US
// dollars upstream, which cannot be re-priced from this file:
//   * Google Play (PLAY_TOPUP_PRODUCTS) - fixed USD-defined SKUs; Play converts
//     to the buyer's local currency at its own rate.
//   * the legacy `{ usd_cents }` body on /topup/intent, kept working for app
//     builds shipped before this change.
// It is NOT a price anyone is quoted. Do NOT reintroduce it as one.
//
// NOTE: "coins" is the legacy wire/DB name for a token at the SAME value, so no
// stored balance changed. Internal D1 columns (amount_coins), Stripe
// `metadata[coins]`, and analytics prop keys keep their legacy names to protect
// live balances / in-flight payments / dashboards; the user-facing term is "Tokens".
const TOKENS_PER_USD = 100;
const usdCentsForTokens = (tokens: number) => Math.round((tokens * 100) / TOKENS_PER_USD); // tokens → USD cents (== tokens)
/** Tokens → paise. The whole rail, exactly: 1 token = \u20b91 = 100 paise. */
const paiseForTokens = (tokens: number) => tokens * 100;
/** Default money-in currency. India is the only market (see the PRODUCT PIVOT). */
const TOPUP_CURRENCY = "inr";
// [TOKENS-FX-1] Min lowered 500→100 tokens so the region-aware quote presets
// ($1 minimum / ₹100 minimum, both = 100 tokens) are actually payable on the
// Stripe rail. Play's own floor stays $5 (its lowest fixed product).
const MIN_TOPUP = 100, MAX_TOPUP = 50_000; // in TOKENS: \u20b9100 .. \u20b950,000

function walletStub(env: Env, uid: string) {
  return env.WALLET_DO.get(env.WALLET_DO.idFromName(uid));
}

// ---------------------------------------------------------------------------
// [AI-WALLET-SPENDABLE-2] Typed WalletDO operation union (Part VIII §52/§57 of
// Specs/ROOT-CAUSE-REPORT-RECURRING-ISSUES-2026-07-25.md — "a required
// allow_free param gives no compile-time safety... walletOp takes an untyped
// object and the DO does body = await req.json() as any, so TypeScript
// enforcement evaporates at the fetch boundary"). This union restores
// COMPILE-TIME enforcement at every call site: `allow_free` is a REQUIRED,
// NO-DEFAULT boolean on `reserve` and `consume_reserved` — every caller must
// explicitly choose `true` (internal AI/feature cost — free/bonus/paid
// headroom) or `false` (campaign escrow/payouts — real, withdrawable money,
// paid-only headroom). do/wallet.ts ALSO rejects a missing/non-boolean
// allow_free at RUNTIME with 400, because a stale/generated client can still
// send an untyped body over the wire — this union is the compile-time half,
// not a replacement for it.
//
// Every OTHER field is intentionally loose (`Record<string, unknown>`
// intersected in via WalletOpBase) rather than exhaustively typed, because
// dozens of call sites across worker/src (ledger.ts, referral.ts,
// affiliate.ts, payout.ts, translate.ts, avavision.ts, avavoice.ts, …) build
// these objects with call-site-specific extra fields (ledger rows, meta,
// counterparty_uid, commission, …) that this change does not own or need to
// re-type. The index signature deliberately disables TypeScript's excess-
// property check for object literals so none of those call sites need to
// change — ONLY the two fields that were the actual, provable bug
// (allow_free on reserve/consume_reserved) are now enforced.
// ---------------------------------------------------------------------------
type WalletOpBase = Record<string, unknown> & { uid?: string; op_id?: string; app_name?: string; ref?: string };

export type WalletOperation =
  | (WalletOpBase & { op: "balance" })
  // [AGENT-LIVE-1 / M1] Read-only replay-cache lookup by op_id — added to this
  // union (not owned by WS-D, but required for `ledger.ts` `walletOpResult`
  // to compile) so agent-live refund/release recovery can distinguish "this
  // op already ran" from "nothing happened yet" without guessing from the
  // eventually-consistent escrow balance.
  | (WalletOpBase & { op: "op_result"; op_id: string })
  | (WalletOpBase & { op: "credit"; amount: number })
  | (WalletOpBase & { op: "promo_credit"; amount: number })
  | (WalletOpBase & { op: "hard_reset"; amount?: number })
  | (WalletOpBase & { op: "spend"; amount: number; allow_free?: boolean })
  | (WalletOpBase & { op: "earn"; amount: number })
  | (WalletOpBase & { op: "debit_hold"; amount: number })
  | (WalletOpBase & { op: "release" })
  // [AVA-CAMP-B1-WALLET] escrow ops — `allow_free` is MANDATORY on both
  // `reserve` and `consume_reserved`, with NO DEFAULT.
  | (WalletOpBase & { op: "reserve"; amount: number; ref: string; allow_free: boolean; expires_at?: number })
  // [AFF-G6-WALLET-1] §4.6: optional `type` labels the audit/statement row the
  // DO writes on consume. Omitted (every existing campaign caller) → the DO
  // still writes "campaign_call". A payout passes `type: "payout"` so it is not
  // filed in the user's statement and `wallet_ledger` as a campaign charge.
  | (WalletOpBase & { op: "consume_reserved"; amount: number; ref: string; allow_free: boolean; type?: string })
  | (WalletOpBase & { op: "release_reservation"; ref: string })
  // [AI-WALLET-SPENDABLE-2] atomic AI-accrual settlement — ONE DO round trip,
  // never a Worker-side read-modify-write across two separate walletOp calls.
  // Exclusively for allow_free:true (AI-metered) reservations — the DO
  // refuses to settle a campaign/payout reservation this way.
  | (WalletOpBase & { op: "settle_ai_cost"; ref: string; actual_cost_micro_usd: number; capability?: string })
  // [AI-BUDGET-AUTH-1] Strongly-consistent per-account free-AI budget.
  // Reserve before provider work, then settle actual usage or release.
  | (WalletOpBase & {
      op: "ai_budget_reserve"; request_id: string; day: string;
      input_tokens: number; output_tokens: number; cost_micro_usd: number;
      daily_input_limit: number; daily_output_limit: number; daily_cost_limit: number;
      turn_limit: number;
    })
  | (WalletOpBase & {
      op: "ai_budget_settle"; request_id: string; day: string;
      input_tokens: number; output_tokens: number; cost_micro_usd: number;
    })
  | (WalletOpBase & { op: "ai_budget_release"; request_id: string; day: string })
  // Per-account unrecovered-cost exposure uses reserve/settle/release so
  // concurrent metered jobs cannot all pass below a stale completed-loss total.
  | (WalletOpBase & { op: "ai_unrecovered_status"; day: string })
  | (WalletOpBase & {
      op: "ai_unrecovered_reserve"; request_id: string; day: string;
      amount_micro_usd: number; daily_limit_micro_usd: number;
    })
  | (WalletOpBase & {
      op: "ai_unrecovered_settle"; request_id: string; day: string;
      amount_micro_usd: number;
    })
  | (WalletOpBase & { op: "ai_unrecovered_release"; request_id: string; day: string })
  // Account-deletion cascade hook — clears the sub-cent AI remainder and
  // releases any stray AI-job reservations WITHOUT touching balance/free/bonus.
  | (WalletOpBase & { op: "clear_ai_remainder" })
  // Server-authoritative human audio/video participant-minute pool. This is
  // intentionally an internal WalletDO operation; no client-facing wallet API
  // shape changes and the route is unreachable while the billing flag is dark.
  | (WalletOpBase & {
      op: "call_usage_consume";
      participant_seconds: number;
      media: "audio" | "video";
    })
  | MessengerCallWalletOperation;

// [MESSENGER-CALL-BILLING-FOUNDATION] Caller-only daily allowance/tick
// operation. This is intentionally a different op from call_usage_consume:
// the latter is the dark legacy monthly/per-seat meter and must retain its
// wire semantics. The payer is the WalletDO uid passed to walletOp(); there is
// deliberately no payer_uid or callee wallet field in this contract.
export interface MessengerCallUsageConsumeOperation {
  op: "messenger_call_usage_consume";
  op_id: string;
  call_id: string;
  authorization_id: string;
  day: string;
  wall_seconds: number;
  media: MessengerMedia;
  quality_sku: MessengerQualitySku;
  /** Frozen by the authorization row; never supplied by a callee. */
  price_version: number;
  rate_centitokens_per_participant_minute: number;
  daily_audio_allowance_participant_seconds: number;
  allow_free: boolean;
  /** Paid ticks must consume this caller-owned reservation. */
  reservation_ref?: string;
}

export interface MessengerCallUsageStatusOperation {
  op: "messenger_call_usage_status";
  day: string;
  daily_audio_allowance_participant_seconds: number;
}

/** Read-only server authority for a caller's active Messenger reservation. */
export interface MessengerCallReservationStatusOperation {
  op: "messenger_call_reservation_status";
  reservation_ref: string;
}

export type MessengerCallWalletOperation = WalletOpBase & (MessengerCallUsageConsumeOperation | MessengerCallUsageStatusOperation | MessengerCallReservationStatusOperation);

export async function walletOp(env: Env, uid: string, op: WalletOperation): Promise<{ status: number; body: any }> {
  const r = await walletStub(env, uid).fetch("https://wallet/op", {
    method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(op),
  });
  return { status: r.status, body: await r.json().catch(() => ({})) };
}

/**
 * Atomic caller-funded Messenger tick. The uid is the payer authority and is
 * supplied separately from the operation body; callee identity is intentionally
 * absent so this helper cannot debit a second WalletDO by accident.
 */
export async function consumeMessengerCallUsage(
  env: Env,
  uid: string,
  args: Omit<MessengerCallUsageConsumeOperation, "op">,
): Promise<{ ok: boolean; status: number; body: any }> {
  const result = await walletOp(env, uid, {
    ...args,
    op: "messenger_call_usage_consume",
    uid,
    app_name: "messenger_call",
    ref: `messenger-call:${args.authorization_id}`,
  });
  return { ok: result.status === 200 && result.body?.ok === true, status: result.status, body: result.body };
}

/** Create/extend a paid-only caller reservation before provider connection. */
export async function reserveMessengerCall(
  env: Env,
  uid: string,
  amount: number,
  ref: string,
  opId: string,
  expiresAt: number,
): Promise<{ ok: boolean; status: number; body: any }> {
  const result = await walletOp(env, uid, {
    op: "reserve", uid, amount, ref, op_id: opId, app_name: "messenger_call",
    allow_free: false, expires_at: expiresAt,
  });
  return { ok: result.status === 200 && result.body?.ok === true, status: result.status, body: result.body };
}

export async function releaseMessengerCallReservation(
  env: Env,
  uid: string,
  ref: string,
  opId: string,
): Promise<{ ok: boolean; status: number; body: any }> {
  const result = await walletOp(env, uid, {
    op: "release_reservation", uid, ref, op_id: opId, app_name: "messenger_call",
  });
  return { ok: result.status === 200 && result.body?.ok === true, status: result.status, body: result.body };
}

export async function messengerCallReservationStatus(
  env: Env,
  uid: string,
  reservationRef: string,
): Promise<{ ok: boolean; status: number; body: any }> {
  const result = await walletOp(env, uid, {
    op: "messenger_call_reservation_status", uid, reservation_ref: reservationRef, app_name: "messenger_call",
  });
  return { ok: result.status === 200 && result.body?.ok === true, status: result.status, body: result.body };
}

export async function messengerCallUsageStatus(
  env: Env,
  uid: string,
  args: Omit<MessengerCallUsageStatusOperation, "op">,
): Promise<{ ok: boolean; status: number; body: any }> {
  const result = await walletOp(env, uid, {
    ...args, op: "messenger_call_usage_status", uid, app_name: "messenger_call",
  });
  return { ok: result.status === 200 && result.body?.ok === true, status: result.status, body: result.body };
}

/** Look up an app's commission rate (0..1); 0.20 default. */
export async function commissionRate(env: Env, app: string): Promise<number> {
  const r = await env.DB_WALLET.prepare("SELECT rate FROM commission_rates WHERE app_name=?1").bind(app).first<{ rate: number }>();
  return r?.rate ?? 0.20;
}

/**
 * Atomic coin transfer used by AvaOLX + AvaCalendar: debit buyer, credit seller
 * (minus `commissionOverride` if given, else the app rate) into a 7-day hold.
 * Returns { ok, status, buyerBalance, sellerNet, commission } or an error body.
 */
export async function transferTokens(
  env: Env,
  buyer: string,
  seller: string,
  amount: number,
  app: string,
  ref: string,
  commissionOverride?: number,
): Promise<{ ok: boolean; status: number; body: any; sellerNet: number; commission: number }> {
  const debit = await walletOp(env, buyer, { op: "spend", uid: buyer, amount, app_name: app, counterparty_uid: seller, ref });
  if (debit.status !== 200) return { ok: false, status: debit.status, body: debit.body, sellerNet: 0, commission: 0 };
  const rate = commissionOverride ?? await commissionRate(env, app);
  const commission = Math.round(amount * rate);
  const sellerNet = amount - commission;
  await walletOp(env, seller, { op: "earn", uid: seller, amount: sellerNet, commission, app_name: app, counterparty_uid: buyer, ref });
  return { ok: true, status: 200, body: debit.body, sellerNet, commission };
}

// [AVA-CAMP-B1-WALLET] Thin exports for the outbound-campaign escrow ops (Specs/
// OUTBOUND-AI-CALLING-CAMPAIGNS.md §2/§5), mirroring `transferTokens` above.
// CampaignDO/VobizAgentRoom call these instead of building the walletOp() body
// by hand. The DO exposes "release_reservation" (not "release") to avoid
// colliding with the pre-existing hold-release op of the same name.
export async function walletReserve(
  env: Env, uid: string, amount: number, ref: string, opId: string,
): Promise<{ ok: boolean; status: number; reservedTotal?: number; available?: number; body: any }> {
  // [AI-WALLET-SPENDABLE-2] allow_free:false — campaign escrow is real,
  // withdrawable money; it must only ever admit against PAID balance.
  const r = await walletOp(env, uid, { op: "reserve", uid, amount, ref, allow_free: false, op_id: opId, app_name: "campaign" });
  return { ok: r.status === 200 && r.body?.ok === true, status: r.status, reservedTotal: r.body?.reservedTotal, available: r.body?.available, body: r.body };
}

export async function walletConsumeReserved(
  env: Env, uid: string, ref: string, amount: number, opId: string,
): Promise<{ ok: boolean; status: number; consumed?: number; reservedRemaining?: number; body: any }> {
  // [AI-WALLET-SPENDABLE-2] allow_free:false — must match the policy this ref
  // was reserved with (walletReserve above), or the DO refuses with 409.
  const r = await walletOp(env, uid, { op: "consume_reserved", uid, ref, amount, allow_free: false, op_id: opId, app_name: "campaign" });
  return { ok: r.status === 200 && r.body?.ok === true, status: r.status, consumed: r.body?.consumed, reservedRemaining: r.body?.reservedRemaining, body: r.body };
}

export async function walletReleaseReservation(
  env: Env, uid: string, ref: string, opId: string,
): Promise<{ ok: boolean; status: number; refunded?: number; body: any }> {
  const r = await walletOp(env, uid, { op: "release_reservation", uid, ref, op_id: opId, app_name: "campaign" });
  return { ok: r.status === 200 && r.body?.ok === true, status: r.status, refunded: r.body?.refunded, body: r.body };
}

function topupEnabled(env: Env): boolean {
  // Fail closed: also require the webhook signing secret. Without it, a forged
  // webhook would be the only thing between an attacker and free coins, so
  // top-ups must NOT be enableable until STRIPE_WEBHOOK_SECRET is configured.
  return env.WALLET_TOPUP_ENABLED === "1" && !!env.STRIPE_SECRET_KEY && !!env.STRIPE_WEBHOOK_SECRET;
}

// POST /api/wallet/topup { tokens } (legacy { amountUsdCents } / { amount } also
// accepted - all three have ALWAYS carried the TOKEN COUNT, never a cash amount,
// so the rename is a clarification and old clients keep working unchanged).
//
// [TOKENS-INR-RAIL-1] This is the WEB rail (Stripe Checkout redirect) and it now
// charges INR: `tokens` rupees, billed as `tokens * 100` paise. It used to build
// a USD line item at `usdCentsForTokens(tokens)`, which is where the published
// price and the real charge came apart.
// Money route: requires Idempotency-Key header (A1); rate-limited 5/h (A3).
export async function walletTopup(req: Request, env: Env): Promise<Response> {
  const ctx = await requireUser(req, env);
  if (isFail(ctx)) return json({ error: ctx.error }, ctx.status);
  const limited = await rateLimit(env, `topup:${ctx.uid}`, RL.topup.max, RL.topup.windowSec);
  if (limited) return limited;
  return withIdempotency(req, env, ctx.uid, () => topupCore(req, env, ctx.uid));
}

async function topupCore(req: Request, env: Env, uid: string): Promise<Response> {
  const b = (await req.json().catch(() => ({}))) as any;
  // Every accepted key carries the TOKEN COUNT. `amountUsdCents` is a legacy
  // name from when 1 token was priced at 1 US cent and the two numbers were
  // numerically identical; it is still the token count, not cents.
  const amount = Math.trunc(Number(b.tokens ?? b.amountUsdCents ?? b.amount));
  if (!(amount >= MIN_TOPUP && amount <= MAX_TOPUP)) return json({ error: `amount must be ${MIN_TOPUP}..${MAX_TOPUP} tokens` }, 400);

  if (!topupEnabled(env)) {
    // Infra is built; real money-in is held pending legal (§10.1). Honest 503.
    return json({ error: "top-up unavailable", reason: "pending_legal_approval", flag: "WALLET_TOPUP_ENABLED" }, 503);
  }

  const id = crypto.randomUUID();
  // 1 token = \u20b91, so the charge is `amount` rupees expressed in paise.
  const minor = paiseForTokens(amount);
  // Stripe Checkout Session (server-side; client redirects to session.url).
  const form = new URLSearchParams();
  form.set("mode", "payment");
  form.set("success_url", (env.WALLET_RETURN_URL || "https://avatok.ai/wallet") + "?topup=success");
  form.set("cancel_url", (env.WALLET_RETURN_URL || "https://avatok.ai/wallet") + "?topup=cancel");
  form.set("client_reference_id", id);
  form.set("metadata[uid]", uid);
  form.set("metadata[topup_id]", id);
  form.set("metadata[coins]", String(amount));
  form.set("line_items[0][quantity]", "1");
  form.set("line_items[0][price_data][currency]", TOPUP_CURRENCY);
  form.set("line_items[0][price_data][unit_amount]", String(minor));
  form.set("line_items[0][price_data][product_data][name]", `${amount} Tokens`);

  const res = await fetch("https://api.stripe.com/v1/checkout/sessions", {
    method: "POST",
    headers: { Authorization: `Bearer ${env.STRIPE_SECRET_KEY}`, "Content-Type": "application/x-www-form-urlencoded" },
    body: form.toString(),
  });
  const session = (await res.json()) as any;
  if (!res.ok) return json({ error: "stripe error", detail: session?.error?.message }, 502);

  await env.DB_WALLET.prepare(
    // amount_cents holds MINOR units of `currency` - paise here, not cents.
    "INSERT INTO topup_records (id, uid, stripe_session_id, amount_coins, amount_cents, currency, status, created_at) VALUES (?1,?2,?3,?4,?5,?7,'pending',?6)",
  ).bind(id, uid, session.id, amount, minor, Date.now(), TOPUP_CURRENCY).run();
  track(env, uid, "wallet_topup_initiated", "avawallet", { amount, cents: minor, currency: TOPUP_CURRENCY, via: "checkout" });
  return json({ checkout_url: session.url, session_id: session.id, topup_id: id });
}

// Minimal Stripe REST helper (form-encoded POST / query GET). Never throws.
async function stripeApi(
  env: Env, path: string, form?: URLSearchParams, extraHeaders?: Record<string, string>,
): Promise<{ ok: boolean; status: number; body: any }> {
  const res = await fetch(`https://api.stripe.com/v1/${path}`, {
    method: form ? "POST" : "GET",
    headers: {
      Authorization: `Bearer ${env.STRIPE_SECRET_KEY}`,
      "Content-Type": "application/x-www-form-urlencoded",
      ...(extraHeaders ?? {}),
    },
    body: form ? form.toString() : undefined,
  });
  const body = await res.json().catch(() => ({}));
  return { ok: res.ok, status: res.status, body };
}

// POST /api/wallet/topup/intent { usd_cents } — creates a Stripe PaymentIntent so
// the app can present the NATIVE in-app PaymentSheet (card / Apple Pay / Google
// Pay) with NO browser redirect. Tokens are still credited server-side only, by
// the payment_intent.succeeded webhook — the client never moves money itself.
// Money route: rate-limited 5/h (A3). Client sends the real USD amount in cents;
// the server is the single source of truth for the coin conversion.
export async function walletTopupIntent(req: Request, env: Env): Promise<Response> {
  const ctx = await requireUser(req, env);
  if (isFail(ctx)) return json({ error: ctx.error }, ctx.status);
  const limited = await rateLimit(env, `topup:${ctx.uid}`, RL.topup.max, RL.topup.windowSec);
  if (limited) return limited;

  const b = (await req.json().catch(() => ({}))) as any;
  // [TOKENS-INR-RAIL-1] INR IS THE DEFAULT. The quote-driven client sends
  // { amount_minor, currency }, and the currency it is told to use is now INR
  // for everyone (see walletTopupQuote). 1 Token = \u20b91 FIXED - tokens ARE
  // rupees, never FX-converted - minimum \u20b9100.
  //
  // USD survives for exactly one caller: an app build shipped BEFORE this change
  // that posts the legacy `{ usd_cents }` body with no `currency`. Defaulting
  // those to INR would read 500 US cents as 500 paise and credit 5 tokens
  // instead of 500 - a silent 100x underpay - so the legacy key still pins USD.
  // Anything else, including a bare `{ amount_minor }`, is rupees.
  const legacyUsdBody = b.currency == null && b.usd_cents != null;
  const explicit = String(b.currency ?? "").toLowerCase();
  const currency = explicit === "usd" || (legacyUsdBody && explicit === "") ? "usd" : "inr";
  const cents = Math.trunc(Number(b.amount_minor ?? b.usd_cents ?? b.amountUsdCents)); // minor units of `currency`
  if (!(cents > 0)) return json({ error: "amount_minor required (amount in minor units)" }, 400);
  const coins = currency === "inr"
    ? Math.round(cents / 100)                       // paise → whole rupees → tokens (1 Token = Rs 1, fixed)
    : Math.round((cents * TOKENS_PER_USD) / 100);   // legacy USD cents → tokens (1 token == 1 cent)
  if (!(coins >= MIN_TOPUP && coins <= MAX_TOPUP)) {
    return json({
      error: currency === "inr"
        ? `amount must be ₹${MIN_TOPUP}..₹${MAX_TOPUP}`
        : `amount must be $${MIN_TOPUP / TOKENS_PER_USD}..$${MAX_TOPUP / TOKENS_PER_USD}`,
    }, 400);
  }
  if (!topupEnabled(env)) {
    return json({ error: "top-up unavailable", reason: "pending_legal_approval", flag: "WALLET_TOPUP_ENABLED" }, 503);
  }

  const id = crypto.randomUUID();
  const form = new URLSearchParams();
  form.set("amount", String(cents));
  form.set("currency", currency);
  form.set("automatic_payment_methods[enabled]", "true"); // card + wallets, Stripe-managed
  form.set("description", `${coins} Tokens top-up`);
  form.set("metadata[uid]", ctx.uid);
  form.set("metadata[topup_id]", id);
  form.set("metadata[coins]", String(coins));
  const pi = await stripeApi(env, "payment_intents", form);
  if (!pi.ok) return json({ error: "stripe error", detail: pi.body?.error?.message }, 502);

  // One pending record per attempt — the PaymentIntent id rides in stripe_session_id
  // (unique-indexed) so the webhook can match THIS exact attempt.
  await env.DB_WALLET.prepare(
    // amount_cents = minor units of `currency` (USD cents, or paise for INR).
    "INSERT INTO topup_records (id, uid, stripe_session_id, amount_coins, amount_cents, currency, status, created_at) VALUES (?1,?2,?3,?4,?5,?7,'pending',?6)",
  ).bind(id, ctx.uid, pi.body.id, coins, cents, Date.now(), currency).run();
  track(env, ctx.uid, "wallet_topup_initiated", "avawallet", { coins, cents, currency, via: "payment_sheet" });
  return json({
    payment_intent_client_secret: pi.body.client_secret,
    publishable_key: env.STRIPE_PUBLISHABLE_KEY || "",
    topup_id: id, coins, cents, currency,
  });
}

// ── Google Play top-up ──────────────────────────────────────────────────────
// The client buys a FIXED-PRICE consumable (`avatok_topup_*`) via native Play
// Billing, then POSTs the purchase token here. The server maps productId→Tokens
// from THIS table (never trusts a client amount), verifies the token with the
// Play Developer API, and credits — idempotent on Google's orderId. This is the
// Android money-in rail; Stripe stays the web rail. Keep in lock-step with the
// active `avatok_topup_*` products in the Play Console.
const PLAY_TOPUP_PRODUCTS: Record<string, number> = {
  avatok_topup_5: 500,      // $5   → 500 Tokens
  avatok_topup_10: 1_000,   // $10  → 1,000
  avatok_topup_25: 2_500,   // $25  → 2,500
  avatok_topup_50: 5_000,   // $50  → 5,000
  avatok_topup_100: 10_000, // $100 → 10,000
};

// POST /api/wallet/topup/play/verify { productId, purchaseToken }
// Money route: rate-limited 5/h (A3). Fails CLOSED until the Play service account
// (PLAY_SERVICE_ACCOUNT_JSON) is configured — a forged token can never mint Tokens.
export async function walletTopupPlayVerify(req: Request, env: Env): Promise<Response> {
  const ctx = await requireUser(req, env);
  if (isFail(ctx)) return json({ error: ctx.error }, ctx.status);

  // Killable master switch (KV): independent of subscription billing.
  try {
    if (!(await readConfig(env)).playTopupEnabled) {
      return json({ ok: false, error: "top-up unavailable", reason: "play_topup_disabled" }, 503);
    }
  } catch { /* if config read fails, fall through to the service-account gate below */ }

  const limited = await rateLimit(env, `topup:${ctx.uid}`, RL.topup.max, RL.topup.windowSec);
  if (limited) return limited;

  const b = (await req.json().catch(() => ({}))) as any;
  const productId = String(b.productId ?? "");
  const purchaseToken = String(b.purchaseToken ?? "");
  if (!productId || !purchaseToken) return json({ error: "productId and purchaseToken required" }, 400);

  // Server-side price map is the ONLY source of the credit amount.
  const coins = PLAY_TOPUP_PRODUCTS[productId];
  if (!coins) return json({ error: "unknown product" }, 400);
  if (!(coins >= MIN_TOPUP && coins <= MAX_TOPUP)) return json({ error: "amount out of range" }, 400);

  // Fail CLOSED until the service account is wired (forged token can't mint coins).
  if (!(env as any).PLAY_SERVICE_ACCOUNT_JSON) {
    return json({ ok: false, error: "play verification not configured", reason: "play_unconfigured" }, 503);
  }

  const v = await verifyPlayProduct(env, productId, purchaseToken);
  if (!v.ok) {
    track(env, ctx.uid, "wallet_topup_verify_failed", "avawallet", { source: "play", reason: v.reason });
    return json({ ok: false, error: "play verification failed", reason: v.reason }, 502);
  }
  if (!v.purchased) {
    track(env, ctx.uid, "wallet_topup_verify_rejected", "avawallet", { source: "play", state: v.purchaseState });
    return json({ ok: false, error: "purchase not completed", reason: `state_${v.purchaseState ?? "unknown"}` }, 402);
  }

  // Idempotency key = Google order id (falls back to the token if absent).
  const orderRef = v.orderId || `token:${purchaseToken.slice(0, 40)}`;
  return creditPlayTopup(env, ctx.uid, coins, orderRef, productId, purchaseToken, v);
}

// Credit a verified Play top-up. A topup_records row keyed on the Google orderId
// (stripe_session_id column, unique-indexed) records `pending_credit` before the
// WalletDO call and becomes `paid` only after the wallet confirms. That leaves a
// safe retry path for a transient DO/D1 failure; the WalletDO also dedupes on
// op_id `topup:play:<orderId>` so a replay credits exactly once.
async function creditPlayTopup(
  env: Env, uid: string, coins: number, orderRef: string, productId: string,
  purchaseToken: string, play: { priceAmountMicros?: number; priceCurrencyCode?: string; purchaseTimeMillis?: number },
): Promise<Response> {
  const existing = await env.DB_WALLET.prepare(
    "SELECT id, status FROM topup_records WHERE stripe_session_id=?1 AND uid=?2",
  ).bind(orderRef, uid).first<{ id: string; status: string }>();
  if (existing?.status === "paid") {
    const bal = await walletOp(env, uid, { op: "balance", uid });
    return json({ ok: true, duplicate: true, coins, balance: bal.body?.balance ?? null });
  }

  const id = existing?.id || crypto.randomUUID();
  const priceCurrency = String(play.priceCurrencyCode || "usd").toLowerCase();
  const priceMinor = Number.isFinite(Number(play.priceAmountMicros))
    ? Math.max(0, Math.round(Number(play.priceAmountMicros) / 10_000))
    : usdCentsForTokens(coins);
  try {
    await env.DB_WALLET.prepare(
      `INSERT INTO topup_records
       (id, uid, stripe_session_id, amount_coins, amount_cents, currency, status, paid_at, created_at,
        provider, provider_purchase_token, provider_order_id, provider_price_minor, provider_price_currency, provider_purchase_at)
       VALUES (?1,?2,?3,?4,?5,?6,'pending_credit',?7,?7,'google_play',?8,?3,?9,?10,?11)`,
    ).bind(id, uid, orderRef, coins, priceMinor, priceCurrency, Date.now(), purchaseToken,
      priceMinor, priceCurrency, play.purchaseTimeMillis ?? null).run();
  } catch {
    // A concurrent request may have inserted the same order. Re-read it and
    // continue from pending_credit; only a paid row is a completed duplicate.
    const raced = await env.DB_WALLET.prepare(
      "SELECT id, status FROM topup_records WHERE stripe_session_id=?1 AND uid=?2",
    ).bind(orderRef, uid).first<{ id: string; status: string }>();
    if (!raced) return json({ ok: false, error: "top-up recording failed", reason: "record_failed" }, 503);
    if (raced.status === "paid") {
      const bal = await walletOp(env, uid, { op: "balance", uid });
      return json({ ok: true, duplicate: true, coins, balance: bal.body?.balance ?? null });
    }
  }

  const meta: any = {
    title: `Top-up ${coins} Tokens`, amount_minor: priceMinor, currency: priceCurrency,
    source: "topup", method: "google_play", product: productId,
  };
  const r = await walletOp(env, uid, {
    op: "credit", uid, amount: coins, type: "topup", app_name: "avawallet", ref: orderRef, op_id: `topup:play:${orderRef}`,
    ledger: { debit: "external:google_play", credit: acctUser(uid), type: "topup", ref: orderRef, meta: JSON.stringify(meta) },
  });

  if (r.status !== 200 || r.body?.ok !== true) {
    track(env, uid, "wallet_topup_credit_failed", "avawallet", {
      coins, source: "play", order_ref: orderRef, status: r.status,
    });
    return json({ ok: false, error: "wallet credit pending", reason: "wallet_credit_failed" }, 503);
  }
  const marked = await env.DB_WALLET.prepare(
    "UPDATE topup_records SET status='paid' WHERE id=?1 AND uid=?2 AND status='pending_credit'",
  ).bind(id, uid).run();
  if (!marked.meta.changes) {
    const bal = await walletOp(env, uid, { op: "balance", uid });
    return json({ ok: true, duplicate: true, coins, balance: bal.body?.balance ?? null });
  }

  try { await payAffiliateOnTopup(env, uid, coins, id); } catch { /* best-effort */ }
  try { await sendReceipt(env, uid, "topup", { orderId: id, title: `${coins} Tokens`, lines: [{ label: `${coins} Tokens`, amount: coins }], total: coins }); } catch { /* best-effort */ }
  void brainIngest(env, { uid, domain: "wallet", kind: "wallet_topup", sourceId: `play:${orderRef}`, text: `Topped up ${coins} Tokens`, meta: { coins, source: "play" } });
  try { await notifyUser(env, uid, { type: "wallet", title: `Added ${coins} Tokens`, data: { deeplink: "/wallet", amount: coins } }); } catch { /* best-effort */ }
  track(env, uid, "wallet_topup_completed", "avawallet", { coins, source: "play" });
  return json({ ok: true, credited: coins, coins, balance: r.body?.balance ?? null });
}

/**
 * Reconcile Google Play one-time refunds/voids. Google does not push these to
 * this Worker, so this sweep is the authoritative safety net for affiliate
 * commissions earned from Play top-ups. It is deliberately idempotent: the
 * top-up row is marked voided and the affiliate reversal uses a stable op id.
 */
export async function runPlayVoidedPurchaseSweep(env: Env): Promise<{ scanned: number; matched: number; clawed: number; failed: number }> {
  if (!(env as any).PLAY_SERVICE_ACCOUNT_JSON) return { scanned: 0, matched: 0, clawed: 0, failed: 0 };
  const out = { scanned: 0, matched: 0, clawed: 0, failed: 0 };
  const start = Date.now() - 180 * 86_400_000;
  let page: string | undefined;
  for (let i = 0; i < 5; i++) {
    const batch = await listVoidedPlayPurchases(env, start, page);
    if (!batch.ok) { out.failed++; break; }
    for (const v of batch.purchases) {
      out.scanned++;
      const topup = await env.DB_WALLET.prepare(
        `SELECT id, uid, amount_coins, status FROM topup_records
         WHERE provider_purchase_token=?1 OR provider_order_id=?2 OR stripe_session_id=?2
         ORDER BY created_at ASC LIMIT 1`,
      ).bind(v.purchaseToken, v.orderId || "").first<{ id: string; uid: string; amount_coins: number; status: string }>();
      if (!topup || topup.status === "voided") continue;
      out.matched++;
      try {
        const reason = `google_play_void:${String(v.voidedReason ?? "unknown")}`;
        const clawed = await reverseAffiliate(env, String(topup.id), Number(topup.amount_coins), reason, `play_voided:${v.purchaseToken}`);
        await env.DB_WALLET.prepare(
          `UPDATE topup_records SET status='voided', voided_at=?2, voided_reason=?3
           WHERE id=?1 AND status='paid'`,
        ).bind(String(topup.id), Number(v.voidedTimeMillis || Date.now()), reason).run();
        await env.DB_WALLET.prepare(
          `INSERT INTO play_voided_purchases
           (purchase_token, order_id, product_id, voided_at, voided_reason, topup_id, processed_at)
           VALUES (?1,?2,?3,?4,?5,?6,?7) ON CONFLICT(purchase_token) DO NOTHING`,
        ).bind(v.purchaseToken, v.orderId || null, v.productId || null,
          Number(v.voidedTimeMillis || Date.now()), v.voidedReason == null ? null : String(v.voidedReason),
          String(topup.id), Date.now()).run();
        out.clawed += clawed;
      } catch (e) {
        out.failed++;
        console.error("play voided purchase reconciliation failed:", String(e));
      }
    }
    page = batch.nextPageToken;
    if (!page) break;
  }
  return out;
}

// POST /webhooks/stripe — credit coins when Stripe confirms a payment. Handles
// BOTH the legacy hosted Checkout (checkout.session.completed) and the in-app
// PaymentSheet (payment_intent.succeeded). Either way the credit funnels through
// `creditTopup`, which is idempotent on the topup record + a deterministic op_id.
export async function stripeWebhook(req: Request, env: Env): Promise<Response> {
  const payload = await req.text();
  const sig = req.headers.get("stripe-signature");
  // Fail closed: a missing signing secret means we cannot trust this webhook, so
  // refuse it rather than fall through (closes any unsigned "free coins" path).
  if (!env.STRIPE_WEBHOOK_SECRET) return json({ error: "webhook not configured" }, 503);
  const ok = await verifyStripeSig(payload, sig, env.STRIPE_WEBHOOK_SECRET);
  if (!ok) return json({ error: "bad signature" }, 400);
  let event: any; try { event = JSON.parse(payload); } catch { return json({ error: "bad json" }, 400); }

  // Phase 1 subscriptions share this signed endpoint. Let the subscribe handler
  // claim subscription-mode checkouts + customer.subscription.* events first; it
  // returns null for everything else (e.g. one-time top-ups) so we fall through.
  const subHandled = await subscribeWebhookEvent(env, event);
  if (subHandled) return subHandled;

  if (event.type === "checkout.session.completed") {
    const s = event.data?.object ?? {};
    const ref = (typeof s.payment_intent === "string" && s.payment_intent) || s.id;
    return creditTopup(env, {
      uid: s.metadata?.uid, coins: Math.trunc(Number(s.metadata?.coins || 0)), topupId: s.metadata?.topup_id,
      ref, session: s.id, method: null, brand: null, last4: null,
    });
  }

  if (event.type === "payment_intent.succeeded") {
    const pi = event.data?.object ?? {};
    // The webhook PaymentIntent isn't expanded, so fetch it once to read the
    // payment method (card brand/last4 or wallet) for the receipt + log detail.
    let method: string | null = null, brand: string | null = null, last4: string | null = null;
    try {
      const full = await stripeApi(env, `payment_intents/${pi.id}?expand[]=latest_charge`);
      const pmd = full.body?.latest_charge?.payment_method_details;
      method = pmd?.type ?? null;
      const cardLike = pmd?.card ?? pmd?.[method ?? ""]?.card ?? null;
      if (cardLike) { brand = cardLike.brand ?? null; last4 = cardLike.last4 ?? null; }
    } catch { /* best-effort: method stays null, credit still proceeds */ }
    return creditTopup(env, {
      uid: pi.metadata?.uid, coins: Math.trunc(Number(pi.metadata?.coins || 0)), topupId: pi.metadata?.topup_id,
      ref: pi.id, session: null, method, brand, last4,
    });
  }

  return json({ received: true });
}

// Shared credit path for both Stripe webhook events. Idempotent: only credits a
// pending top-up THIS user initiated, matching the recorded amount; the WalletDO
// dedupes on op_id and emits the double-entry ledger row to Q_WALLET.
async function creditTopup(
  env: Env,
  p: { uid?: string; coins: number; topupId?: string; ref: string; session: string | null; method: string | null; brand: string | null; last4: string | null },
): Promise<Response> {
  const { uid, coins, topupId, ref } = p;
  if (!uid || !(coins > 0) || !topupId) return json({ received: true });

  const rec = await env.DB_WALLET.prepare("SELECT status, amount_coins, amount_cents, currency FROM topup_records WHERE id=?1 AND uid=?2")
    .bind(topupId, uid).first<{ status: string; amount_coins: number; amount_cents: number | null; currency: string | null }>();
  if (!rec) return json({ received: true, ignored: "no matching topup record" });
  if (rec.status !== "pending") return json({ received: true, duplicate: true });
  if (rec.amount_coins !== coins) return json({ received: true, ignored: "amount mismatch" });

  // Ledger meta drives the in-app receipt + log-detail sheet: the real amount
  // charged, and HOW it was paid (card brand/last4, Apple/Google Pay, ...) so a
  // user can see "Rs 500 paid with Visa ...4242 -> 500 Tokens".
  //
  // [TOKENS-INR-RAIL-1] `cents` is MINOR UNITS OF `currency`, read from the
  // top-up record rather than recomputed as USD. It used to be
  // usdCentsForTokens(coins), which printed a dollar figure on an INR charge.
  // The key keeps its legacy name because shipped clients read it.
  const meta: any = {
    title: `Top-up ${coins} Tokens`,
    cents: Number(rec.amount_cents ?? paiseForTokens(coins)),
    currency: String(rec.currency || TOPUP_CURRENCY).toLowerCase(),
    source: "topup",
  };
  meta.method = p.method ?? "card";
  if (p.brand) meta.card_brand = p.brand;
  if (p.last4) meta.card_last4 = p.last4;
  if (p.session) meta.session = p.session;

  await walletOp(env, uid, {
    op: "credit", uid, amount: coins, type: "topup", app_name: "avawallet", ref, op_id: `topup:${topupId}`,
    ledger: { debit: "external:stripe", credit: acctUser(uid), type: "topup", ref, meta: JSON.stringify(meta) },
  });
  await env.DB_WALLET.prepare("UPDATE topup_records SET status='paid', paid_at=?2 WHERE id=?1").bind(topupId, Date.now()).run();
  // Lifetime affiliate commission: 10% of this top-up to whoever referred the user
  // (idempotent per top-up; no-op if there's no affiliate). Never blocks the credit.
  try { await payAffiliateOnTopup(env, uid, coins, topupId); } catch { /* best-effort */ }
  // A4: top-up receipt (best-effort, never blocks the credit).
  try { await sendReceipt(env, uid, "topup", { orderId: topupId, title: `${coins} Tokens`, lines: [{ label: `${coins} Tokens`, amount: coins }], total: coins }); } catch { /* best-effort */ }
  void brainIngest(env, { uid, domain: "wallet", kind: "wallet_topup", sourceId: `stripe:${topupId}`, text: `Topped up ${coins} Tokens`, meta: { coins } });
  try { await notifyUser(env, uid, { type: "wallet", title: `Added ${coins} Tokens`, data: { deeplink: "/wallet", amount: coins } }); } catch { /* best-effort */ }
  track(env, uid, "wallet_topup_completed", "avawallet", { coins });
  return json({ received: true, credited: coins });
}

// POST /api/wallet/spend — DISABLED 2026-06-18 (financial hardening).
//
// This endpoint accepted a CLIENT-SUPPLIED `amount` (and an arbitrary `to_uid`),
// which a re-coded client could use to UNDERPAY for goods/features. No client
// flow uses it: every real purchase already goes through a dedicated,
// SERVER-PRICED endpoint where the amount is derived from server records, never
// from the request body —
//   • AvaOLX            → listing.price_coins   (routes/olx.ts)
//   • AvaBooking/Calendar → slot.price_coins    (routes/calendar.ts)
//   • AvaVision/AvaVoice → server-metered gross  (routes/avavision.ts, avavoice.ts)
//   • AvaTranslate       → server constant       (routes/translate.ts)
// The server, never the client, decides the amount. Do NOT reintroduce a
// client-amount spend route.
export async function walletSpend(_req: Request, _env: Env): Promise<Response> {
  return json({ error: "endpoint removed", reason: "purchases are priced server-side via their own endpoints" }, 410);
}

export async function walletBalance(req: Request, env: Env): Promise<Response> {
  const ctx = await requireUser(req, env);
  if (isFail(ctx)) return json({ error: ctx.error }, ctx.status);
  const r = await walletOp(env, ctx.uid, { op: "balance", uid: ctx.uid });
  // BETA PHASE: report every user as premium so the whole client renders the
  // premium experience (sidebar "BETA PHASE" pill, no PAID badges, no upsell).
  // Read-only patch — does NOT mutate stored wallet state. Real coin balance is
  // untouched; flip betaFreePremium off in KV to restore the free/premium split.
  try {
    if (r.status === 200 && r.body && (await readConfig(env)).betaFreePremium) {
      r.body.premium = 1;
      r.body.beta = true;
    }
  } catch { /* serve the raw snapshot if config lookup fails */ }
  // Phase 1 subscriptions: echo the user's billing tier (0=Free..3=Max) so the
  // whole client renders the right plan pill/badges. premium = tier >= 1 (or the
  // beta flag above). Best-effort: a tier read failure never blocks the balance.
  try {
    if (r.status === 200 && r.body) {
      const sub = await getSub(env, ctx.uid);
      r.body.tier = sub.tier;
      r.body.tier_status = sub.status;
      r.body.tier_renews_at = sub.renewsAt;
      if (sub.tier >= 1) r.body.premium = 1;
    }
  } catch { /* tier optional — serve the snapshot without it */ }
  return json(r.body, r.status);
}

export async function walletTransactions(req: Request, env: Env): Promise<Response> {
  const ctx = await requireUser(req, env);
  if (isFail(ctx)) return json({ error: ctx.error }, ctx.status);
  const rs = await env.DB_WALLET.withSession("first-unconstrained").prepare(
    "SELECT id, type, amount, balance_after, app_name, counterparty_uid, commission, ref, created_at FROM wallet_transactions WHERE uid=?1 ORDER BY created_at DESC LIMIT 100",
  ).bind(ctx.uid).all();
  return json({ transactions: rs.results ?? [] });
}

export async function walletEarnings(req: Request, env: Env): Promise<Response> {
  const ctx = await requireUser(req, env);
  if (isFail(ctx)) return json({ error: ctx.error }, ctx.status);
  const now = Date.now();
  const held = await env.DB_WALLET.prepare(
    "SELECT COALESCE(SUM(amount),0) AS held FROM earning_holds WHERE uid=?1 AND released=0 AND available_at>?2",
  ).bind(ctx.uid, now).first<{ held: number }>();
  const matured = await env.DB_WALLET.prepare(
    "SELECT COALESCE(SUM(amount),0) AS matured FROM earning_holds WHERE uid=?1 AND released=1",
  ).bind(ctx.uid).first<{ matured: number }>();
  const upcoming = await env.DB_WALLET.prepare(
    "SELECT amount, available_at FROM earning_holds WHERE uid=?1 AND released=0 ORDER BY available_at ASC LIMIT 20",
  ).bind(ctx.uid).all();
  return json({ held: held?.held ?? 0, released_total: matured?.matured ?? 0, upcoming: upcoming.results ?? [] });
}

// GET /api/wallet/live — WebSocket balance stream (auth via query: the DO needs the uid).
export async function walletLive(req: Request, env: Env): Promise<Response> {
  const ctx = await requireUser(req, env);
  if (isFail(ctx)) return json({ error: ctx.error }, ctx.status);
  return walletStub(env, ctx.uid).fetch("https://wallet/ws", req);
}

// ---------------------------------------------------------------------------
// Double-entry ledger read APIs (Phase 2). A user's statement = rows where
// their account is debit (out) or credit (in). Keyset pagination on
// (created_at, id); server-side filters: type, from, to, q (ref/meta search).
// ---------------------------------------------------------------------------

function decodeCursor(c: string | null): { t: number; id: string } | null {
  if (!c) return null;
  try {
    const [t, ...rest] = atob(c).split(":");
    return { t: Number(t), id: rest.join(":") };
  } catch { return null; }
}
const encodeCursor = (t: number, id: string) => btoa(`${t}:${id}`);

/** Shape a ledger row for the requesting account: signed amount + parsed meta. */
function shapeRow(r: any, acct: string) {
  let meta: any = null; try { meta = r.meta ? JSON.parse(r.meta) : null; } catch { /* raw */ }
  const out = r.debit === acct;
  return {
    id: r.id, type: r.type, ref: r.ref, created_at: r.created_at,
    debit: r.debit, credit: r.credit,
    amount: out ? -Number(r.amount) : Number(r.amount), // signed for this account
    title: meta?.title ?? null, meta,
  };
}

// GET /api/wallet/ledger?cursor=&limit=50&type=&from=&to=&q=
export async function walletLedger(req: Request, env: Env): Promise<Response> {
  const ctx = await requireUser(req, env);
  if (isFail(ctx)) return json({ error: ctx.error }, ctx.status);
  const acct = acctUser(ctx.uid);
  const u = new URL(req.url);
  const limit = Math.min(100, Math.max(1, Number(u.searchParams.get("limit") || 50)));
  const cur = decodeCursor(u.searchParams.get("cursor"));
  const types = (u.searchParams.get("type") || "").split(",").map((s) => s.trim()).filter(Boolean);
  const from = Number(u.searchParams.get("from") || 0);
  const to = Number(u.searchParams.get("to") || 0);
  const q = (u.searchParams.get("q") || "").trim();

  const where: string[] = ["(debit=?1 OR credit=?1)"];
  const binds: unknown[] = [acct];
  let i = 2;
  if (cur) { where.push(`(created_at < ?${i} OR (created_at = ?${i} AND id < ?${i + 1}))`); binds.push(cur.t, cur.id); i += 2; }
  if (types.length) { where.push(`type IN (${types.map(() => `?${i++}`).join(",")})`); binds.push(...types); }
  if (from > 0) { where.push(`created_at >= ?${i++}`); binds.push(from); }
  if (to > 0) { where.push(`created_at <= ?${i++}`); binds.push(to); }
  if (q) { where.push(`(ref LIKE ?${i} OR meta LIKE ?${i})`); binds.push(`%${q}%`); i++; }

  const rs = await env.DB_WALLET.withSession("first-unconstrained").prepare(
    `SELECT id, debit, credit, amount, type, ref, meta, created_at FROM wallet_ledger
     WHERE ${where.join(" AND ")} ORDER BY created_at DESC, id DESC LIMIT ${limit + 1}`,
  ).bind(...binds).all();
  const rows = (rs.results ?? []) as any[];
  const page = rows.slice(0, limit);
  const last = page[page.length - 1];
  track(env, ctx.uid, q || types.length || from || to ? "wallet_filter_used" : "wallet_ledger_viewed", "avawallet", { n: page.length });
  return json({
    entries: page.map((r) => shapeRow(r, acct)),
    cursor: rows.length > limit && last ? encodeCursor(Number(last.created_at), String(last.id)) : null,
  });
}

// GET /api/wallet/ledger/:id — full detail (fee breakdown, counterpart, refs).
export async function walletLedgerDetail(req: Request, env: Env, id: string): Promise<Response> {
  const ctx = await requireUser(req, env);
  if (isFail(ctx)) return json({ error: ctx.error }, ctx.status);
  const acct = acctUser(ctx.uid);
  const r = await env.DB_WALLET.prepare(
    "SELECT id, debit, credit, amount, type, ref, meta, created_at FROM wallet_ledger WHERE id=?1 AND (debit=?2 OR credit=?2)",
  ).bind(id, acct).first<any>();
  // [WALLET-TXMETA-1] Free/bonus-token spends never produce a wallet_ledger row,
  // so the detail sheet used to be empty for most receptionist charges. Resolve
  // the id against wallet_transactions instead (same { entry, related } shape,
  // entry.meta carries duration_sec / rate_per_min / context).
  const tx = await txDetailFor(env, ctx.uid, id);
  if (!r) return tx ? json(tx) : json({ error: "not found" }, 404);
  // Sibling rows on the same ref complete the picture (e.g. the fee row of a release).
  const siblings = r.ref
    ? ((await env.DB_WALLET.prepare("SELECT id, debit, credit, amount, type, created_at FROM wallet_ledger WHERE ref=?1 AND id<>?2 LIMIT 10").bind(r.ref, id).all()).results ?? [])
    : [];
  // [WALLET-TXMETA-1] Merge: the ledger row's own meta wins on collision, the
  // transaction row fills in the fields it alone knows (duration/rate/context).
  const entry = shapeRow(r, acct);
  if (tx) entry.meta = { ...(tx.entry.meta as Record<string, unknown>), ...(entry.meta ?? {}) };
  return json({ entry, related: siblings });
}

// POST /api/wallet/ledger/:id/receipt — "Email me this receipt" (A4 re-send).
//
// [WALLET-RECEIPT-1] The ids the app taps come from the STATEMENT feed, i.e.
// wallet_transactions — but this endpoint only ever looked in wallet_ledger,
// which shares ids with wallet_transactions ONLY for double-entry (escrow/
// marketplace) messages. Ordinary spends (calls, AI, voicemail) have no
// wallet_ledger row, so "Get receipt" 404'd on exactly the rows users see.
// Look up wallet_transactions first (scoped to the caller's uid) and keep the
// wallet_ledger lookup as the legacy fallback for old double-entry-only ids.
export async function walletReceiptResend(req: Request, env: Env, id: string): Promise<Response> {
  const ctx = await requireUser(req, env);
  if (isFail(ctx)) return json({ error: ctx.error }, ctx.status);

  const tx = await env.DB_WALLET.prepare(
    `SELECT id, type, amount, app_name, ref, created_at, context, duration_sec, rate_per_min
     FROM wallet_transactions WHERE id=?1 AND uid=?2`,
  ).bind(id, ctx.uid).first<any>();
  if (tx) {
    const amount = Number(tx.amount ?? 0);
    const label = labelFor(String(tx.type || ""), tx.app_name ? String(tx.app_name) : null, amount);
    const title = String(tx.context || "").trim() || label;
    const lines = [{ label: title, amount: Math.abs(amount) }];
    // Metered charges (calls): show the duration × rate math on the receipt.
    if (tx.duration_sec && tx.rate_per_min) {
      const m = Math.floor(Number(tx.duration_sec) / 60);
      const s = String(Math.round(Number(tx.duration_sec) % 60)).padStart(2, "0");
      lines.push({ label: `Metered: ${m}:${s} at ${Number(tx.rate_per_min)} tokens/min`, amount: 0 });
    }
    const ok = await sendReceipt(env, ctx.uid, tx.type === "topup" ? "topup" : "purchase", {
      orderId: String(tx.ref || tx.id), title, lines, total: Math.abs(amount), date: Number(tx.created_at),
    });
    return json(ok ? { sent: true } : { sent: false, error: "no email on file or email disabled" }, ok ? 200 : 502);
  }

  // Legacy fallback: double-entry-only ids (escrow/marketplace rows).
  const acct = acctUser(ctx.uid);
  const r = await env.DB_WALLET.prepare(
    "SELECT id, debit, credit, amount, type, ref, meta, created_at FROM wallet_ledger WHERE id=?1 AND (debit=?2 OR credit=?2)",
  ).bind(id, acct).first<any>();
  if (!r) return json({ error: "not found" }, 404);
  let meta: any = {}; try { meta = r.meta ? JSON.parse(r.meta) : {}; } catch { /* ignore */ }
  const title = meta?.title || r.type;
  const lines = [{ label: title, amount: Number(meta?.gross ?? r.amount) }];
  if (meta?.fee) lines.push({ label: "Platform fee (creator-side)", amount: -Number(meta.fee) });
  const ok = await sendReceipt(env, ctx.uid, r.type === "topup" ? "topup" : "purchase", {
    orderId: r.ref || r.id, title, lines, total: Number(r.amount), date: Number(r.created_at),
  });
  return json(ok ? { sent: true } : { sent: false, error: "no email on file or email disabled" }, ok ? 200 : 502);
}

// Stripe webhook signature (HMAC-SHA256 over `${t}.${payload}`).
export async function verifyStripeSig(payload: string, header: string | null, secret: string): Promise<boolean> {
  if (!header) return false;
  const parts = Object.fromEntries(header.split(",").map((kv) => kv.split("=")));
  const t = parts["t"]; const v1 = parts["v1"];
  if (!t || !v1) return false;
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const mac = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(`${t}.${payload}`));
  const hex = [...new Uint8Array(mac)].map((b) => b.toString(16).padStart(2, "0")).join("");
  // constant-time-ish compare
  if (hex.length !== v1.length) return false;
  let diff = 0; for (let i = 0; i < hex.length; i++) diff |= hex.charCodeAt(i) ^ v1.charCodeAt(i);
  return diff === 0;
}
