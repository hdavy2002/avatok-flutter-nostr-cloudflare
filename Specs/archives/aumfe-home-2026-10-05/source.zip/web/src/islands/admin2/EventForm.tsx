/* EventForm — [ADMIN2-EVENTS 2026-09-26] /admin/events/new and /admin/events/[id].
 * Contract: Specs/SPEC-2026-09-26-ADMIN-2.md ("Events"). API: worker/src/routes/admin2_events.ts.
 *
 *  - One form for create and edit. Edit sends ONLY the fields that changed (the server
 *    diffs again and logs what actually changed against the admin's id).
 *  - "What's missing before publish" is the server's listing_blockers result for the
 *    saved event — the same list publish enforces — never a browser copy of the rules.
 *  - Publish = save, then approve + publish in one server action (no review loop).
 *  - Cancel refunds every open booking first (server rule); the dialog says so.
 *  - The YouTube link uses the existing admin route (PUT /api/admin/listings/:id/youtube).
 *  - Telemetry: admin2_event_saved {action}; failures -> captureException.
 *
 *  [SAATHUM-EVENT-FIELDS-1 2026-09-26] OWNER DECISIONS:
 *  - "Start from an article" (top of the form): pick any Puja & Havan Guide article
 *    and the form fills title, deity, intention, descriptions, duration, price and the
 *    article photo as cover. Fields the article does not know stay as they are.
 *    Logic: ./articlePrefill.ts. Telemetry: admin2_event_article_prefill.
 *  - "On the booking card": intention pill, temple location, prasad courier and
 *    7-day replay — the Book now card (islands/home/BookNowShelf.tsx) reads them.
 *  - "Google & WhatsApp": SEO title/description are written automatically by the
 *    worker on every save (attrs.seo, admin2_events.ts refreshSeo). Typing here
 *    overrides; clearing goes back to automatic. The WhatsApp share line
 *    (attrs.ad_hook) is AI-written on publish by lib/listing_ad_hook.ts.
 */
import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import {
  ArrowLeft, Ban, BookOpen, CalendarDays, CircleAlert, CircleCheck, Clock, Copy, ExternalLink, ImagePlus, IndianRupee,
  Loader2, MapPin, MessageCircle, MonitorPlay, Save, Search, Send, Sparkles, Star, Ticket, Trash2, Undo2, Upload, User, Users,
} from 'lucide-react';
import { capture, captureException } from '../../lib/analytics';
import { cn } from '../../lib/utils';
import { EVENT_TYPES, EVENT_TYPE_COPY, COLLECTIVE_SANKALPS, type EventType } from '../../lib/eventTypes';
import { whatsappShareText } from '../../lib/shareText';
import { Button } from '../../components/ui/button';
import { Badge } from '../../components/ui/badge';
import { Input } from '../../components/ui/input';
import { Label } from '../../components/ui/label';
import { Calendar } from '../../components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '../../components/ui/popover';
import { Select, SelectContent, SelectGroup, SelectItem, SelectLabel, SelectTrigger, SelectValue } from '../../components/ui/select';
import { Switch } from '../../components/ui/switch';
import { toCrop, cropAspect, type VideoCrop } from '../../components/dash2/crop';
import VideoCropEditor from './VideoCropEditor';
import { ToggleGroup, ToggleGroupItem } from '../../components/ui/toggle-group';
import { articleBySlug, articleCover, articleGroups, fillFromArticle } from './articlePrefill';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '../../components/ui/alert-dialog';
import { toast } from '../../components/ui/sonner';
import { fmtDuration, fmtIstDateTime, listingImage, youtubeThumb, ErrorState, Shimmer } from '../../components/dash2/shared';
import { ApiError, adminApi, errMessage, formatPaise } from './adminApi';
import {
  DELETE_EVENT_BODY, DURATION_PRESETS, TIME_SLOTS, dateOfYmd, deleteEvent, eventsPath, istTodayYmd, looksLikeYoutube, saveYoutube, statusMeta,
  templeLabel, templesPath, timeLabel, uploadCover, ymdOf, youtubeIdOf, type Blocker, type EventDetailResponse, type EventsMeta, type TempleRow,
} from './eventsApi';
import { BRAND } from '../../lib/brand';
import DeleteDialog from './DeleteDialog';

/* ── form model ─────────────────────────────────────────────────────────── */

interface FormState {
  title: string;
  category: string;
  deity: string;
  blurb: string;
  description: string;
  cover_url: string;
  start_date: string;
  start_time: string;
  duration_min: string;
  price_rupees: string;
  capacity: string;
  performed_by: string;
  youtube_url: string;
  /** [SAATHUM-FREEVID-ADMIN-1] Crop box as "x,y,w,h" (fractions of the 16:9 frame); '' = whole video. A string so the form's plain compare sees changes. */
  youtube_crop: string;
  /** [SAATHUM-FREEVID-ADMIN-1] Free event: anyone signed in can watch; no price. */
  free_watch: boolean;
  // [SAATHUM-EVENT-FIELDS-1]
  location: string;
  intention: string;
  /** [SAATHUM-SHARED-SANKALP-1 2026-09-30] Collective sankalp keys, comma-joined (keeps
   *  the form's plain string compare for "changed"). Ritual types only. */
  collective_sankalp: string;
  prasad_courier: boolean;
  guide_slug: string;
  seo_title: string;
  seo_description: string;
  // [SAATHUM-CHADHAVA 2026-09-26]
  video_download: boolean;
  visibility: 'public' | 'private';
  prasad_price_rupees: string;
  booked_boost: string;
  video_download_url: string;
  // [SAATHUM-EVENT-TYPES 2026-09-27]
  event_type: EventType;
  performer_photo_url: string;
  rating_display: string;
  review_count_boost: string;
  // [SAATHUM-TEMPLE-FIELD-1 2026-09-29] id of a saved temple, '' = none.
  temple_id: string;
}

/** Admin-form-only placeholder examples for the performer name box — not in eventTypes.ts
 *  because that file's copy is customer-facing; this is a hint for the owner while typing. */
const PERFORMER_PLACEHOLDER: Record<EventType, string> = {
  havan: 'Pandit Ramesh Sharma, Haridwar',
  puja: 'Pandit Ramesh Sharma, Haridwar',
  satsang: 'Swami Ramananda',
  sermon: 'Swami Ramananda',
  meditation: 'Dr. Meera Iyer',
};

/** [SAATHUM-SHARED-SANKALP-1] Fallback if the worker meta is older than this form. Mirrors
 *  COLLECTIVE_SANKALPS in lib/eventTypes.ts and worker/src/lib/event_types.ts. */
const COLLECTIVE_FALLBACK = Object.entries(COLLECTIVE_SANKALPS).map(([id, label]) => ({ id, label }));

/** Fallback intention list if the worker meta is older than this form. Mirrors ritualGuides ritualCategories. */
const INTENTIONS_FALLBACK = [
  { id: 'luck', label: 'Good luck' }, { id: 'wealth', label: 'Wealth' }, { id: 'health', label: 'Health' },
  { id: 'education', label: 'Education' }, { id: 'career', label: 'Career' }, { id: 'family', label: 'Family' },
  { id: 'peace', label: 'Peace' }, { id: 'life', label: 'Life events' }, { id: 'festival', label: 'Festivals' },
];

const EMPTY: FormState = {
  title: '', category: '', deity: '', blurb: '', description: '', cover_url: '', start_date: '', start_time: '06:00',
  duration_min: '60', price_rupees: '', capacity: '', performed_by: BRAND.name, youtube_url: '', youtube_crop: '', free_watch: false,
  location: '', intention: '', collective_sankalp: '', prasad_courier: true, guide_slug: '', seo_title: '', seo_description: '',
  video_download: true, visibility: 'public', prasad_price_rupees: '99', video_download_url: '', booked_boost: '',
  event_type: 'havan', performer_photo_url: '', rating_display: '', review_count_boost: '', temple_id: '',
};

const cropToForm = (c: VideoCrop | null): string => (c ? `${c.x},${c.y},${c.w},${c.h}` : '');
function cropFromForm(s: string): VideoCrop | null {
  const [x, y, w, h] = s.split(',').map(Number);
  return s ? toCrop({ x, y, w, h }) : null;
}

function fromDetail(d: EventDetailResponse): FormState {
  const e = d.event;
  return {
    title: e.title ?? '',
    category: e.category ?? '',
    deity: e.deity ?? '',
    blurb: e.blurb ?? '',
    description: e.description ?? '',
    cover_url: e.manual_cover_url ?? '',
    start_date: e.start_ist?.date ?? '',
    start_time: e.start_ist?.time ?? '',
    duration_min: e.duration_min ? String(e.duration_min) : '',
    price_rupees: e.price_rupees ? String(e.price_rupees) : '',
    capacity: e.capacity ? String(e.capacity) : '',
    performed_by: e.performed_by ?? '',
    youtube_url: d.youtube?.url ?? '',
    youtube_crop: cropToForm(toCrop(d.youtube?.crop)),
    free_watch: e.free_watch ?? false,
    location: e.location ?? '',
    intention: e.intention ?? '',
    collective_sankalp: (e.collective_sankalp ?? []).join(','),
    prasad_courier: e.prasad_courier ?? true,
    guide_slug: e.guide_slug ?? '',
    video_download: e.video_download ?? true,
    visibility: e.visibility === 'private' ? 'private' : 'public',
    prasad_price_rupees: e.prasad_price_rupees != null ? String(e.prasad_price_rupees) : '99',
    booked_boost: e.booked_boost ? String(e.booked_boost) : '',
    video_download_url: e.video_download_url ?? '',
    // Only an admin-typed value lives in the box; the automatic one is the placeholder.
    seo_title: e.seo?.title_source === 'admin' ? e.seo.title : '',
    seo_description: e.seo?.description_source === 'admin' ? e.seo.description : '',
    event_type: e.event_type ?? 'havan',
    performer_photo_url: e.performer_photo_url ?? '',
    rating_display: e.rating_display != null ? String(e.rating_display) : '',
    review_count_boost: e.review_count_boost != null ? String(e.review_count_boost) : '',
    temple_id: e.temple_id ?? '',
  };
}

/** The request body for the worker, from the fields that differ from `base` (all of them on create). */
function bodyOf(f: FormState, base: FormState | null): Record<string, unknown> {
  const changed = (k: keyof FormState) => !base || f[k] !== base[k];
  const out: Record<string, unknown> = {};
  if (changed('title')) out.title = f.title;
  if (changed('category')) out.category = f.category;
  if (changed('deity')) out.deity = f.deity;
  if (changed('blurb')) out.blurb = f.blurb;
  if (changed('description')) out.description = f.description;
  if (changed('cover_url')) out.cover_url = f.cover_url || null;
  if (changed('start_date') || changed('start_time')) {
    if (f.start_date || !base) { out.start_date = f.start_date; out.start_time = f.start_date ? f.start_time : ''; }
    else { out.start_date = ''; out.start_time = ''; }
  }
  if (changed('duration_min')) out.duration_min = f.duration_min === '' ? null : Number(f.duration_min);
  if (changed('price_rupees') && f.price_rupees !== '' && !f.free_watch) out.price_rupees = Number(f.price_rupees);
  if (changed('capacity')) out.capacity = f.capacity === '' ? null : Number(f.capacity);
  if (changed('performed_by')) out.performed_by = f.performed_by;
  for (const k of ['location', 'intention', 'guide_slug', 'seo_title', 'seo_description'] as const) if (changed(k)) out[k] = f[k].trim();
  for (const k of ['prasad_courier', 'video_download', 'visibility', 'free_watch'] as const) if (changed(k)) out[k] = f[k];
  if (changed('prasad_price_rupees')) out.prasad_price_rupees = f.prasad_price_rupees === '' ? null : Number(f.prasad_price_rupees);
  if (changed('video_download_url')) out.video_download_url = f.video_download_url.trim() || null;
  if (changed('booked_boost')) out.booked_boost = f.booked_boost.trim() === '' ? null : Number(f.booked_boost);
  if (changed('event_type')) out.event_type = f.event_type;
  if (changed('performer_photo_url')) out.performer_photo_url = f.performer_photo_url.trim() || null;
  if (changed('rating_display')) out.rating_display = f.rating_display.trim() === '' ? null : Number(f.rating_display);
  if (changed('review_count_boost')) out.review_count_boost = f.review_count_boost.trim() === '' ? null : Number(f.review_count_boost);
  if (changed('temple_id')) out.temple_id = f.temple_id || null;
  if (changed('collective_sankalp')) out.collective_sankalp = f.collective_sankalp ? f.collective_sankalp.split(',') : null;
  if (!base) {
    // Create: omit empties the server treats as "not set yet".
    for (const k of ['deity', 'blurb', 'description', 'performed_by', 'location', 'intention', 'guide_slug', 'seo_title', 'seo_description', 'video_download_url', 'performer_photo_url'] as const) if (!f[k]) delete out[k];
    if (!f.start_date) { delete out.start_date; delete out.start_time; }
    if (f.capacity === '') delete out.capacity;
    if (!f.temple_id) delete out.temple_id;
    if (!f.collective_sankalp) delete out.collective_sankalp;
    if (f.rating_display.trim() === '') delete out.rating_display;
    if (f.review_count_boost.trim() === '') delete out.review_count_boost;
  }
  return out;
}

const FIELD_OF_BLOCKER: Record<string, keyof FormState> = {
  title: 'title', category: 'category', starts_at: 'start_date', duration_min: 'duration_min', price: 'price_rupees',
  performed_by: 'performed_by', description: 'description', blurb: 'blurb', cover_media: 'cover_url', cover_url: 'cover_url',
  capacity: 'capacity', location: 'location', intention: 'intention', guide_slug: 'guide_slug',
  seo_title: 'seo_title', seo_description: 'seo_description', prasad_courier: 'prasad_courier',
  video_download: 'video_download', visibility: 'visibility', prasad_price_rupees: 'prasad_price_rupees', video_download_url: 'video_download_url', booked_boost: 'booked_boost',
  event_type: 'event_type', performer_photo_url: 'performer_photo_url', rating_display: 'rating_display', review_count_boost: 'review_count_boost', temple_id: 'temple_id',
  collective_sankalp: 'collective_sankalp',
};

type Busy = null | 'save' | 'publish' | 'unpublish' | 'cancel' | 'upload' | 'perf_photo' | 'poster' | 'article' | 'video_url';

/* ── component ──────────────────────────────────────────────────────────── */

export default function EventForm({ eventId }: { eventId?: string }) {
  const [id, setId] = useState<string | undefined>(eventId);
  const [meta, setMeta] = useState<EventsMeta | null>(null);
  const [detail, setDetail] = useState<EventDetailResponse | null>(null);
  const [form, setForm] = useState<FormState>(EMPTY);
  const [base, setBase] = useState<FormState | null>(null);
  const [loading, setLoading] = useState(!!eventId);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [busy, setBusy] = useState<Busy>(null);
  const [errors, setErrors] = useState<Partial<Record<keyof FormState, string>>>({});
  const [banner, setBanner] = useState<{ tone: 'error' | 'ok'; text: string; blockers?: Blocker[] } | null>(null);
  const [confirmCancel, setConfirmCancel] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);
  const [dateOpen, setDateOpen] = useState(false);
  const refs = useRef<Partial<Record<keyof FormState, HTMLElement | null>>>({});
  const fileRef = useRef<HTMLInputElement | null>(null);
  const [articleSlug, setArticleSlug] = useState('');
  // [SAATHUM-TEMPLE-FIELD-1] Saved temples + the inline "Add a new temple" mini-form.
  const [temples, setTemples] = useState<TempleRow[]>([]);
  const [addingTemple, setAddingTemple] = useState(false);
  const [newTemple, setNewTemple] = useState({ name: '', place: '' });
  const [templeBusy, setTempleBusy] = useState(false);
  const performerFileRef = useRef<HTMLInputElement | null>(null);
  const groups = useMemo(() => articleGroups(form.event_type), [form.event_type]);
  const typeCopy = EVENT_TYPE_COPY[form.event_type];

  const status = detail?.event.status ?? 'draft';
  const isPublic = status === 'published' || status === 'live';
  const isClosed = status === 'cancelled' || status === 'completed';
  const scheduleLocked = isPublic;

  useEffect(() => {
    adminApi<EventsMeta>(eventsPath(undefined, 'meta')).then(setMeta).catch((e) => {
      captureException(e, { where: 'admin2_event_form_meta' });
    });
  }, []);

  useEffect(() => {
    adminApi<{ temples: TempleRow[] }>(templesPath).then((r) => setTemples(r.temples ?? [])).catch((e) => {
      captureException(e, { where: 'admin2_event_form_temples' });
    });
  }, []);

  async function saveNewTemple() {
    const name = newTemple.name.trim(); const place = newTemple.place.trim();
    if (name.length < 2 || place.length < 2) { setErrors((x) => ({ ...x, temple_id: 'Enter the temple name and the place (at least 2 letters each).' })); return; }
    setTempleBusy(true);
    try {
      const r = await adminApi<{ temple: TempleRow; created: boolean }>(templesPath, { method: 'POST', body: { name, place } });
      setTemples((list) => (list.some((t) => t.id === r.temple.id) ? list : [...list, r.temple].sort((a, b) => a.name.localeCompare(b.name))));
      set('temple_id', r.temple.id);
      setAddingTemple(false); setNewTemple({ name: '', place: '' });
      toast.success(r.created ? 'Temple saved for future events.' : 'That temple was already saved — selected it.');
    } catch (e) {
      captureException(e, { where: 'admin2_event_form_temple_add' });
      setErrors((x) => ({ ...x, temple_id: errMessage(e) }));
    } finally { setTempleBusy(false); }
  }

  const load = useCallback(async (targetId: string) => {
    setLoadError(null);
    try {
      const d = await adminApi<EventDetailResponse>(eventsPath(targetId));
      setDetail(d);
      const f = fromDetail(d);
      setForm(f); setBase(f);
    } catch (e) {
      captureException(e, { where: 'admin2_event_form_load' });
      setLoadError(e instanceof ApiError && e.status === 404 ? 'This event does not exist (or was deleted).' : errMessage(e));
    } finally { setLoading(false); }
  }, []);

  useEffect(() => { if (eventId) void load(eventId); }, [eventId, load]);

  const set = <K extends keyof FormState>(k: K, v: FormState[K]) => {
    setForm((s) => ({ ...s, [k]: v }));
    setErrors((e) => (e[k] ? { ...e, [k]: undefined } : e));
  };

  const dirtyKeys = useMemo(() => (Object.keys(form) as (keyof FormState)[]).filter((k) => !base || form[k] !== base[k]), [form, base]);
  const dirty = !base || dirtyKeys.length > 0;

  function applyDetail(d: EventDetailResponse, keepYoutube?: string) {
    setDetail(d);
    const f = fromDetail(d);
    if (keepYoutube !== undefined) f.youtube_url = keepYoutube;
    setForm(f); setBase(f);
  }

  function focusField(k: keyof FormState) {
    const el = refs.current[k];
    if (el) { el.scrollIntoView({ block: 'center', behavior: 'smooth' }); (el as HTMLInputElement).focus?.(); }
  }

  function showError(e: unknown, action: string) {
    const body = e instanceof ApiError ? (e.body as Record<string, any> | undefined) : undefined;
    const field = body?.field ? FIELD_OF_BLOCKER[String(body.field)] : undefined;
    const msg = errMessage(e);
    if (field) { setErrors((x) => ({ ...x, [field]: msg })); focusField(field); }
    setBanner({ tone: 'error', text: msg, blockers: Array.isArray(body?.blockers) ? body!.blockers : undefined });
    toast.error(msg);
    if (!(e instanceof ApiError) || e.status >= 500) captureException(e, { where: `admin2_event_${action}` });
    capture('admin2_event_saved', { action, ok: false, error: e instanceof ApiError ? e.error : 'network', listing_id: id ?? null });
  }

  /** Client-side sanity for the obvious cases; the server is the authority. */
  function precheck(): boolean {
    const e: Partial<Record<keyof FormState, string>> = {};
    if (form.title.trim().length < 3) e.title = 'Give the event a title.';
    if (!form.category) e.category = 'Pick a category.';
    if (form.youtube_url.trim() && !looksLikeYoutube(form.youtube_url)) e.youtube_url = 'That is not a YouTube link.';
    const min = meta?.min_price_rupees ?? 1;
    if (!form.free_watch && form.price_rupees !== '' && (!Number.isInteger(Number(form.price_rupees)) || Number(form.price_rupees) < min)) e.price_rupees = `Price must be a whole number, at least ₹${min}.`;
    setErrors(e);
    const first = Object.keys(e)[0] as keyof FormState | undefined;
    if (first) { focusField(first); return false; }
    return true;
  }

  /** Save (create or edit) + YouTube link. Returns the event id, or null on failure. */
  async function save(action: 'create' | 'update' | 'publish'): Promise<string | null> {
    if (!precheck()) return null;
    let currentId = id;
    const ytChanged = (base?.youtube_url ?? '') !== form.youtube_url.trim();
    // [SAATHUM-FREEVID-ADMIN-1] Read the crop before applyDetail() below resets the form from the server copy.
    const cropNow = form.youtube_url.trim() ? cropFromForm(form.youtube_crop) : null;
    const cropChanged = (base?.youtube_crop ?? '') !== cropToForm(cropNow);
    try {
      if (!currentId) {
        const r = await adminApi<EventDetailResponse & { id: string }>(eventsPath(), { method: 'POST', body: bodyOf(form, null) });
        currentId = r.id;
        setId(r.id);
        window.history.replaceState(null, '', `/admin/events/${encodeURIComponent(r.id)}`);
        applyDetail(r, form.youtube_url);
        capture('admin2_event_saved', { action: 'create', ok: true, listing_id: r.id });
      } else if (dirtyKeys.some((k) => k !== 'youtube_url' && k !== 'youtube_crop')) {
        const r = await adminApi<EventDetailResponse>(eventsPath(currentId), { method: 'PUT', body: bodyOf(form, base) });
        applyDetail(r, form.youtube_url);
        if (action !== 'publish') capture('admin2_event_saved', { action: 'update', ok: true, listing_id: currentId, fields: dirtyKeys.join(',') });
      }
      if ((ytChanged || cropChanged) && currentId) {
        await saveYoutube(currentId, form.youtube_url.trim(), cropNow);
        setBase((b) => (b ? { ...b, youtube_url: form.youtube_url.trim(), youtube_crop: cropToForm(cropNow) } : b));
        capture('admin2_event_saved', { action: 'youtube', ok: true, listing_id: currentId, cleared: !form.youtube_url.trim() });
        if (cropChanged) capture('admin2_video_crop_saved', { listing_id: currentId, cleared: cropNow === null, aspect: Math.round(cropAspect(cropNow) * 100) / 100 });
        const d = await adminApi<EventDetailResponse>(eventsPath(currentId));
        applyDetail(d);
      }
      return currentId ?? null;
    } catch (e) {
      showError(e, action);
      return null;
    }
  }

  async function onSave() {
    setBusy('save'); setBanner(null);
    const ok = await save(id ? 'update' : 'create');
    if (ok) { setBanner({ tone: 'ok', text: 'Saved.' }); toast.success('Saved'); }
    setBusy(null);
  }

  async function onPublish() {
    setBusy('publish'); setBanner(null);
    const saved = dirty || !id ? await save('publish') : id;
    if (!saved) { setBusy(null); return; }
    try {
      const r = await adminApi<EventDetailResponse>(eventsPath(saved, 'publish'), { method: 'POST' });
      applyDetail(r);
      setBanner({ tone: 'ok', text: 'Published. Customers can book it now.' });
      toast.success('Published', { description: 'Customers can book it now.' });
      capture('admin2_event_saved', { action: 'publish', ok: true, listing_id: saved });
    } catch (e) {
      showError(e, 'publish');
      void load(saved);
    } finally { setBusy(null); }
  }

  async function onUnpublish() {
    if (!id) return;
    setBusy('unpublish'); setBanner(null);
    try {
      const r = await adminApi<EventDetailResponse>(eventsPath(id, 'unpublish'), { method: 'POST' });
      applyDetail(r);
      setBanner({ tone: 'ok', text: 'Unpublished. It is back in Drafts.' });
      toast.success('Unpublished');
      capture('admin2_event_saved', { action: 'unpublish', ok: true, listing_id: id });
    } catch (e) { showError(e, 'unpublish'); } finally { setBusy(null); }
  }

  async function onDelete() {
    if (!id) return;
    setDeleting(true); setDeleteError(null);
    try {
      await deleteEvent(id);
      capture('admin2_event_deleted', { id });
      toast.success('Event deleted');
      window.location.assign('/admin/events');
    } catch (e) {
      // 409 has_money_history / 503 are shown in the dialog with the server's own words.
      if (!(e instanceof ApiError) || e.status >= 500) captureException(e, { where: 'admin2_event_delete' });
      setDeleteError(errMessage(e));
      setDeleting(false);
    }
  }

  async function onCancel() {
    if (!id) return;
    setBusy('cancel'); setBanner(null);
    try {
      const r = await adminApi<{ ok: boolean; refunds: { scanned: number; refunded: number; review_pending: number; no_refund: number } }>(
        eventsPath(id, 'cancel'), { method: 'POST', body: { confirm: true } },
      );
      const rf = r.refunds;
      const text = rf.scanned
        ? `Cancelled. ${rf.refunded} refunded${rf.review_pending ? `, ${rf.review_pending} waiting for a manual refund (see Refunds)` : ''}${rf.no_refund ? `, ${rf.no_refund} with no refund due` : ''}.`
        : 'Cancelled. Nobody had booked.';
      setBanner({ tone: 'ok', text });
      toast.success('Event cancelled');
      capture('admin2_event_saved', { action: 'cancel', ok: true, listing_id: id, refunded: rf.refunded, review_pending: rf.review_pending });
      await load(id);
    } catch (e) { showError(e, 'cancel'); } finally { setBusy(null); setConfirmCancel(false); }
  }

  async function onUpload(files: FileList | null) {
    const file = files?.[0];
    if (!file) return;
    setBusy('upload');
    try {
      const url = await uploadCover(file);
      set('cover_url', url);
      toast.success('Image uploaded', { description: 'Save to keep it.' });
      capture('admin2_event_cover_upload', { ok: true });
    } catch (e) {
      const msg = e instanceof Error && !(e instanceof ApiError) ? e.message : errMessage(e);
      setErrors((x) => ({ ...x, cover_url: msg }));
      captureException(e, { where: 'admin2_event_cover_upload' });
      capture('admin2_event_cover_upload', { ok: false });
    } finally {
      setBusy(null);
      if (fileRef.current) fileRef.current.value = '';
    }
  }

  /** [SAATHUM-EVENT-TYPES 2026-09-27] Optional round photo next to the performer's name. */
  async function onUploadPerformerPhoto(files: FileList | null) {
    const file = files?.[0];
    if (!file) return;
    setBusy('perf_photo');
    try {
      const url = await uploadCover(file);
      set('performer_photo_url', url);
      toast.success('Photo uploaded', { description: 'Save to keep it.' });
      capture('admin2_event_performer_photo_upload', { ok: true });
    } catch (e) {
      const msg = e instanceof Error && !(e instanceof ApiError) ? e.message : errMessage(e);
      setErrors((x) => ({ ...x, performer_photo_url: msg }));
      captureException(e, { where: 'admin2_event_performer_photo_upload' });
      capture('admin2_event_performer_photo_upload', { ok: false });
    } finally {
      setBusy(null);
      if (performerFileRef.current) performerFileRef.current.value = '';
    }
  }

  async function onPoster(action: 'generate' | 'keep') {
    let target = id;
    if (!target || dirty) { target = (await save('update')) ?? undefined; if (!target) return; }
    setBusy('poster'); setBanner(null);
    try {
      const r = await adminApi<EventDetailResponse>(eventsPath(target, 'poster'), { method: 'POST', body: { action }, timeoutMs: 120_000 });
      applyDetail(r);
      toast.success(action === 'generate' ? 'AI poster ready — keep it or upload your own.' : 'AI poster kept.');
      capture('admin2_event_saved', { action: action === 'generate' ? 'poster_generate' : 'poster_keep', ok: true, listing_id: target });
    } catch (e) { showError(e, action === 'generate' ? 'poster_generate' : 'poster_keep'); } finally { setBusy(null); }
  }

  /** [SAATHUM-CHADHAVA 2026-09-26] The video download link is the one field a completed
   * event can still take (writeMediaAndAttrs allows only this key once an event is
   * closed) — its own save so it works even though the main Save bar is hidden then. */
  async function onSaveVideoUrl() {
    if (!id) return;
    setBusy('video_url'); setBanner(null);
    try {
      const r = await adminApi<EventDetailResponse>(eventsPath(id), { method: 'PUT', body: { video_download_url: form.video_download_url.trim() || null } });
      applyDetail(r, form.youtube_url);
      toast.success('Saved');
      capture('admin2_event_saved', { action: 'video_download_url', ok: true, listing_id: id });
    } catch (e) { showError(e, 'video_download_url'); } finally { setBusy(null); }
  }

  /** [SAATHUM-EVENT-FIELDS-1] Fill the form from a Puja & Havan Guide article. Undo restores the form. */
  async function onPickArticle(slug: string) {
    const a = articleBySlug(slug);
    if (!a) return;
    setArticleSlug(slug);
    const before = form;
    setBusy('article'); setBanner(null);
    const t0 = performance.now();
    try {
      const fill = await fillFromArticle(a, { categories: meta?.categories ?? [], minPrice: meta?.min_price_rupees ?? 1 });
      setForm((s) => ({ ...s, ...fill }));
      setErrors({});
      let coverOk = false;
      try {
        const url = await articleCover(a);
        setForm((s) => ({ ...s, cover_url: url }));
        coverOk = true;
      } catch (e) {
        captureException(e, { where: 'admin2_event_article_cover', slug });
        toast.error('Could not copy the article photo', { description: 'Upload an image yourself.' });
      }
      toast.success(`Filled from “${a.title}”`, {
        description: 'Check the text, then add the location, date, time and YouTube link.',
        action: { label: 'Undo', onClick: () => { setForm(before); setArticleSlug(''); } },
      });
      capture('admin2_event_article_prefill', {
        ok: true, slug, listing_id: id ?? null, cover: coverOk, price: !!fill.price_rupees, category: !!fill.category,
        ms: Math.round(performance.now() - t0),
      });
    } catch (e) {
      captureException(e, { where: 'admin2_event_article_prefill', slug });
      capture('admin2_event_article_prefill', { ok: false, slug, listing_id: id ?? null });
      toast.error('Could not read that article.');
    } finally { setBusy(null); }
  }

  function shareUrl(): string {
    return `${window.location.origin}/book/${encodeURIComponent(id ?? '')}`;
  }

  function onWhatsApp() {
    if (!id) return;
    // [WEB-WA-SHARE-2] Readable pitch in the message body — see lib/shareText.ts.
    const text = whatsappShareText({
      title: form.title, url: shareUrl(), hook: detail?.event.ad_hook || null,
      startsAt: detail?.event.starts_at ?? null, place: form.location || null,
      price: form.price_rupees ? Number(form.price_rupees) : null,
      ritual: EVENT_TYPE_COPY[form.event_type]?.ritual ?? true,
      personalSankalp: (EVENT_TYPE_COPY[form.event_type]?.ritual ?? true) && form.visibility === 'private',
    });
    window.open('https://wa.me/?text=' + encodeURIComponent(text), '_blank', 'noopener');
    capture('admin2_event_share', { channel: 'whatsapp', listing_id: id });
  }

  async function copyLink() {
    if (!id) return;
    const url = `${window.location.origin}/book/${encodeURIComponent(id)}`;
    try { await navigator.clipboard.writeText(url); toast.success('Link copied', { description: url }); }
    catch { toast.error('Could not copy the link.'); }
  }

  /* ── render ── */

  if (loading) {
    return (
      <div className="grid gap-4 lg:grid-cols-[1fr_320px]" aria-busy="true">
        <div className="flex flex-col gap-4">{[0, 1, 2].map((i) => <Shimmer key={i} className="h-40 w-full rounded-xl" />)}</div>
        <Shimmer className="h-64 w-full rounded-xl" />
      </div>
    );
  }
  if (loadError) return <ErrorState message={loadError} onRetry={() => { setLoading(true); void load(eventId!); }} />;

  const ev = detail?.event;
  const st = statusMeta(status, ev?.tab);
  const coverPreview = form.cover_url || ev?.ai_poster_url || '';
  const usingAi = !form.cover_url && !!ev?.ai_poster_url;
  const blockers = detail?.blockers ?? [];
  const posterPlan = detail?.poster_plan;
  const minPrice = meta?.min_price_rupees ?? 1;
  const disabled = isClosed || busy !== null;
  const ytId = detail?.youtube?.video_id;
  const formYtId = youtubeIdOf(form.youtube_url);

  // [SAATHUM-EVENT-TYPES 2026-09-27] Live preview for the "Social proof" section. The admin
  // API doesn't expose a real rating/review count yet, so this previews the admin-set numbers
  // only — the public site's own render (lib/eventTypes.ts socialProof()) adds the real ones.
  const previewRating = Number(form.rating_display);
  const hasPreviewRating = form.rating_display.trim() !== '' && previewRating >= 1 && previewRating <= 5;
  const previewReviews = Number(form.review_count_boost) || 0;
  const previewBooked = (ev?.seats_booked ?? 0) + (Number(form.booked_boost) || 0);
  const socialProofPreview = [
    hasPreviewRating ? `⭐ ${previewRating.toFixed(1)}/5` : null,
    previewReviews > 0 ? `${previewReviews.toLocaleString('en-IN')} reviews` : null,
    `${previewBooked.toLocaleString('en-IN')} booked`,
  ].filter(Boolean).join(' · ');

  return (
    <div className="flex flex-col gap-5 pb-28 lg:pb-0">
      {/* Header strip */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <a href="/admin/events" className="inline-flex items-center gap-1.5 text-[14px] font-bold text-muted-foreground no-underline hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> All events
        </a>
        {id && (
          <div className="flex flex-wrap items-center gap-1.5">
            <Badge variant={st.variant}>{st.label}</Badge>
            <Button variant="ghost" size="sm" onClick={() => void copyLink()}><Copy /> Copy link</Button>
            <Button variant="ghost" size="sm" onClick={onWhatsApp}><MessageCircle /> WhatsApp</Button>
            <Button asChild variant="ghost" size="sm"><a href={`/book/${encodeURIComponent(id)}`} target="_blank" rel="noopener"><ExternalLink /> View on site</a></Button>
            <Button asChild variant="ghost" size="sm"><a href={`/admin/bookings?event=${encodeURIComponent(id)}`}><Ticket /> Bookings{ev ? ` (${ev.seats_booked})` : ''}</a></Button>
          </div>
        )}
      </div>

      {banner && (
        <div role={banner.tone === 'error' ? 'alert' : 'status'}
          className={cn('rounded-xl border px-4 py-3 text-[14px] font-semibold',
            banner.tone === 'error' ? 'border-destructive/40 bg-destructive/10 text-destructive' : 'border-accent/40 bg-accent/10 text-foreground')}>
          <p className="flex items-start gap-2">{banner.tone === 'error' ? <CircleAlert className="mt-0.5 h-4 w-4 shrink-0" /> : <CircleCheck className="mt-0.5 h-4 w-4 shrink-0" />}{banner.text}</p>
          {banner.blockers && banner.blockers.length > 1 && (
            <ul className="mt-2 list-disc pl-10 text-[13px]">{banner.blockers.map((b) => <li key={b.code}>{b.message}</li>)}</ul>
          )}
        </div>
      )}

      {isClosed && (
        <p className="rounded-xl border border-border bg-muted px-4 py-3 text-[14px] font-semibold text-muted-foreground">
          This event is {status === 'cancelled' ? 'cancelled' : 'over'}. It can't be edited.
        </p>
      )}

      <div className="grid items-start gap-5 lg:grid-cols-[minmax(0,1fr)_340px]">
        {/* ── Main column ── */}
        <div className="flex flex-col gap-5">
          {/* [SAATHUM-EVENT-TYPES 2026-09-27] First thing in the form — everything below adapts to it. */}
          <Section title="What kind of event?" subtitle="Everything below — labels, checkout, the booking card — adapts to this.">
            <ToggleGroup type="single" variant="outline" value={form.event_type} disabled={disabled}
              className="grid grid-cols-2 gap-2 sm:grid-cols-5"
              onValueChange={(v) => {
                if (!v || v === form.event_type) return;
                const t = v as EventType;
                set('event_type', t);
                setArticleSlug('');
                capture('admin2_event_type_selected', { event_type: t });
              }}>
              {EVENT_TYPES.map((t) => (
                <ToggleGroupItem key={t} value={t} aria-label={EVENT_TYPE_COPY[t].label} className="h-auto flex-col gap-1 py-3">
                  <span className="text-[14px] font-bold">{EVENT_TYPE_COPY[t].label}</span>
                </ToggleGroupItem>
              ))}
            </ToggleGroup>
            <p className="text-[12px] font-semibold text-muted-foreground">
              {typeCopy.ritual
                ? 'Ritual event — collective sankalp, chadhava and prasad courier are offered.'
                : 'Not a ritual — no sankalp, chadhava or prasad; customers just book a seat.'}
            </p>
          </Section>

          {(!isClosed && (typeCopy.ritual || articleBySlug(form.guide_slug))) && (
            <Section title="Start from an article"
              subtitle={typeCopy.ritual
                ? 'Pick a Puja & Havan Guide article to fill the form. You add the location, date, time and YouTube link.'
                : `No ${typeCopy.noun} articles yet — this only applies to havans and pujas.`}>
              {typeCopy.ritual ? (
                <Field label="Article" hint={`${groups[0].items.length + groups[1].items.length} articles`}>
                  <Select value={articleSlug || undefined} onValueChange={(v) => void onPickArticle(v)} disabled={disabled}>
                    <SelectTrigger aria-label="Start from an article">
                      {busy === 'article' ? <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" /> : <Search className="h-4 w-4 text-muted-foreground" />}
                      <SelectValue placeholder="Choose an article…" />
                    </SelectTrigger>
                    <SelectContent className="max-h-80">
                      {groups.map((g) => (
                        <SelectGroup key={g.label}>
                          <SelectLabel>{g.label}</SelectLabel>
                          {g.items.map((a) => <SelectItem key={a.slug} value={a.slug}>{a.title} · {a.deity}</SelectItem>)}
                        </SelectGroup>
                      ))}
                    </SelectContent>
                  </Select>
                </Field>
              ) : (
                // Article was linked before switching to a non-ritual type; show it collapsed (read-only) rather than hide the link entirely.
                <p className="text-[13px] font-semibold text-muted-foreground">Linked article: {articleBySlug(form.guide_slug)?.title}</p>
              )}
            </Section>
          )}

          <Section title="The event" subtitle="What customers see on the booking page.">
            <Field label="Title" htmlFor="ev-title" error={errors.title} hint={`${form.title.length}/${meta?.limits.titleMax ?? 120}`}>
              <Input id="ev-title" ref={(el) => { refs.current.title = el; }} value={form.title} maxLength={meta?.limits.titleMax ?? 120}
                disabled={disabled} onChange={(e) => set('title', e.target.value)} placeholder="Maha Mrityunjaya Havan" aria-invalid={!!errors.title} />
            </Field>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Category" error={errors.category}>
                <Select value={form.category || undefined} onValueChange={(v) => set('category', v)} disabled={disabled}>
                  <SelectTrigger ref={(el) => { refs.current.category = el; }} aria-invalid={!!errors.category} aria-label="Category">
                    <SelectValue placeholder="Pick a category" />
                  </SelectTrigger>
                  <SelectContent>
                    {(meta?.categories ?? []).map((c) => <SelectItem key={c.id} value={c.id}>{c.label}</SelectItem>)}
                    {form.category && meta && !meta.categories.some((c) => c.id === form.category) && (
                      <SelectItem value={form.category}>{ev?.category_label ?? form.category} (inactive)</SelectItem>
                    )}
                  </SelectContent>
                </Select>
              </Field>
              <Field label="Deity" htmlFor="ev-deity" error={errors.deity} hint="Optional">
                <Input id="ev-deity" list="ev-deity-list" value={form.deity} maxLength={meta?.limits.deityMax ?? 60} disabled={disabled}
                  onChange={(e) => set('deity', e.target.value)} placeholder="Shiva" />
                <datalist id="ev-deity-list">{(meta?.deity_suggestions ?? []).map((d) => <option key={d} value={d} />)}</datalist>
              </Field>
            </div>
            <Field label="Short description" htmlFor="ev-blurb" error={errors.blurb} hint={`${form.blurb.length}/${meta?.limits.blurbMax ?? 120}`}>
              <Input id="ev-blurb" ref={(el) => { refs.current.blurb = el; }} value={form.blurb} maxLength={meta?.limits.blurbMax ?? 120} disabled={disabled}
                onChange={(e) => set('blurb', e.target.value)} placeholder="One line for the card" />
            </Field>
            <Field label="Long description" htmlFor="ev-desc" error={errors.description} hint="What happens, what the devotee receives, how to prepare.">
              <textarea id="ev-desc" ref={(el) => { refs.current.description = el; }} rows={6} value={form.description}
                maxLength={meta?.limits.descriptionMax ?? 6000} disabled={disabled} onChange={(e) => set('description', e.target.value)}
                className="flex min-h-[140px] w-full rounded-md border border-input bg-card px-3 py-2 text-base text-foreground shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm" />
            </Field>
            <Field label={typeCopy.performerField} htmlFor="ev-perf" error={errors.performed_by} hint="Required before publishing — who customers are booking.">
              <div className="flex items-start gap-3">
                <div className="relative h-16 w-16 shrink-0 overflow-hidden rounded-full border border-border/70 bg-muted">
                  {form.performer_photo_url ? (
                    <img src={listingImage(form.performer_photo_url, 128) ?? form.performer_photo_url} alt="" className="h-full w-full object-cover" />
                  ) : (
                    <span className="flex h-full w-full items-center justify-center text-muted-foreground"><User className="h-6 w-6" /></span>
                  )}
                  {busy === 'perf_photo' && <span className="absolute inset-0 flex items-center justify-center bg-card/70"><Loader2 className="h-4 w-4 animate-spin text-primary" /></span>}
                </div>
                <div className="flex flex-1 flex-col gap-2">
                  <Input id="ev-perf" ref={(el) => { refs.current.performed_by = el; }} value={form.performed_by} maxLength={meta?.limits.performedByMax ?? 80}
                    disabled={disabled} onChange={(e) => set('performed_by', e.target.value)} placeholder={PERFORMER_PLACEHOLDER[form.event_type]} />
                  <div className="flex items-center gap-2">
                    <input ref={performerFileRef} type="file" accept="image/jpeg,image/png,image/webp" className="sr-only" id="ev-perf-photo-file"
                      onChange={(e) => void onUploadPerformerPhoto(e.target.files)} disabled={disabled} />
                    <Button type="button" variant="outline" size="sm" disabled={disabled} onClick={() => performerFileRef.current?.click()}>
                      <Upload className="h-3.5 w-3.5" /> {form.performer_photo_url ? 'Replace photo' : 'Add photo'}
                    </Button>
                    {form.performer_photo_url && (
                      <Button type="button" variant="ghost" size="sm" disabled={disabled} onClick={() => set('performer_photo_url', '')}><Trash2 className="h-3.5 w-3.5" /> Remove</Button>
                    )}
                  </div>
                  {errors.performer_photo_url && <p className="text-[13px] font-semibold text-destructive">{errors.performer_photo_url}</p>}
                </div>
              </div>
            </Field>
            <Field label="Temple" error={errors.temple_id} hint="Shown to customers as “Performed at …”. Optional.">
              <Select value={addingTemple ? '__new' : (form.temple_id || '__none')} disabled={disabled}
                onValueChange={(v) => {
                  if (v === '__new') { setAddingTemple(true); return; }
                  setAddingTemple(false); set('temple_id', v === '__none' ? '' : v);
                }}>
                <SelectTrigger ref={(el) => { refs.current.temple_id = el; }} aria-label="Temple"><SelectValue placeholder="Choose a temple" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="__none">No temple</SelectItem>
                  {temples.map((t) => <SelectItem key={t.id} value={t.id}>{templeLabel(t)}</SelectItem>)}
                  {form.temple_id && !temples.some((t) => t.id === form.temple_id) && (
                    <SelectItem value={form.temple_id}>{ev?.temple ? templeLabel(ev.temple) : 'Saved temple'}</SelectItem>
                  )}
                  <SelectItem value="__new">+ Add a new temple</SelectItem>
                </SelectContent>
              </Select>
              {addingTemple && (
                <div className="mt-3 grid gap-3 sm:grid-cols-2">
                  <div className="flex flex-col gap-1.5">
                    <Label htmlFor="ev-temple-name" className="font-bold">Temple name</Label>
                    <Input id="ev-temple-name" value={newTemple.name} maxLength={80} disabled={disabled || templeBusy}
                      onChange={(e) => setNewTemple((n) => ({ ...n, name: e.target.value }))} placeholder="Kunjapuri Devi Temple" />
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <Label htmlFor="ev-temple-place" className="font-bold">Place</Label>
                    <Input id="ev-temple-place" value={newTemple.place} maxLength={80} disabled={disabled || templeBusy}
                      onChange={(e) => setNewTemple((n) => ({ ...n, place: e.target.value }))} placeholder="Rishikesh" />
                  </div>
                  <div className="flex items-center gap-2 sm:col-span-2">
                    <Button type="button" size="sm" disabled={disabled || templeBusy} onClick={() => void saveNewTemple()}>
                      {templeBusy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />} Save temple
                    </Button>
                    <Button type="button" variant="ghost" size="sm" disabled={templeBusy} onClick={() => { setAddingTemple(false); setNewTemple({ name: '', place: '' }); }}>Cancel</Button>
                  </div>
                </div>
              )}
            </Field>
          </Section>

          <Section title="On the booking card" subtitle="The badges and ticks customers see on the Book now card.">
            {typeCopy.ritual && (
              <Field label="Sankalp for this event" error={errors.collective_sankalp}
                hint="Recited by the pujari for every devotee. Customers no longer give a gotra or wish for a public event — just a name. Pick up to 5.">
                <ToggleGroup type="multiple" variant="outline" className="flex-wrap justify-start" disabled={disabled}
                  value={form.collective_sankalp ? form.collective_sankalp.split(',') : []}
                  onValueChange={(v: string[]) => {
                    if (v.length > 5) return;
                    set('collective_sankalp', v.join(','));
                    capture('admin2_event_collective_sankalp', { count: v.length, keys: v.join(',') });
                  }}>
                  {(meta?.collective_sankalps ?? COLLECTIVE_FALLBACK).map((c) => (
                    <ToggleGroupItem key={c.id} value={c.id} aria-label={c.label}>{c.label}</ToggleGroupItem>
                  ))}
                </ToggleGroup>
              </Field>
            )}
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Intention" error={errors.intention} hint="The badge on the photo">
                <Select value={form.intention || undefined} onValueChange={(v) => set('intention', v === '__none' ? '' : v)} disabled={disabled}>
                  <SelectTrigger ref={(el) => { refs.current.intention = el; }} aria-label="Intention"><SelectValue placeholder="Good luck, Wealth, Health…" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="__none">None</SelectItem>
                    {(meta?.intentions ?? INTENTIONS_FALLBACK).map((c) => <SelectItem key={c.id} value={c.id}>{c.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </Field>
              <Field label="Location" htmlFor="ev-loc" error={errors.location} hint="Temple city, e.g. Haridwar">
                <div className="relative">
                  <MapPin className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input id="ev-loc" ref={(el) => { refs.current.location = el; }} className="pl-9" value={form.location} maxLength={meta?.limits.locationMax ?? 60}
                    disabled={disabled} onChange={(e) => set('location', e.target.value)} placeholder="Haridwar" />
                </div>
              </Field>
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              {typeCopy.ritual && (
                <ToggleRow id="ev-prasad" label="Prasad courier" hint="Prasad is couriered to the devotee" checked={form.prasad_courier}
                  disabled={disabled} onChange={(v) => set('prasad_courier', v)} />
              )}
              <ToggleRow id="ev-video-download" label="Video download" hint="Paid devotees can download the video anytime" checked={form.video_download}
                disabled={disabled} onChange={(v) => set('video_download', v)} />
            </div>
            {typeCopy.ritual && form.prasad_courier && (
              <Field label="Prasad shipping price (₹)" htmlFor="ev-prasad-price" error={errors.prasad_price_rupees} hint="Anywhere in India">
                <div className="relative max-w-[10rem]">
                  <IndianRupee className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input id="ev-prasad-price" type="number" inputMode="numeric" min={0} max={5000} step={1} className="pl-9"
                    value={form.prasad_price_rupees} disabled={disabled} onChange={(e) => set('prasad_price_rupees', e.target.value)} placeholder="99" />
                </div>
              </Field>
            )}
            <Field label="Who can book" error={errors.visibility}>
              <ToggleGroup type="single" variant="outline" value={form.visibility} disabled={disabled}
                onValueChange={(v) => { if (v === 'public' || v === 'private') { set('visibility', v); if (v === 'private') set('capacity', '1'); } }}>
                <ToggleGroupItem value="public" aria-label="Public">Public</ToggleGroupItem>
                <ToggleGroupItem value="private" aria-label="Private">Private</ToggleGroupItem>
              </ToggleGroup>
              <p className="text-[12px] font-semibold text-muted-foreground">
                {form.visibility === 'private'
                  ? 'Private: a 1:1 session for one family (1 seat).'
                  : 'Public: many devotees join together.'}
              </p>
            </Field>
            <p className="text-[12px] font-semibold text-muted-foreground">
              {typeCopy.ritual ? (form.visibility === 'private' ? '“Sankalp in your name” and “Live on YouTube” always show.' : '“Collective sankalp” and “Live on YouTube” always show.') : '“Live on YouTube” always shows.'} Rating and “booked” fill in from real bookings.
            </p>
            <Field label="Read benefits links to">
              {articleBySlug(form.guide_slug) ? (
                <div className="flex flex-wrap items-center gap-2 text-[14px] font-semibold">
                  <BookOpen className="h-4 w-4 text-accent" />
                  <a href={articleBySlug(form.guide_slug)!.href} target="_blank" rel="noopener" className="text-foreground underline-offset-2 hover:underline">{articleBySlug(form.guide_slug)!.title}</a>
                  <Button type="button" variant="ghost" size="sm" disabled={disabled} onClick={() => set('guide_slug', '')}>Remove</Button>
                </div>
              ) : (
                <p className="text-[13px] font-semibold text-muted-foreground">No article linked — the site matches one by title. Pick an article above to link it.</p>
              )}
            </Field>
          </Section>

          {/* [SAATHUM-EVENT-TYPES 2026-09-27] Owner decision: admin-set social-proof numbers,
              editable even on a published event; each is added on top of the real count. */}
          <Section title="Social proof (shown to customers)" subtitle="Optional. Each number is added on top of the real count — leave empty to show only what's real.">
            <div className="grid gap-4 sm:grid-cols-3">
              <Field label="Star rating" htmlFor="ev-rating" error={errors.rating_display} hint="1.0–5.0. Empty = real rating only.">
                <div className="relative">
                  <Star className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input id="ev-rating" type="number" inputMode="decimal" min={1} max={5} step={0.1} className="pl-9"
                    value={form.rating_display} disabled={disabled} onChange={(e) => set('rating_display', e.target.value)} placeholder="4.9" />
                </div>
              </Field>
              <Field label="Review count" htmlFor="ev-review-count" error={errors.review_count_boost} hint="Added to real reviews.">
                <div className="relative">
                  <Users className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input id="ev-review-count" type="number" inputMode="numeric" min={0} max={1000000} step={1} className="pl-9"
                    value={form.review_count_boost} disabled={disabled} onChange={(e) => set('review_count_boost', e.target.value)} placeholder="e.g. 128" />
                </div>
              </Field>
              <Field label="Extra “booked” count" htmlFor="ev-boost" error={errors.booked_boost}
                hint={`Added to real bookings${ev ? ` (${ev.seats_booked} real)` : ''}.`}>
                <div className="relative">
                  <Users className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input id="ev-boost" type="number" inputMode="numeric" min={0} max={1000000} step={1} className="pl-9"
                    value={form.booked_boost} disabled={disabled} onChange={(e) => set('booked_boost', e.target.value)} placeholder="e.g. 1200" />
                </div>
              </Field>
            </div>
            <p className="text-[13px] font-semibold text-muted-foreground">Card shows: {socialProofPreview}</p>
          </Section>

          <Section title="Cover image" subtitle="Upload a photo, or generate the AI poster and keep it.">
            <div ref={(el) => { refs.current.cover_url = el; }} className="flex flex-col gap-4 sm:flex-row">
              <div className="relative aspect-[4/5] w-full overflow-hidden rounded-lg border border-border/70 bg-muted sm:w-48">
                {coverPreview ? <img src={listingImage(coverPreview, 480) ?? coverPreview} alt="Cover preview" className="h-full w-full object-cover" />
                  : <span className="flex h-full w-full flex-col items-center justify-center gap-2 text-[13px] font-bold text-muted-foreground"><ImagePlus className="h-7 w-7" />No image yet</span>}
                {usingAi && <Badge variant="secondary" className="absolute left-2 top-2"><Sparkles className="h-3 w-3" /> AI poster{ev?.poster?.status === 'approved' ? '' : ' · not kept'}</Badge>}
                {(busy === 'upload' || busy === 'poster') && (
                  <span className="absolute inset-0 flex items-center justify-center bg-card/70"><Loader2 className="h-6 w-6 animate-spin text-primary" /></span>
                )}
              </div>
              <div className="flex flex-1 flex-col gap-2">
                <input ref={fileRef} type="file" accept="image/jpeg,image/png,image/webp" className="sr-only" id="ev-cover-file"
                  onChange={(e) => void onUpload(e.target.files)} disabled={disabled} />
                <Button type="button" variant="outline" disabled={disabled} onClick={() => fileRef.current?.click()}>
                  <Upload /> {form.cover_url ? 'Replace image' : 'Upload image'}
                </Button>
                {form.cover_url && (
                  <Button type="button" variant="ghost" disabled={disabled} onClick={() => set('cover_url', '')}><Trash2 /> Remove uploaded image</Button>
                )}
                {!form.cover_url && (
                  <>
                    <Button type="button" variant="outline" disabled={disabled || !form.title.trim() || !form.category} onClick={() => void onPoster('generate')}>
                      <Sparkles /> {ev?.ai_poster_url ? 'Generate a new AI poster' : 'Generate AI poster'}
                    </Button>
                    {ev?.poster?.status === 'draft' && (
                      <Button type="button" disabled={disabled} onClick={() => void onPoster('keep')}><CircleCheck /> Keep this poster</Button>
                    )}
                  </>
                )}
                <p className="text-[12px] font-semibold text-muted-foreground">JPG, PNG or WebP, up to 8 MB. Portrait works best. The AI poster takes up to a minute.</p>
                {ev?.poster?.status === 'failed' && <p className="text-[13px] font-semibold text-destructive">The AI poster failed{ev.poster.error ? `: ${ev.poster.error}` : ''}. Try again or upload an image.</p>}
                {errors.cover_url && <p className="text-[13px] font-semibold text-destructive">{errors.cover_url}</p>}
              </div>
            </div>
          </Section>

          <Section title="When" subtitle="Indian Standard Time.">
            {scheduleLocked && (
              <p className="rounded-md bg-muted px-3 py-2 text-[13px] font-semibold text-muted-foreground">
                A published event's date and time can't change — people booked for that time. Cancel it and create a new one instead.
              </p>
            )}
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Date" error={errors.start_date}>
                <Popover open={dateOpen} onOpenChange={setDateOpen}>
                  <PopoverTrigger asChild>
                    <Button ref={(el) => { refs.current.start_date = el; }} type="button" variant="outline" disabled={disabled || scheduleLocked}
                      className={cn('w-full justify-start font-semibold', !form.start_date && 'text-muted-foreground')} aria-invalid={!!errors.start_date}>
                      <CalendarDays /> {form.start_date ? fmtYmd(form.start_date) : 'Pick a date'}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar mode="single" selected={dateOfYmd(form.start_date)} defaultMonth={dateOfYmd(form.start_date)}
                      disabled={{ before: dateOfYmd(istTodayYmd())! }}
                      onSelect={(d) => { if (d) { set('start_date', ymdOf(d)); setDateOpen(false); } }} initialFocus />
                  </PopoverContent>
                </Popover>
              </Field>
              <Field label="Start time (IST)" error={errors.start_time}>
                <Select value={form.start_time || undefined} onValueChange={(v) => set('start_time', v)} disabled={disabled || scheduleLocked}>
                  <SelectTrigger aria-label="Start time"><Clock className="h-4 w-4 text-muted-foreground" /><SelectValue placeholder="Pick a time" /></SelectTrigger>
                  <SelectContent className="max-h-72">
                    {form.start_time && !TIME_SLOTS.includes(form.start_time) && <SelectItem value={form.start_time}>{timeLabel(form.start_time)}</SelectItem>}
                    {TIME_SLOTS.map((t) => <SelectItem key={t} value={t}>{timeLabel(t)}</SelectItem>)}
                  </SelectContent>
                </Select>
              </Field>
            </div>
            <Field label="Duration" error={errors.duration_min} hint={form.duration_min ? fmtDuration(Number(form.duration_min)) : `${meta?.duration.min ?? 5}–${meta?.duration.max ?? 480} minutes`}>
              <div className="flex flex-wrap items-center gap-2">
                {DURATION_PRESETS.map((m) => (
                  <Button key={m} type="button" size="sm" variant={form.duration_min === String(m) ? 'default' : 'outline'} disabled={disabled || scheduleLocked}
                    onClick={() => set('duration_min', String(m))}>{fmtDuration(m)}</Button>
                ))}
                <Input ref={(el) => { refs.current.duration_min = el; }} type="number" inputMode="numeric" min={5} max={480} className="w-28"
                  value={form.duration_min} disabled={disabled || scheduleLocked} onChange={(e) => set('duration_min', e.target.value)} aria-label="Duration in minutes" />
              </div>
            </Field>
          </Section>

          <Section title="Price and seats">
            {/* [SAATHUM-FREEVID-ADMIN-1] Free event: no price, no booking; signed-in (email) viewers watch. */}
            <ToggleRow id="ev-free" label="Free event — anyone signed in can watch"
              hint="No payment or booking. Viewers only sign in with their email — no WhatsApp check."
              checked={form.free_watch} disabled={disabled}
              onChange={(v) => { set('free_watch', v); capture('admin2_event_free_toggled', { free: v, listing_id: id ?? null }); }} />
            <div className="grid gap-4 sm:grid-cols-2">
              {form.free_watch ? (
                <div className="flex flex-col gap-1.5">
                  <Label className="font-bold">Price</Label>
                  <p className="flex h-10 items-center rounded-md border border-dashed border-border bg-muted px-3 text-[15px] font-bold text-foreground">Free — no price</p>
                </div>
              ) : (
              <Field label="Price (₹)" htmlFor="ev-price" error={errors.price_rupees} hint={`Per booking. At least ₹${minPrice}.`}>
                <div className="relative">
                  <IndianRupee className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input id="ev-price" ref={(el) => { refs.current.price_rupees = el; }} type="number" inputMode="numeric" min={minPrice} step={1} className="pl-9"
                    value={form.price_rupees} disabled={disabled} onChange={(e) => set('price_rupees', e.target.value)} placeholder="501" aria-invalid={!!errors.price_rupees} />
                </div>
              </Field>
              )}
              <Field label="Capacity" htmlFor="ev-cap" error={errors.capacity} hint={form.visibility === 'private' ? 'Private events are locked to 1 seat.' : 'Optional. Empty = no limit.'}>
                <div className="relative">
                  <Users className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input id="ev-cap" ref={(el) => { refs.current.capacity = el; }} type="number" inputMode="numeric" min={1} step={1} className="pl-9"
                    value={form.capacity} disabled={disabled || form.visibility === 'private'} onChange={(e) => set('capacity', e.target.value)} placeholder="No limit" />
                </div>
              </Field>
            </div>
          </Section>

          <Section title="YouTube live link" subtitle="Create an UNLISTED live stream on YouTube and paste its link. The same video serves the live event and its replay; only people who paid can see it (a free event: anyone signed in).">
            <Field label="Unlisted YouTube link" htmlFor="ev-yt" error={errors.youtube_url}>
              <Input id="ev-yt" ref={(el) => { refs.current.youtube_url = el; }} inputMode="url" value={form.youtube_url} disabled={disabled}
                onChange={(e) => set('youtube_url', e.target.value)} placeholder="https://youtube.com/live/…" aria-invalid={!!errors.youtube_url} />
            </Field>
            {ytId && form.youtube_url === (base?.youtube_url ?? '') && (
              <div className="flex items-center gap-3">
                <img src={youtubeThumb(ytId)} alt="Video thumbnail" className="aspect-video w-40 rounded-md border border-border/70 object-cover" />
                <span className="inline-flex items-center gap-1.5 text-[13px] font-bold text-accent"><MonitorPlay className="h-4 w-4" /> Linked · id {ytId}</span>
              </div>
            )}
            {formYtId && (
              <VideoCropEditor videoId={formYtId} title={form.title} disabled={disabled}
                value={cropFromForm(form.youtube_crop)} saved={cropFromForm(base?.youtube_crop ?? '')}
                onChange={(c) => set('youtube_crop', cropToForm(c))} />
            )}
          </Section>

          {/* [SAATHUM-CHADHAVA 2026-09-26] Stays editable on a completed event — the admin
              pastes this after the havan, once the recording is ready. */}
          <Section title="Video download link" subtitle="Paste after the event — devotees see a Download button in Past events.">
            <Field label="Download link" htmlFor="ev-video-url" error={errors.video_download_url}>
              <Input id="ev-video-url" ref={(el) => { refs.current.video_download_url = el; }} inputMode="url" value={form.video_download_url}
                disabled={busy !== null} onChange={(e) => set('video_download_url', e.target.value)} placeholder="https://…" aria-invalid={!!errors.video_download_url} />
            </Field>
            {isClosed && (
              <Button type="button" variant="outline" className="self-start" disabled={busy !== null || form.video_download_url === (base?.video_download_url ?? '')}
                onClick={() => void onSaveVideoUrl()}>
                {busy === 'video_url' ? <Loader2 className="animate-spin" /> : <Save />} Save link
              </Button>
            )}
          </Section>

          <Section title="Google & WhatsApp" subtitle="Written for you automatically every time you save. Type to override; clear a box to go back to automatic.">
            <Field label="Google title" htmlFor="ev-seo-t" error={errors.seo_title}
              hint={form.seo_title ? `${form.seo_title.length}/${meta?.limits.seoTitleMax ?? 70} · yours` : 'Automatic'}>
              <Input id="ev-seo-t" ref={(el) => { refs.current.seo_title = el; }} value={form.seo_title} maxLength={meta?.limits.seoTitleMax ?? 70} disabled={disabled}
                onChange={(e) => set('seo_title', e.target.value)} placeholder={detail?.event.seo?.title || 'Written automatically when you save'} />
            </Field>
            <Field label="Google description" htmlFor="ev-seo-d" error={errors.seo_description}
              hint={form.seo_description ? `${form.seo_description.length}/${meta?.limits.seoDescriptionMax ?? 170} · yours` : 'Automatic'}>
              <textarea id="ev-seo-d" ref={(el) => { refs.current.seo_description = el; }} rows={3} value={form.seo_description}
                maxLength={meta?.limits.seoDescriptionMax ?? 170} disabled={disabled} onChange={(e) => set('seo_description', e.target.value)}
                placeholder={detail?.event.seo?.description || 'Written automatically when you save'}
                className="flex w-full rounded-md border border-input bg-card px-3 py-2 text-base text-foreground shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm" />
            </Field>
            {(form.seo_title || detail?.event.seo?.title) && (
              <div className="rounded-lg border border-border/70 bg-background p-3" aria-label="Google preview">
                <p className="text-[12px] font-semibold text-muted-foreground">{BRAND.domain} › book</p>
                <p className="text-[17px] font-semibold leading-snug text-grand-teal">{form.seo_title || detail?.event.seo?.title}</p>
                <p className="text-[13px] leading-snug text-muted-foreground">{form.seo_description || detail?.event.seo?.description}</p>
              </div>
            )}
            <Field label="WhatsApp share line" hint="Printed on the share image">
              <p className="text-[14px] font-semibold text-foreground">
                {detail?.event.ad_hook ?? <span className="text-muted-foreground">AI writes this when you publish, with the real price beside it.</span>}
              </p>
            </Field>
            {id && <Button type="button" variant="outline" className="self-start" onClick={onWhatsApp}><MessageCircle /> Share on WhatsApp</Button>}
          </Section>
        </div>

        {/* ── Side column: readiness + actions ── */}
        <aside className="flex flex-col gap-4 lg:sticky lg:top-6">
          <div className="dash-surface rounded-xl border border-border/70 bg-card p-4">
            <h2 className="font-dash text-[17px] font-bold text-grand-teal">Before publishing</h2>
            {!id ? (
              <p className="mt-2 text-[14px] font-semibold text-muted-foreground">Save the event to check what's still missing.</p>
            ) : isClosed ? (
              <p className="mt-2 text-[14px] font-semibold text-muted-foreground">Nothing to do.</p>
            ) : isPublic ? (
              <p className="mt-2 flex items-center gap-2 text-[14px] font-semibold text-foreground"><CircleCheck className="h-4 w-4 text-accent" /> Live on the site and taking bookings.</p>
            ) : blockers.length === 0 && posterPlan?.kind !== 'needs_image' ? (
              <p className="mt-2 flex items-center gap-2 text-[14px] font-semibold text-foreground"><CircleCheck className="h-4 w-4 text-accent" /> Ready to publish.</p>
            ) : (
              <ul className="mt-3 flex flex-col gap-2">
                {blockers.map((b) => {
                  const f = b.field ? FIELD_OF_BLOCKER[b.field] : undefined;
                  return (
                    <li key={b.code} className="flex items-start gap-2 text-[14px] font-semibold text-foreground">
                      <CircleAlert className="mt-0.5 h-4 w-4 shrink-0 text-destructive" />
                      <span>{b.message}{f && <button type="button" className="ml-1 font-bold text-accent underline-offset-2 hover:underline" onClick={() => focusField(f)}>Fix</button>}</span>
                    </li>
                  );
                })}
                {posterPlan?.kind === 'needs_image' && (
                  <li className="flex items-start gap-2 text-[14px] font-semibold text-foreground">
                    <CircleAlert className="mt-0.5 h-4 w-4 shrink-0 text-destructive" />
                    <span>{posterPlan.message}</span>
                  </li>
                )}
              </ul>
            )}
            {id && dirty && !isClosed && <p className="mt-3 text-[12px] font-semibold text-muted-foreground">You have unsaved changes — this list is for the saved version.</p>}
          </div>

          {ev && (
            <div className="dash-surface rounded-xl border border-border/70 bg-card p-4 text-[14px] font-semibold">
              <dl className="grid grid-cols-[auto_1fr] gap-x-3 gap-y-1.5">
                <dt className="text-muted-foreground">Starts</dt><dd className="text-foreground">{fmtIstDateTime(ev.starts_at)}</dd>
                <dt className="text-muted-foreground">Price</dt><dd className="text-foreground">{ev.free_watch ? 'Free' : formatPaise(ev.price_paise)}</dd>
                <dt className="text-muted-foreground">Booked</dt><dd className="text-foreground">{ev.seats_booked}{ev.capacity ? ` of ${ev.capacity}` : ''}{ev.pending_payments ? ` · ${ev.pending_payments} paying` : ''}</dd>
                <dt className="text-muted-foreground">Video</dt><dd className="text-foreground">{ev.youtube_set ? 'Linked' : 'Not linked yet'}</dd>
              </dl>
            </div>
          )}

          {!isClosed && (
            <div className="fixed inset-x-0 bottom-[calc(var(--dash-tabbar-h,64px)+env(safe-area-inset-bottom,0px))] z-30 border-t border-border bg-card/95 p-3 backdrop-blur sm:bottom-0 sm:left-[var(--dash-rail-w,72px)] lg:static lg:z-auto lg:rounded-xl lg:border lg:bg-card lg:p-4 lg:backdrop-blur-none">
              <div className="mx-auto flex max-w-6xl flex-wrap gap-2 lg:flex-col">
                <Button variant="outline" className="flex-1" disabled={busy !== null || (!!id && !dirty)} onClick={() => void onSave()}>
                  {busy === 'save' ? <Loader2 className="animate-spin" /> : <Save />} {isPublic ? 'Save changes' : 'Save draft'}
                </Button>
                {!isPublic ? (
                  <Button className="flex-1" disabled={busy !== null} onClick={() => void onPublish()}>
                    {busy === 'publish' ? <Loader2 className="animate-spin" /> : <Send />} Publish
                  </Button>
                ) : status === 'published' ? (
                  <Button variant="secondary" className="flex-1" disabled={busy !== null || (ev?.seats_booked ?? 0) > 0 || (ev?.pending_payments ?? 0) > 0}
                    title={(ev?.seats_booked ?? 0) > 0 ? 'People have booked — cancel instead' : undefined} onClick={() => void onUnpublish()}>
                    {busy === 'unpublish' ? <Loader2 className="animate-spin" /> : <Undo2 />} Unpublish
                  </Button>
                ) : null}
                {id && (isPublic || status === 'draft') && (
                  <Button variant="ghost" className="flex-1 text-destructive hover:bg-destructive/10" disabled={busy !== null} onClick={() => setConfirmCancel(true)}>
                    <Ban /> {status === 'draft' ? 'Discard draft' : 'Cancel event'}
                  </Button>
                )}
                {id && (() => {
                  const sold = (ev?.seats_booked ?? 0) > 0 || (ev?.pending_payments ?? 0) > 0;
                  return (
                    <Button variant="ghost" className="flex-1 text-destructive hover:bg-destructive/10" disabled={busy !== null || deleting || sold}
                      title={sold ? 'People have booked or are paying — cancel instead. Payment records are kept.' : undefined}
                      onClick={() => { setDeleteError(null); setConfirmDelete(true); }}>
                      <Trash2 /> Delete permanently
                    </Button>
                  );
                })()}
              </div>
            </div>
          )}
        </aside>
      </div>

      <AlertDialog open={confirmCancel} onOpenChange={(o) => { if (busy !== 'cancel') setConfirmCancel(o); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{status === 'draft' ? 'Discard this draft?' : 'Cancel this event?'}</AlertDialogTitle>
            <AlertDialogDescription>
              {status === 'draft'
                ? 'It moves to Cancelled. Nothing was sold.'
                : (ev?.seats_booked ?? 0) > 0
                  ? `${ev!.seats_booked} ${ev!.seats_booked === 1 ? 'person has' : 'people have'} booked. Every open booking is refunded first; any that need a manual UPI refund appear in Refunds. This can't be undone.`
                  : 'Nobody has booked yet. The event comes off the site. This can’t be undone.'}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={busy === 'cancel'}>Keep it</AlertDialogCancel>
            <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" disabled={busy === 'cancel'}
              onClick={(e) => { e.preventDefault(); void onCancel(); }}>
              {busy === 'cancel' && <Loader2 className="animate-spin" />} {status === 'draft' ? 'Discard' : 'Cancel event'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <DeleteDialog open={confirmDelete} onOpenChange={setConfirmDelete} busy={deleting} error={deleteError}
        title="Delete this event permanently?" body={DELETE_EVENT_BODY} onConfirm={() => void onDelete()} />
    </div>
  );
}

/* ── small building blocks ─────────────────────────────────────────────── */

function fmtYmd(ymd: string): string {
  const d = dateOfYmd(ymd);
  return d ? d.toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' }) : ymd;
}

function Section({ title, subtitle, children }: { title: string; subtitle?: string; children: ReactNode }) {
  return (
    <section className="dash-surface flex flex-col gap-4 rounded-xl border border-border/70 bg-card p-4 sm:p-5">
      <header>
        <h2 className="font-dash text-[18px] font-bold text-grand-teal">{title}</h2>
        {subtitle && <p className="mt-1 text-[13px] font-semibold text-muted-foreground">{subtitle}</p>}
      </header>
      {children}
    </section>
  );
}

function ToggleRow({ id, label, hint, checked, disabled, onChange }: { id: string; label: string; hint: string; checked: boolean; disabled?: boolean; onChange: (v: boolean) => void }) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-lg border border-border/70 bg-background px-3 py-2.5">
      <div>
        <Label htmlFor={id} className="font-bold">{label}</Label>
        <p className="text-[12px] font-semibold text-muted-foreground">{hint}</p>
      </div>
      <Switch id={id} checked={checked} disabled={disabled} onCheckedChange={onChange} aria-label={label} />
    </div>
  );
}

function Field({ label, htmlFor, error, hint, children }: { label: string; htmlFor?: string; error?: string; hint?: string; children: ReactNode }) {
  return (
    <div className="flex flex-col gap-1.5">
      <div className="flex items-baseline justify-between gap-2">
        <Label htmlFor={htmlFor} className="font-bold">{label}</Label>
        {hint && !error && <span className="text-[12px] font-semibold text-muted-foreground">{hint}</span>}
      </div>
      {children}
      {error && <p className="text-[13px] font-semibold text-destructive" role="alert">{error}</p>}
    </div>
  );
}
