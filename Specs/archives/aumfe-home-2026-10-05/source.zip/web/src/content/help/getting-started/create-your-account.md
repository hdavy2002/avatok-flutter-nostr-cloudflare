---
title: "Signing up for an account on {{brand.name}}"
description: "How to sign up on {{brand.domain}} with an email code and an Indian mobile OTP, and why onboarding and your {{brand.name}} number are completed in the app."
section: getting-started
order: 2
updated: 2026-09-11
keywords: ["sign up", "signup", "create account", "otp", "email code", "verification", "phone number", "{{brand.name}} number"]
audience: both
faq:
  - q: "What do I need to sign up on the website?"
    a: "Your name, an email address you can check, and an Indian mobile number (+91) — you'll verify both with a one-time code before your account opens."
  - q: "Do I get my {{brand.name}} number when I sign up on the web?"
    a: "No. Web sign-up creates your account; choosing your {{brand.name}} number and the rest of onboarding happen the first time you open the {{brand.name}} app."
  - q: "Why does {{brand.name}} need my real phone number if it stays confidential?"
    a: "It's used to verify you're a real person and to secure your account — everyone else only ever sees your {{brand.name}} number, never your real one."
draft: false
---

<!-- rebrand: reviewed -->

## What you need

Signing up on {{brand.domain}} ([create an account](/sign-up)) takes three things: your first and last name, an email inbox you can open, and an Indian mobile number. Each of the email and the number is confirmed with a one-time code before the account exists — you never set or remember a password.

## How it works, step by step

1. **Enter your name and email**, then tap Verify. A 6-digit code lands in your inbox, and a box slides open on the same screen to enter it — there's no separate "check your email" page.
2. **Once your email is verified**, the mobile number field unlocks. Enter your 10-digit number — the country code is fixed to **+91**, since phone verification on the web is for Indian numbers only.
3. **Tap Send OTP.** A 6-digit code arrives on WhatsApp (the number must have WhatsApp), and you enter it in the same inline box. Both your email and phone show a green "Verified" tick once confirmed.
4. **Accept the terms** (you'll need to be 18 or over) and tap **Create my account**. Your account is created only after both checks pass — an account can't be opened without verifying both.

You can also start with **Google** — it fills in your name and email, and you still verify a phone number afterwards.

## Why the phone number, if it stays confidential?

Verifying a real mobile number is how {{brand.name}} confirms you're a genuine person and secures your account against takeover. It is never shown to anyone else. Once you're through onboarding in the app, your public identity to other users is a separate **{{brand.name}} number** that keeps your real one masked.

## What happens after you sign up

Creating your account on the web is the first step, not the whole thing. Once it's created, you land on [Our Pujas](/marketplace), ready to choose a ritual. You can book, pay and watch right in your browser — no app needed. See [Choosing and booking a ritual](/help/booking-and-paying/how-to-book).

## Already have an account?

Use [sign in](/sign-in) instead — the same email-code verification applies there too, since there are no passwords on {{brand.name}}.

## Trouble signing up

If an email address already has an account, sign-up will tell you to log in instead. If a code doesn't arrive, you can resend it after a short wait shown on screen. For anything else, see [Report a problem](/help/account-and-safety/report-a-problem) or write to support (@) {{brand.domain}}.
