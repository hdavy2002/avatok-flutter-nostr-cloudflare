// [WEB-SEO-5 2026-09-10] Single source of truth for the brand/company facts
// that feed structured data (and, gradually, the visible chrome) across the
// site. Before this file, the Organization/WebSite/WebPage JSON-LD graph was
// defined inline in Base.astro's frontmatter — correct, but it meant "add the
// Pvt Ltd name" or "add the Instagram link" required understanding and
// editing a raw schema.org object. Now those are one field each, here.
//
// Everything below carries forward the reasoning that used to live as a
// comment above Base.astro's `orgLd` ([WEB-SEO-1]/[WEB-SEO-2]) — read it
// before changing a value, not just the field's name.
//
// [WEB-SEO-REBRAND-1 2026-09-27] OWNER DECISION: Saa Thum is "a small team in
// Dehradun, Uttarakhand" (the wording on /about; office moved from Mumbai, owner 2026-09-29). No company name is published
// and NO foreign entity or address may appear anywhere on saathum.com — the old
// Delaware values that sat here were removed. When an Indian company is actually
// registered, set legalName and the registered office here.
//
// `sameAs` must only list profiles that resolve today. The Play listing is
// Closed Alpha and returns 404 to the public, so it is deliberately absent —
// a 404 in sameAs is worse than no entry. Add it once the app is public.
//
// A field set to `null` means "not known / not public yet" and is OMITTED
// from the JSON-LD output by `orgJsonLd()` below — it never emits `null`,
// an empty string, or a placeholder into the graph.

import { BRAND, brandUrl } from './brand';
export interface PostalAddress {
  /** Public address for the legal entity. */
  locality: string;
  region: string;
  country: string;
  /** Set only once a real, publishable street address exists. */
  street: string | null;
  postalCode: string | null;
}

export interface ParentOrg {
  name: string;
  region: string;
  country: string;
}

export interface OperatingEntity {
  /** Indian operating entity; publish an address only once it is finalized. */
  name: string;
  locality: string;
  country: string;
  registeredOffice: string | null;
}

export interface SameAs {
  youtube: string | null;
  /** Company Page (not a personal profile — founders stay anonymous, [WEB-SEO-7]). */
  linkedin: string | null;
  crunchbase: string | null;
  wikidata: string | null;
  instagram: string | null;
  /** Closed Alpha today — the public listing 404s. Set once the app is public. */
  playStore: string | null;
}

export interface OrgLogo {
  url: string;
  width: number;
  height: number;
}

export interface OrgConstants {
  /** The brand name. This is the Organization's `name` — see NAMING RULE above. */
  name: string;
  alternateNames: string[];
  /** Registered legal name — null until an Indian company is registered. */
  legalName: string | null;
  url: string;
  logo: OrgLogo;
  description: string;
  slogan: string;
  // [WEB-SEO-7] Owner decision 2026-09-10: founders are never named publicly.
  // Do NOT add a schema.org `founder` Person node.
  foundersDescription: string;
  foundingDate: string;
  email: string;
  address: PostalAddress;
  parent: ParentOrg;
  indianEntity: OperatingEntity;
  sameAs: SameAs;
  languages: string[];
  contactUrl: string;
  /** {search_term_string} is a literal template placeholder, not interpolated here. */
  searchUrlTemplate: string;
}

export const ORG: OrgConstants = {
  name: BRAND.name,
  alternateNames: [BRAND.name.replace(/\s+/g, ''), BRAND.domain, BRAND.nameHindi],
  // [SAATHUM-ENTITY-1 2026-09-25] Owner: no legal-entity info published on saathum.com.
  legalName: null,
  url: brandUrl('/'),
  // [BRAND-LOGO-1 2026-09-27] Square diya mark for Google's Organization logo.
  logo: {
    url: brandUrl('/assets/logo/favicon-512.png'),
    width: 512,
    height: 512,
  },
  // rebrand: reviewed — [SAATHUM-REBRAND-1 2026-09-25]
  // [WEB-SEO-REBRAND-1 2026-09-27] Same wording as /about and /llms.txt.
  description:
    // [WEB-REFRAME-1 2026-09-29] OWNER: Himalayan temple havans, positive temples only, supporting mountain pujaris.
    `${BRAND.name} (${BRAND.domain}) arranges havans and pujas online, performed in your name at remote Himalayan temples in Uttarakhand and Himachal. Each ritual is led by the temple's own pujari while our travelling crew films it: streamed live when the mountain network holds, and always recorded in full for you to watch or download. Dry prasad is couriered from the temple. We partner only with positive temples of Shiva and Parvati, Vishnu, Ram and Sita, Krishna and the gentle Himalayan Devis, and each booking helps the pujaris and villages who care for them.`,
  slogan: 'Faith, brought home to you.',
  foundersDescription: '',
  foundingDate: '2025',
  // [SAATHUM-BRAND-1 2026-09-20] Left as the avatok.ai mailbox on purpose —
  // per the rename's hard rule, existing @avatok.ai mailboxes stay working
  // and are not renamed as part of this sweep. Point this at a saathum.com
  // mailbox once one exists and is verified (see
  // Specs/PLAN-2026-09-20-SAATHUM-EMAIL-DOMAIN-CUTOVER.md).
  email: BRAND.emails.support,
  address: {
    locality: 'Dehradun',
    region: 'Uttarakhand',
    country: 'IN',
    // [owner 2026-09-29] Office moved to Dehradun; city only, no street published.
    street: null,
    postalCode: null,
  },
  parent: {
    // [WEB-SEO-REBRAND-1] No parent organisation. Kept only for the type.
    name: '',
    region: '',
    country: '',
  },
  indianEntity: {
    name: '',
    locality: 'Dehradun',
    country: 'IN',
    registeredOffice: null,
  },
  sameAs: {
    // [SAATHUM-BRAND-1 2026-09-20] These four profiles (youtube/@avatok,
    // linkedin/company/avatok, the Saa Thum Wikidata item) were the Saa Thum
    // brand's real, resolving accounts — `sameAs` must only list profiles
    // that resolve TODAY (see the file header), and none of them are
    // Saa Thum's. Nulled rather than repointed at a guessed Saa Thum handle;
    // set each once a real Saa Thum profile exists. avatok.ai keeps its own
    // accounts as the frozen snapshot's brand facts (lane 06).
    youtube: null,
    linkedin: null,
    crunchbase: null,
    wikidata: null,
    // Set once a real, resolving Instagram profile exists.
    instagram: null,
    // Closed Alpha — 404s publicly today. Set once the Play listing is public.
    playStore: null,
  },
  languages: ['en'],
  contactUrl: '/contact',
  searchUrlTemplate: brandUrl('/marketplace?q={search_term_string}'),
};

/** Filters `ORG.sameAs` down to the profiles that are actually set. */
export function sameAsList(): string[] {
  return Object.values(ORG.sameAs).filter((v): v is string => v != null);
}

export interface PageLdInput {
  canonical: string;
  title: string;
  description: string;
  ogImage: string;
}

/**
 * Builds the site-wide Organization/WebSite/WebPage JSON-LD graph from ORG.
 * Answer engines read this to decide what Saa Thum *is*; keep it consistent
 * with the visible copy on /about. This is the same graph shape Base.astro
 * used to build inline ([WEB-SEO-1]/[WEB-SEO-2]) — same @ids, same nodes —
 * just sourced from ORG so one field edit here reaches every page.
 *
 * [WEB-SEO-2 2026-09-10] Enriched for Google's knowledge panel and
 * sitelinks. The panel Google draws beside a brand search is assembled from
 * the Knowledge Graph, and the Knowledge Graph is fed by exactly the fields
 * below: a square logo (>=112px, ImageObject), `sameAs` official profiles, a
 * parent organisation, founding date, contact point and a locality. The
 * WebSite node gains a SearchAction so Google can offer a sitelinks search
 * box that posts to /marketplace?q=. None of this is a ranking signal — it
 * is what lets Google SHOW more once the pages rank.
 */
export function orgJsonLd({ canonical, title, description, ogImage }: PageLdInput): object {
  const orgId = `${ORG.url}#organization`;
  const websiteId = `${ORG.url}#website`;
  const logoId = `${ORG.url}#logo`;

  const organization: Record<string, unknown> = {
    '@type': 'Organization',
    '@id': orgId,
    name: ORG.name,
    alternateName: ORG.alternateNames,
    url: ORG.url,
    logo: {
      '@type': 'ImageObject',
      '@id': logoId,
      url: ORG.logo.url,
      contentUrl: ORG.logo.url,
      width: ORG.logo.width,
      height: ORG.logo.height,
      caption: ORG.name,
    },
    image: { '@id': logoId },
    description: ORG.description,
    // [SAATHUM-BRAND-1 2026-09-20] [WEB-SEO-6]'s original disambiguation
    // ("avatok" collided with avatok.tech and an avatar-video app) no longer
    // applies under the Saa Thum name — no known collision exists, so this is
    // now a plain entity description rather than a "not to be confused with"
    // claim. Mirrors the visible FAQ on /about (components/EntityFaq.astro).
    disambiguatingDescription:
      `An online havan and puja service at ${BRAND.domain}, based in Dehradun, Uttarakhand — its crew travels to positive Himalayan temples where local pujaris perform havans in the devotee's name, filmed for families in India and abroad.`,
    knowsAbout: ['havan', 'puja', 'sankalp', 'Himalayan temples', 'Uttarakhand temples', 'online havan', 'puja video', 'prasad delivery'],
    slogan: ORG.slogan,
    foundingDate: ORG.foundingDate,
    areaServed: 'Worldwide',
    knowsLanguage: ORG.languages,
    email: ORG.email,
    contactPoint: [
      {
        '@type': 'ContactPoint',
        contactType: 'customer support',
        email: ORG.email,
        url: new URL(ORG.contactUrl, ORG.url).toString(),
        areaServed: 'Worldwide',
        availableLanguage: ['English'],
      },
    ],
    sameAs: sameAsList(),
    // [WEB-SEO-REBRAND-1 2026-09-27] Where Saa Thum is — the neighbourhood named on /about.
    address: {
      '@type': 'PostalAddress',
      ...(ORG.address.street ? { streetAddress: ORG.address.street } : {}),
      addressLocality: ORG.address.locality,
      addressRegion: ORG.address.region,
      addressCountry: ORG.address.country,
      ...(ORG.address.postalCode ? { postalCode: ORG.address.postalCode } : {}),
    },
  };
  if (ORG.legalName != null) {
    organization.legalName = ORG.legalName;
  }

  const website = {
    '@type': 'WebSite',
    '@id': websiteId,
    url: ORG.url,
    name: ORG.name,
    alternateName: BRAND.domain,
    // The WebSite is one stable entity; a page-specific description belongs
    // on WebPage/Article, never on the site node.
    description: ORG.description,
    inLanguage: 'en-IN',
    publisher: { '@id': orgId },
    potentialAction: {
      '@type': 'SearchAction',
      target: {
        '@type': 'EntryPoint',
        urlTemplate: ORG.searchUrlTemplate,
      },
      'query-input': 'required name=search_term_string',
    },
  };

  const webPage = {
    '@type': 'WebPage',
    '@id': `${canonical}#webpage`,
    url: canonical,
    name: title,
    description,
    isPartOf: { '@id': websiteId },
    about: { '@id': orgId },
    inLanguage: 'en-IN',
    primaryImageOfPage: { '@type': 'ImageObject', url: ogImage },
  };

  return {
    '@context': 'https://schema.org',
    '@graph': [organization, website, webPage],
  };
}
