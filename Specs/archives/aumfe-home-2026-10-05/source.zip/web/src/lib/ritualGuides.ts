// [SAATHUM-GUIDE-1 2026-09-25] The Puja & Havan Guide — editorial knowledge
// articles, one per ritual Saa Thum performs. Source: owner's "Havan & Puja
// Catalogue" (30 havans + 25 pujas). This is EDITORIAL content, not bookable
// inventory — prices, dates and seats live in the marketplace ("Our Pujas").
//
// Replaces the old creator /ideas page (archived, 301 → /rituals).
//
// IMAGES: every ritual has ONE image at /assets/rituals/<slug>.png
// (file on disk: web/public/assets/rituals/<slug>.png, 1536×1024).
// The card, the article hero and the social preview all read `image`, so the
// moment a file is dropped in with the right name it shows up everywhere.
// Prompts for every file: Specs/saathum-ritual-images/IMAGE-PROMPTS.md.
//
// COPY RULES (owner brief): only benefic rituals, serene deity forms, no fear
// selling, no guaranteed outcomes, no medical claims. Benefits are what
// devotees traditionally seek — the page says so.

import { BRAND } from './brand';

export type RitualType = 'havan' | 'puja';
export type RitualCategory = keyof typeof ritualCategories;

export const ritualCategories = {
  education: 'Education',
  luck: 'Good Luck & New Beginnings',
  wealth: 'Wealth',
  career: 'Career & Business',
  health: 'Health',
  family: 'Family & Relationships',
  peace: 'Peace & Protection',
  life: 'Life Events',
  festival: 'Festivals',
} as const;

/** Short labels for tight spaces (homepage card pills). */
export const ritualCategoryShort: Record<RitualCategory, string> = {
  education: 'Education', luck: 'Good luck', wealth: 'Wealth', career: 'Career', health: 'Health',
  family: 'Family', peace: 'Peace', life: 'Life events', festival: 'Festivals',
};

export const ritualTypes: Record<RitualType, string> = { havan: 'Havan', puja: 'Puja' };

export const RITUAL_IMAGE_DIR = '/assets/rituals';

type RitualSource = {
  slug: string;
  type: RitualType;
  title: string;
  deity: string;
  category: RitualCategory;
  description: string;
  benefits: string[];
  whoFor: string;
  bestTime: string;
  duration: string;
  offerings: string;
  tags: string[];
  /** Serene-form image brief; also used for alt text. */
  imagePrompt: string;
  /** Extra line for rituals that need one (health, muhurat, etc.). */
  note?: string;
  muhurat?: 'none' | 'recommended' | 'required';
};

export type Ritual = RitualSource & { href: string; image: string; imageAlt: string };

const sources: RitualSource[] = [
  // ───────────────────────────── HAVANS (30) ─────────────────────────────
  { slug: 'saraswati-havan', type: 'havan', title: 'Saraswati Havan', deity: 'Goddess Saraswati', category: 'education',
    description: "Offerings into the sacred fire for Saraswati, goddess of learning, music and speech — held before exams, admissions, creative work or a child's first lessons.",
    benefits: ['Sharper focus and memory', 'Confidence in studies and exams', 'Blessings for arts, music and writing'],
    whoFor: 'Students, parents of school-going children, teachers, artists, writers, and anyone starting a course or creative venture.',
    bestTime: 'Vasant Panchami, Navratri (7th–9th day), Thursdays, or before an exam.', duration: '60–90 min',
    offerings: 'White flowers, ghee, sesame, rice, sandalwood, and a pen or book placed at the altar.',
    tags: ['exams', 'students', 'knowledge', 'music', 'arts', 'children'],
    imagePrompt: 'Goddess Saraswati in a white saree seated on a white lotus, playing a veena, holding a book and rosary, white swan at her side, soft golden morning light, small fire altar in the corner.' },
  { slug: 'gayatri-havan', type: 'havan', title: 'Gayatri Havan', deity: 'Gayatri Devi', category: 'education',
    description: 'A havan offered with the Gayatri mantra, the Vedic prayer most revered for lighting up the mind. Gentle and fit for any occasion, it is sought for clarity.',
    benefits: ['Clarity of thought', 'Discipline and willpower', 'Spiritual growth', 'Lifts mental fog'],
    whoFor: 'Students, professionals facing big decisions, spiritual seekers, and anyone feeling confused or scattered.',
    bestTime: 'Sunrise, Sundays, Gayatri Jayanti, Purnima.', duration: '60–120 min (often 108 or 1008 offerings)',
    offerings: 'Ghee, havan samagri, sandalwood, rice, sugar.',
    tags: ['clarity', 'wisdom', 'mantra', 'daily', 'beginners'],
    imagePrompt: 'Five-faced Goddess Gayatri in radiant red and gold seated on a lotus, sunrise glow behind her, faint golden light rays in the air, calm and luminous.' },
  { slug: 'hayagriva-havan', type: 'havan', title: 'Hayagriva Havan', deity: 'Lord Hayagriva (Vishnu)', category: 'education',
    description: 'Hayagriva, the horse-headed form of Vishnu, guards all knowledge. Scholars offer this havan for higher studies, research and competitive exams.',
    benefits: ['Excellent memory', 'Success in competitive exams', 'Mastery over a subject', 'Eloquence'],
    whoFor: 'Higher-education students, researchers, UPSC/NEET/JEE aspirants, teachers and speakers.',
    bestTime: 'Thursdays, Shravana nakshatra, Hayagriva Jayanti (Shravan Purnima).', duration: '60–90 min',
    offerings: 'Ghee, cardamom, tulsi, white flowers, sweet pongal or payasam.',
    tags: ['exams', 'research', 'memory', 'higher studies'],
    imagePrompt: 'Gentle white horse-headed Lord Hayagriva in blue and gold robes, holding a book and conch, seated peacefully on a lotus with a soft white aura.' },
  { slug: 'dakshinamurthy-havan', type: 'havan', title: 'Dakshinamurthy (Medha) Havan', deity: 'Lord Dakshinamurthy (Shiva as the teacher)', category: 'education',
    description: 'Honours Shiva as Dakshinamurthy, the silent teacher of the world. Chosen for deeper focus, for grasping hard subjects, and for meeting a good mentor.',
    benefits: ['Deep concentration', 'Understanding rather than rote memory', 'Guidance from good teachers', 'A calm mind'],
    whoFor: 'Students struggling with focus, PhD scholars, teachers and coaches, and anyone seeking a guru.',
    bestTime: 'Thursdays, Pradosham, Guru Purnima.', duration: '60–90 min',
    offerings: 'Bilva leaves, ghee, honey, sesame, rice.',
    tags: ['focus', 'mentor', 'wisdom', 'Shiva', 'teachers'],
    imagePrompt: 'Young serene Shiva as Dakshinamurthy seated under a banyan tree, right hand in chin-mudra, four sages listening at his feet, dappled sunlight, peaceful forest.' },
  { slug: 'brihaspati-havan', type: 'havan', title: 'Brihaspati (Guru Graha) Havan', deity: 'Brihaspati (Jupiter)', category: 'education',
    description: 'Offered to Brihaspati, teacher of the devas, who is revered in tradition for wisdom, higher learning, the blessing of children and good fortune in life.',
    benefits: ['Better judgement', 'Success in higher education and law', 'Good fortune', 'Blessings for children and marriage'],
    whoFor: 'Students of law, philosophy or finance, teachers, and people seeking wisdom and direction in life.',
    bestTime: 'Thursdays and Guru Purnima.', duration: '60–90 min',
    offerings: 'Yellow flowers, chana dal, turmeric, ghee, yellow cloth, peepal samidha.',
    tags: ['Brihaspati', 'wisdom', 'learning', 'Thursday'],
    imagePrompt: 'Wise elderly sage Brihaspati in yellow-gold robes with a flowing white beard, holding a staff and scriptures, seated on a golden throne with a warm yellow aura.' },
  { slug: 'ganapati-havan', type: 'havan', title: 'Ganapati Havan', deity: 'Lord Ganesha', category: 'luck',
    description: 'The havan families hold before anything new. Ganesha, remover of obstacles, is invoked to bless a fresh beginning — a new job, home, business or journey.',
    benefits: ['Clears obstacles', 'A smooth start to new projects', 'Good luck', 'Confidence'],
    whoFor: 'Anyone starting something new — a job, business, home, wedding season, travel or exams.',
    bestTime: 'Chaturthi tithi, Wednesdays, Ganesh Chaturthi, or the morning of a new beginning.', duration: '45–75 min',
    offerings: 'Modak, durva grass, red flowers, ghee, jaggery, coconut.',
    tags: ['new beginnings', 'obstacles', 'luck', 'business', 'most popular'],
    imagePrompt: 'Joyful Lord Ganesha in red and gold, holding a modak and lotus, little mouse at his feet, marigold garlands, warm festive light.' },
  { slug: 'satyanarayana-havan', type: 'havan', title: 'Satyanarayana Havan', deity: 'Lord Satyanarayana (Vishnu)', category: 'luck',
    description: 'A havan of thanks and blessing, held by families after happy news or to welcome prosperity and harmony into the household.',
    benefits: ['Family harmony', 'Gratitude and contentment', 'Prosperity', 'Fulfilment of wishes'],
    whoFor: 'Families celebrating a milestone (new home, job, baby, recovery), newly married couples, and anyone wanting a general blessing.',
    bestTime: 'Purnima (full moon), Ekadashi, Thursdays.', duration: '90–120 min',
    offerings: 'Panchamrit, tulsi, bananas, wheat-flour prasad (sheera), betel leaves.',
    tags: ['family', 'gratitude', 'full moon', 'celebration', 'home'],
    imagePrompt: 'Lord Vishnu in blue with a golden crown, four arms holding conch, discus, mace and lotus, seated on a flower-decorated altar with fruits, tulsi and a lit lamp.' },
  { slug: 'vastu-shanti-havan', type: 'havan', title: 'Vastu Shanti Havan', deity: 'Vastu Purusha & Lord Ganesha', category: 'luck',
    description: 'Brings balance to the energy of a house, shop or office, and is offered to ease vastu defects that building work alone cannot correct.',
    benefits: ['Harmony in the space', 'Eases vastu dosha', 'Wellbeing and prosperity for those who live there'],
    whoFor: 'New home or office owners, anyone experiencing constant friction after moving, and businesses in new premises.',
    bestTime: 'Before moving in, or any auspicious muhurat; avoid Amavasya.', duration: '90–120 min',
    offerings: 'Five grains, copper vastu yantra, ghee, red flowers.',
    tags: ['home', 'office', 'vastu', 'moving', 'property'], muhurat: 'recommended',
    imagePrompt: 'A glowing sacred grid of a home floor plan seen from above, Lord Ganesha at the entrance, small lamps at every corner, peaceful golden light.' },
  { slug: 'griha-pravesh-havan', type: 'havan', title: 'Griha Pravesh Havan', deity: 'Lord Ganesha, Lord Vishnu & Goddess Lakshmi', category: 'life',
    description: 'The havan for a housewarming: it blesses a new home before the family moves in and welcomes Goddess Lakshmi to dwell there.',
    benefits: ['An auspicious start in the new home', 'Protection', 'Prosperity', 'Family unity'],
    whoFor: 'Families moving into a newly built or bought home, and tenants entering a new house.',
    bestTime: 'An auspicious muhurat; popular months are Magh, Phalgun, Vaishakh and Jyeshtha.', duration: '120–180 min',
    offerings: 'Kalash, coconut, milk (boiled to overflow), rice, ghee, fresh flowers.',
    tags: ['housewarming', 'new home', 'family', 'muhurat'], muhurat: 'required',
    imagePrompt: 'A decorated doorway with mango leaves and a colourful rangoli, Goddess Lakshmi and Lord Ganesha blessing from above, a family lighting a lamp on the threshold.' },
  { slug: 'lakshmi-havan', type: 'havan', title: 'Lakshmi Havan', deity: 'Goddess Lakshmi', category: 'wealth',
    description: 'Calls on Lakshmi, goddess of wealth and plenty, with prayers for financial growth, stability and a prosperous, happy home.',
    benefits: ['Financial growth', 'Stability', 'Abundance at home', 'Clears money blocks'],
    whoFor: 'Households wanting prosperity, people going through money troubles, and anyone starting a savings or investment journey.',
    bestTime: 'Fridays, Diwali, Purnima, Akshaya Tritiya.', duration: '60–90 min',
    offerings: "Lotus flowers, kamal gatta seeds, ghee, cow's milk, bilva, coins.",
    tags: ['wealth', 'money', 'Friday', 'Diwali', 'prosperity'],
    imagePrompt: 'Goddess Lakshmi in red and gold seated on a pink lotus, gold coins flowing from her open palm, two white elephants showering water, soft evening light.' },
  { slug: 'kubera-havan', type: 'havan', title: 'Kubera Havan', deity: 'Lord Kubera', category: 'wealth',
    description: 'Kubera keeps the treasury of the gods. Devotees offer this havan for growing savings, protecting wealth and lasting financial security, not windfalls.',
    benefits: ['Growing savings', 'Protection of assets', 'Steady income', 'Financial discipline'],
    whoFor: 'Savers, investors, people who earn well but cannot hold on to money, and business owners protecting capital.',
    bestTime: 'Dhanteras, Fridays, Thursdays, Akshaya Tritiya.', duration: '60–90 min',
    offerings: 'Ghee, rice, coins, yellow flowers, betel nuts.',
    tags: ['savings', 'assets', 'security'],
    imagePrompt: 'Plump, smiling Lord Kubera adorned with jewels, seated on a golden throne, holding a money pot, a mongoose beside him and gems glowing around.' },
  { slug: 'sri-suktam-havan', type: 'havan', title: 'Sri Suktam Havan', deity: 'Goddess Lakshmi', category: 'wealth',
    description: 'Centred on the Sri Suktam, among the oldest Vedic hymns to Lakshmi, this havan seeks prosperity that comes with grace and good character.',
    benefits: ['Prosperity that lasts', 'A good reputation', 'Freedom from want', 'Grace and contentment'],
    whoFor: 'Families wanting long-term prosperity, and those who prefer a Vedic, traditional havan.',
    bestTime: 'Fridays, Purnima, Diwali.', duration: '60–120 min',
    offerings: 'Lotus, bilva, ghee, kheer.',
    tags: ['Vedic', 'wealth', 'grace', 'tradition'],
    imagePrompt: 'Goddess Lakshmi standing in a field of golden lotuses at dawn, gentle light on her face, rice grains and gold at her feet.' },
  { slug: 'dhanvantari-lakshmi-havan', type: 'havan', title: 'Dhanvantari–Lakshmi Havan', deity: 'Lord Dhanvantari & Goddess Lakshmi', category: 'wealth',
    description: 'A Dhanteras havan that brings health and wealth together, in the belief that prosperity is incomplete without wellbeing.',
    benefits: ['Wealth with wellbeing', 'Prayers for good health', 'A prosperous year ahead'],
    whoFor: 'Families on Dhanteras, people rebuilding after illness and financial strain, and doctors and healers.',
    bestTime: 'Dhanteras (two days before Diwali).', duration: '60–90 min',
    offerings: 'Coriander seeds, ghee, a new utensil or coin, tulsi.',
    tags: ['Dhanteras', 'health', 'wealth', 'festival'],
    imagePrompt: 'Lord Dhanvantari holding a golden pot of nectar standing beside Goddess Lakshmi, healing herbs on one side and gold coins on the other, warm festive light.' },
  { slug: 'vishwakarma-havan', type: 'havan', title: 'Vishwakarma Havan', deity: 'Lord Vishwakarma', category: 'career',
    description: 'Honours Vishwakarma, the divine architect. Engineers, builders, factories, designers and tech teams offer it to bless their tools, machines and work.',
    benefits: ['Smooth running of tools and machines', 'Workplace safety', 'Skill and craftsmanship', 'Project success'],
    whoFor: 'Engineers, architects, factory owners, designers, developers, and anyone whose livelihood depends on tools.',
    bestTime: 'Vishwakarma Puja (17 September in most years), or before launching a project.', duration: '60–90 min',
    offerings: 'Flowers on tools and laptops, sweets, ghee, rice.',
    tags: ['engineers', 'craft', 'tools', 'workplace', 'tech'],
    imagePrompt: 'Lord Vishwakarma with a white beard, holding tools and a scroll, surrounded by glowing blueprints and gently turning machinery, calm workshop light.' },
  { slug: 'surya-havan', type: 'havan', title: 'Surya Havan', deity: 'Lord Surya (the Sun)', category: 'career',
    description: 'In tradition the Sun rules leadership, authority, vitality and recognition. Devotees offer this havan for a stronger career, confidence and standing.',
    benefits: ['Career growth and promotions', 'Leadership and confidence', 'Vitality', 'Recognition'],
    whoFor: 'Professionals seeking promotion, leaders, government-job aspirants, and people feeling low on energy.',
    bestTime: 'Sundays at sunrise, Ratha Saptami, Makar Sankranti.', duration: '60–90 min',
    offerings: 'Red flowers, wheat, jaggery, ghee, a copper vessel of water.',
    tags: ['career', 'leadership', 'Sunday', 'promotion', 'energy'],
    imagePrompt: 'Radiant Lord Surya in a golden chariot drawn by seven horses, lotuses in both hands, warm blazing but gentle sunrise light.' },
  { slug: 'lakshmi-narayana-havan', type: 'havan', title: 'Lakshmi–Narayana Havan', deity: 'Lord Vishnu & Goddess Lakshmi', category: 'career',
    description: 'Calls on Lakshmi and Narayana together for a business that prospers honestly — steady growth built on ethics and stability.',
    benefits: ['Business growth', 'Stability and protection', 'Ethical prosperity', 'Harmony between partners'],
    whoFor: 'Business owners, startup founders, partners launching a company, and families with a shared business.',
    bestTime: 'Thursdays, Fridays, Ekadashi, or a company anniversary.', duration: '60–90 min',
    offerings: 'Tulsi, lotus, ghee, kheer, coins.',
    tags: ['business', 'startup', 'growth', 'partnership'],
    imagePrompt: 'Lord Vishnu and Goddess Lakshmi seated together on Garuda in flight, golden sky, both with hands raised in blessing.' },
  { slug: 'rudra-havan', type: 'havan', title: 'Rudra Havan', deity: 'Lord Shiva', category: 'career',
    description: 'A havan to Shiva offered with the Sri Rudram hymn. Both powerful and peaceful, it is sought for strength in hard times and for rising to success.',
    benefits: ['Strength through hardship', 'Success in your efforts', 'Inner calm', 'Letting go of the past'],
    whoFor: 'People going through a tough phase, those seeking strength and resilience, Shiva devotees, and anyone before a major effort.',
    bestTime: 'Mondays, Pradosham, Maha Shivaratri, the month of Shravan.', duration: '90–150 min',
    offerings: 'Bilva leaves, ghee, milk, honey, sesame, rudraksha.',
    tags: ['Shiva', 'strength', 'resilience', 'Monday', 'Shravan'],
    imagePrompt: 'Peaceful Lord Shiva meditating on Mount Kailash, crescent moon in his hair, Ganga flowing gently from his locks, snow peaks and a clear blue sky.' },
  { slug: 'mahamrityunjaya-havan', type: 'havan', title: 'Mahamrityunjaya Havan', deity: 'Lord Shiva (Mrityunjaya)', category: 'health',
    description: 'A havan with the Mahamrityunjaya mantra, the great prayer for wellbeing — offered for loved ones who are unwell, for strength in treatment, and long life.',
    benefits: ['Prayers for recovery', 'Strength and calm during treatment or surgery', 'Blessings for a long life', 'Relief from worry about illness'],
    whoFor: 'Anyone who is unwell or has a family member in hospital, people before surgery, elderly parents, and those living with long-term health issues.',
    bestTime: 'Mondays, Shivaratri, or whenever it is needed — no muhurat is required.', duration: '90–180 min (often 1008 or 11,000 mantras over several days)',
    offerings: 'Bilva, durva, ghee, milk, sesame, amrit (honey-water).',
    tags: ['healing', 'surgery', 'recovery', 'longevity'], muhurat: 'none',
    note: 'A prayer offered alongside medical care, never instead of it. Please keep following your doctor’s advice.',
    imagePrompt: 'Calm Lord Shiva with a gentle smile, holding a pot of nectar and a rudraksha mala, soft white-blue healing light radiating outward.' },
  { slug: 'dhanvantari-havan', type: 'havan', title: 'Dhanvantari Havan', deity: 'Lord Dhanvantari', category: 'health',
    description: 'Honours Dhanvantari, the divine physician who in tradition gave Ayurveda to the world. Offered for wellbeing and the good health of the whole family.',
    benefits: ['Prayers for good health', 'Blessings on healing', 'Wellbeing for the family', 'Blessings for doctors and healers'],
    whoFor: 'Families with health worries, doctors and healthcare workers, and people starting a health journey.',
    bestTime: 'Dhanteras, Ekadashi, or any day when needed.', duration: '60–90 min',
    offerings: 'Tulsi, herbs, ghee, honey, fruits.',
    tags: ['health', 'healing', 'Ayurveda', 'doctors'],
    note: 'A prayer offered alongside medical care, never instead of it.',
    imagePrompt: 'Lord Dhanvantari in blue rising from the ocean of milk, holding a golden pot of amrit, healing herbs and lotus around him, soft dawn light.' },
  { slug: 'ayush-havan', type: 'havan', title: 'Ayush Havan', deity: 'Ayur Devata & Lord Vishnu', category: 'health',
    description: "A havan for a long and healthy life, traditionally held on a child's first birthday, and also for elders or anyone hoping for vitality.",
    benefits: ['Blessings for a long life', 'Good health', 'Protection of children', 'Vitality'],
    whoFor: "Parents on a child's first birthday, families of elderly members, and anyone on a milestone birthday.",
    bestTime: 'On the birth nakshatra (star) of the person, or their birthday.', duration: '60–90 min',
    offerings: 'Durva grass, ghee, curd, rice, honey.',
    tags: ['birthday', 'children', 'elders', 'longevity'],
    imagePrompt: 'A radiant deity blessing a small child, a glowing tree of life behind them, soft green and gold tones, gentle and joyful.' },
  { slug: 'sudarshana-havan', type: 'havan', title: 'Sudarshana Havan', deity: "Sudarshana (Lord Vishnu's discus)", category: 'peace',
    description: "Invokes Vishnu's Sudarshana chakra as a gentle shield of light, offered for easing negativity, worry and unseen obstacles, without any fierce imagery.",
    benefits: ['Protection from negativity', 'Relief from worry', 'Clears hidden obstacles', 'Peace of mind'],
    whoFor: 'People feeling stuck or drained, those facing legal or workplace troubles, and anyone wanting a protective blessing.',
    bestTime: 'Any day, especially Wednesdays and Ekadashi.', duration: '60–90 min',
    offerings: 'Tulsi, ghee, rice, yellow flowers.',
    tags: ['protection', 'negativity', 'worry', 'obstacles'],
    imagePrompt: 'A glowing golden discus with serene Lord Vishnu at its centre, rays of warm light spreading outward like a protective shield, calm sky.' },
  { slug: 'swayamvara-parvati-havan', type: 'havan', title: 'Swayamvara Parvati Havan', deity: 'Goddess Parvati', category: 'family',
    description: 'Through devotion, Parvati chose her own partner. Devotees offer this havan when hoping for a timely, happy marriage with a good life partner.',
    benefits: ['A timely marriage', 'A compatible partner', 'Eases marriage delays', 'Harmony in courtship'],
    whoFor: 'Unmarried men and women, parents seeking a match for their children, and those facing delays.',
    bestTime: 'Fridays, Mondays, Navratri, Gauri Vrat days.', duration: '60–90 min',
    offerings: 'Red flowers, kumkum, bangles, ghee, jaggery.',
    tags: ['marriage', 'partner', 'delay', 'singles'],
    imagePrompt: 'Graceful Goddess Parvati in green and red bridal attire holding a flower garland, flowers falling gently around her, soft pink light.' },
  { slug: 'uma-maheshwara-havan', type: 'havan', title: 'Uma Maheshwara Havan', deity: 'Lord Shiva & Goddess Parvati', category: 'family',
    description: 'Honours Uma and Maheshwara, the ideal divine couple, with prayers for harmony, understanding and love between husband and wife.',
    benefits: ['Marital harmony', 'Clears misunderstandings', 'Deepens love', 'Family peace'],
    whoFor: 'Married couples, couples going through a rough patch, newlyweds, and anniversaries.',
    bestTime: 'Mondays, Pradosham, wedding anniversary, Karwa Chauth.', duration: '60–90 min',
    offerings: 'Bilva, red flowers, ghee, milk, sweets.',
    tags: ['couples', 'marriage', 'anniversary', 'harmony'],
    imagePrompt: 'Lord Shiva and Goddess Parvati seated together, holding hands, Nandi and little Ganesha nearby, mountain sunset in soft orange and blue.' },
  { slug: 'santana-gopala-havan', type: 'havan', title: 'Santana Gopala Havan', deity: 'Bala Krishna', category: 'family',
    description: "The havan for the blessing of children, offered by couples hoping to conceive, for a healthy pregnancy, and for children's wellbeing.",
    benefits: ['Blessings for conception', 'Prayers for a safe pregnancy', 'Healthy, happy children', 'A joyful home'],
    whoFor: 'Couples hoping for a baby, expecting parents, and grandparents praying for grandchildren.',
    bestTime: 'Ashtami tithi, Wednesdays, Janmashtami, Rohini nakshatra.', duration: '60–90 min',
    offerings: 'Butter, tulsi, milk, ghee, yellow flowers.',
    tags: ['children', 'conception', 'pregnancy', 'Krishna'],
    imagePrompt: 'Baby Krishna crawling with a lump of butter in hand, peacock feather in his hair, cows and a warm sunlit courtyard behind him.' },
  { slug: 'shanti-havan', type: 'havan', title: 'Shanti Havan', deity: 'All deities, with Lord Vishnu at the centre', category: 'peace',
    description: "A havan for peace, offered with the Shanti mantras, to calm discord at home, within the family, or in one's own mind.",
    benefits: ['Peace at home', 'Resolves conflicts', 'A calm mind', 'Harmony at work and in the neighbourhood'],
    whoFor: 'Families in conflict, anyone under stress, after a difficult event, or simply for a peaceful year.',
    bestTime: 'Any day; Purnima and Ekadashi are ideal.', duration: '60–90 min',
    offerings: 'White flowers, ghee, rice, sandalwood, kheer.',
    tags: ['peace', 'stress', 'conflict', 'family', 'calm'],
    imagePrompt: 'A glowing fire altar under a peaceful dawn sky, Lord Vishnu blessing from above, white doves and lotuses, soft white and gold light.' },
  { slug: 'hanuman-havan', type: 'havan', title: 'Hanuman Havan', deity: 'Lord Hanuman', category: 'peace',
    description: 'Calls on Hanuman, ever devoted and brave, for strength, courage and protection — always in his gentle, devotional form.',
    benefits: ['Courage', 'Freedom from fear and anxiety', 'Protection while travelling', 'Strength to face challenges'],
    whoFor: "Those feeling fearful or weak, students before big challenges, travellers, sportspeople, and anyone under Saturn's influence.",
    bestTime: 'Tuesdays, Saturdays, Hanuman Jayanti.', duration: '60–90 min',
    offerings: 'Sindoor, jasmine oil, betel leaves, laddoos, ghee.',
    tags: ['courage', 'fear', 'protection', 'Tuesday', 'strength'],
    imagePrompt: 'Strong yet kind Lord Hanuman kneeling in devotion with hands folded, a glowing heart revealing Rama and Sita, orange sunrise sky.' },
  { slug: 'rama-havan', type: 'havan', title: 'Rama Havan', deity: 'Lord Rama', category: 'peace',
    description: 'Honours Lord Rama, the embodiment of righteousness, with prayers for dharma, strong family values and good prevailing over difficulty.',
    benefits: ['Righteous success', 'Strong family values', 'Victory over difficulties', 'Inner discipline'],
    whoFor: 'Families wanting strong values, those in a moral dilemma, and people facing a long struggle.',
    bestTime: 'Ram Navami, Navami tithi, Punarvasu nakshatra.', duration: '60–90 min',
    offerings: 'Tulsi, lotus, ghee, fruits, kheer.',
    tags: ['dharma', 'values', 'family', 'victory'],
    imagePrompt: 'Lord Rama with a bow on his shoulder, Sita and Lakshmana beside him, Hanuman at their feet, the palace of Ayodhya glowing behind them.' },
  { slug: 'krishna-havan', type: 'havan', title: 'Krishna Havan', deity: 'Lord Krishna', category: 'peace',
    description: 'A joyful havan that calls on Krishna as friend and guide, for devotion, wisdom and happiness in daily life.',
    benefits: ['Joy and lightness', 'Wisdom in decisions', 'Devotion', 'Easing of sorrow'],
    whoFor: 'Anyone feeling low or heavy-hearted, seekers of wisdom, and families on Janmashtami.',
    bestTime: 'Janmashtami, Wednesdays, Ashtami, Rohini nakshatra.', duration: '60–90 min',
    offerings: 'Butter, tulsi, milk sweets, yellow flowers, ghee.',
    tags: ['joy', 'wisdom', 'devotion', 'Janmashtami'],
    imagePrompt: 'Lord Krishna playing the flute under a kadamba tree by the Yamuna, peacocks and cows around him, moonlit night with a soft blue glow.' },

  // ───────────────────────────── PUJAS (25) ─────────────────────────────
  { slug: 'ganesh-puja', type: 'puja', title: 'Ganesh Puja', deity: 'Lord Ganesha', category: 'luck',
    description: 'The simplest and best-loved puja: an offering to Ganesha before a new start, or just for good luck in everyday life.',
    benefits: ['Clears obstacles', 'Good luck', 'Confidence before beginnings', 'Daily positivity'],
    whoFor: 'Everyone. The ideal first puja for beginners, students, new businesses, and before travel or events.',
    bestTime: 'Wednesdays, Chaturthi, mornings.', duration: '20–40 min',
    offerings: 'Durva grass, red flowers, modak, coconut, a lamp.',
    tags: ['beginners', 'daily', 'luck', 'quick', 'most popular'],
    imagePrompt: 'Smiling Lord Ganesha in red and gold on a small home altar, marigold garland, a plate of modaks and a lit brass lamp, warm cosy light.' },
  { slug: 'satyanarayan-puja', type: 'puja', title: 'Satyanarayan Puja', deity: 'Lord Satyanarayana (Vishnu)', category: 'family',
    description: 'A household puja with the Satyanarayan katha read aloud, traditionally held after good news or to call blessings on the whole family.',
    benefits: ['Family harmony', 'Gratitude', 'Prosperity', 'Fulfilment of wishes'],
    whoFor: 'Families after a milestone, housewarming, new job or recovery — or every full moon as a tradition.',
    bestTime: 'Purnima, Ekadashi, Thursdays.', duration: '60–90 min',
    offerings: 'Panchamrit, tulsi, sheera, bananas, betel leaves.',
    tags: ['family', 'katha', 'full moon', 'gratitude'],
    imagePrompt: 'Lord Vishnu on a flower-decorated home altar, a family seated around listening to a priest read the katha, bananas, tulsi and sheera prasad in front.' },
  { slug: 'lakshmi-puja', type: 'puja', title: 'Lakshmi Puja', deity: 'Goddess Lakshmi', category: 'wealth',
    description: 'Evening worship of Lakshmi, goddess of wealth — the centre of Diwali, and a Friday ritual in many homes every week.',
    benefits: ['Wealth and abundance', 'Stable finances', 'Blessings on business', 'A bright, prosperous home'],
    whoFor: 'Households, shop and business owners, and anyone starting a financial goal.',
    bestTime: 'Diwali evening, Fridays, Purnima, Akshaya Tritiya.', duration: '30–60 min',
    offerings: 'Lotus, coins, kheer, lamps, kumkum, rice.',
    tags: ['Diwali', 'wealth', 'Friday', 'home', 'business'],
    imagePrompt: 'Goddess Lakshmi on a lotus surrounded by rows of glowing diyas, gold coins, rangoli and a bowl of sweets, deep festive evening light.' },
  { slug: 'saraswati-puja', type: 'puja', title: 'Saraswati Puja', deity: 'Goddess Saraswati', category: 'education',
    description: 'Worship of Saraswati, goddess of learning, with books, pens or instruments laid at the altar to receive her blessing.',
    benefits: ['Focus and memory', 'Exam success', 'Blessings for art and music', 'Clear speech'],
    whoFor: 'Students, teachers, musicians, artists, and parents of children starting school.',
    bestTime: 'Vasant Panchami, Navratri days 7–9, before exams.', duration: '30–45 min',
    offerings: 'Yellow flowers, sweets, books or instruments at the altar, white cloth.',
    tags: ['exams', 'students', 'arts', 'Vasant Panchami'],
    imagePrompt: 'Goddess Saraswati in white on a lotus, books, a pen and a small veena placed before her, yellow flowers and a lamp, soft morning light.' },
  { slug: 'vidyarambham', type: 'puja', title: 'Vidyarambham (Aksharabhyasam)', deity: 'Goddess Saraswati & Lord Ganesha', category: 'life',
    description: "A child writes their first letters in rice, guided by a loving hand, beginning their education with the goddess's blessing.",
    benefits: ['An auspicious start to learning', 'A love of study', 'Saraswati’s blessing on the child'],
    whoFor: 'Parents of children aged 2–5 who are about to start school.',
    bestTime: 'Vijayadashami (Dussehra), Vasant Panchami.', duration: '30–45 min',
    offerings: 'A plate of rice, a slate or book, sweets, flowers.',
    tags: ['children', 'first school', 'Dussehra', 'milestone'], muhurat: 'recommended',
    imagePrompt: "A small child's finger tracing a letter in a plate of rice, a parent's hand guiding, a Goddess Saraswati image glowing softly above, warm joyful light." },
  { slug: 'namkaran-puja', type: 'puja', title: 'Namkaran Puja', deity: 'Lord Ganesha, the Navagraha & the family deity', category: 'life',
    description: "The naming ceremony, where the baby's name is chosen, often by birth star, and whispered into their ear amid blessings.",
    benefits: ['An auspicious name aligned to the birth star', 'Blessings of health and long life for the baby'],
    whoFor: 'New parents, typically on the 11th–12th day or within the first month.',
    bestTime: 'The 11th, 12th or 21st day after birth, or an auspicious muhurat.', duration: '45–60 min',
    offerings: 'Rice, honey, flowers, new clothes for the baby.',
    tags: ['newborn', 'naming', 'milestone', 'family'], muhurat: 'recommended',
    imagePrompt: 'A newborn in a soft cradle decorated with flowers, parents leaning in lovingly, a Lord Ganesha image on a small altar, gentle morning light.' },
  { slug: 'annaprashan-puja', type: 'puja', title: 'Annaprashan Puja', deity: 'Lord Vishnu & Goddess Annapurna', category: 'life',
    description: "Marks a baby's first taste of solid food, usually sweet rice, offered with prayers for good nourishment and health.",
    benefits: ['Blessings for good health', 'Nourishment', 'A joyful family celebration'],
    whoFor: 'Parents when the baby is around six months old.',
    bestTime: 'The 6th–8th month, on an auspicious muhurat.', duration: '30–45 min',
    offerings: 'Kheer or sweet rice, fruits, flowers.',
    tags: ['baby', 'first food', 'milestone'], muhurat: 'recommended',
    imagePrompt: 'A smiling baby being fed a spoon of kheer by a grandparent, Goddess Annapurna with a ladle glowing above, family gathered around.' },
  { slug: 'mundan-puja', type: 'puja', title: 'Mundan Puja', deity: 'The family deity & Lord Ganesha', category: 'life',
    description: "The ceremony of a child's first haircut, celebrating a fresh and healthy start in life with prayers from the family.",
    benefits: ['Blessings for health and long life', 'A cherished family tradition'],
    whoFor: 'Parents of children aged one to three.',
    bestTime: 'The 1st or 3rd year, on an auspicious muhurat, often at a temple.', duration: '30–45 min',
    offerings: 'Flowers, sweets, new clothes.',
    tags: ['toddler', 'first haircut', 'milestone'], muhurat: 'recommended',
    imagePrompt: "A calm toddler on a parent's lap, a priest blessing with a flower, a small altar with Lord Ganesha, soft outdoor light." },
  { slug: 'birthday-puja', type: 'puja', title: 'Janmadin (Birthday) Puja', deity: 'Your ishta devata & Ayur Devata', category: 'life',
    description: 'A puja for a birthday, often held on the birth star rather than the calendar date, praying for a long, healthy and fruitful year ahead.',
    benefits: ['Blessings for a long life', 'Good health', 'Success in the year ahead', 'Gratitude'],
    whoFor: 'Anyone on their birthday, especially milestone years (1, 16, 21, 50, 60, 80).',
    bestTime: 'The birth nakshatra day, or the birthday morning.', duration: '30–45 min',
    offerings: 'A lamp, flowers, sweets, fruits.',
    tags: ['birthday', 'longevity', 'personal'],
    imagePrompt: 'A person lighting a lamp before their personal deity, flowers and sweets on the altar, a soft glow of many lamps around, joyful.' },
  { slug: 'vahan-puja', type: 'puja', title: 'Vahan Puja', deity: 'Lord Ganesha & Lord Vishwakarma', category: 'luck',
    description: 'Blesses a new vehicle — a car, bike, truck or an entire fleet — with prayers for safe journeys on every road.',
    benefits: ['Safe travel', 'Protection on the road', 'Smooth running of the vehicle'],
    whoFor: 'Anyone buying a new vehicle, transport businesses and delivery fleets.',
    bestTime: 'The day of delivery, or an auspicious muhurat.', duration: '20–30 min',
    offerings: 'Lemons, a garland, coconut, kumkum, incense.',
    tags: ['new car', 'bike', 'safety', 'travel'],
    imagePrompt: 'A new car decorated with a marigold garland, a lemon under each wheel, a swastika drawn in kumkum on the bonnet, a family standing beside it smiling.' },
  { slug: 'business-opening-puja', type: 'puja', title: 'Shop & Business Opening Puja', deity: 'Lord Ganesha, Goddess Lakshmi & Lord Kubera', category: 'career',
    description: 'Opens a new shop, office or venture with prayers for luck and prosperity, including lighting the first lamp and marking the very first sale.',
    benefits: ['A prosperous start', 'Clears obstacles', 'Welcomes customers', "The owner's confidence"],
    whoFor: 'Shop owners, startup founders, franchise openings, and freelancers starting a practice.',
    bestTime: 'An auspicious muhurat, Diwali, Akshaya Tritiya, Dhanteras.', duration: '45–60 min',
    offerings: 'Coconut, a lamp, coins, sweets, flowers, the account book.',
    tags: ['shop', 'startup', 'inauguration', 'muhurat'], muhurat: 'recommended',
    imagePrompt: 'A ribbon-decorated shop entrance with a rangoli, Lord Ganesha and Goddess Lakshmi on a small altar inside, the owner lighting a brass lamp, marigold strings overhead.' },
  { slug: 'chopda-pujan', type: 'puja', title: 'Chopda Pujan (Account Book Puja)', deity: 'Goddess Lakshmi, Lord Ganesha & Goddess Saraswati', category: 'career',
    description: 'The Diwali custom of blessing new account books — today often the laptop and accounting software too — for a profitable financial year.',
    benefits: ['A profitable year', 'Clean accounts', "Lakshmi's blessing on income"],
    whoFor: 'Traders, accountants, business owners, freelancers, and anyone starting a new financial year.',
    bestTime: 'Diwali (the Lakshmi Puja evening).', duration: '30–45 min',
    offerings: 'A new ledger, a pen, coins, kumkum, sweets.',
    tags: ['Diwali', 'business', 'accounts', 'traders'],
    imagePrompt: 'A red cloth-bound ledger with a swastika drawn in kumkum, a laptop beside it, Goddess Lakshmi and Lord Ganesha images, coins and a lit lamp, warm Diwali evening.' },
  { slug: 'vastu-puja', type: 'puja', title: 'Vastu Puja', deity: 'Vastu Purusha & Lord Ganesha', category: 'luck',
    description: "A lighter alternative to the Vastu Shanti Havan for homes and offices, balancing a space's energy with a copper yantra and offerings.",
    benefits: ['A peaceful home', 'Balanced energy', 'Eases vastu defects'],
    whoFor: 'New tenants, renovated homes, offices with frequent staff friction, and anyone who feels uneasy in a space.',
    bestTime: 'Before moving in, or any auspicious day.', duration: '45–60 min',
    offerings: 'Vastu yantra, five grains, flowers, a lamp.',
    tags: ['home', 'office', 'vastu', 'energy'],
    imagePrompt: 'A copper vastu yantra on a red cloth at the centre of a bright, clean room, a lamp at each corner, Lord Ganesha on a small altar.' },
  { slug: 'rudrabhishek', type: 'puja', title: 'Rudrabhishek', deity: 'Lord Shiva', category: 'peace',
    description: 'The Shiva linga is bathed in milk, honey, curd, ghee and water as the Rudram is chanted — among the most cherished of all Shiva pujas.',
    benefits: ['Peace of mind', 'Easing of hardship', 'Wellbeing', 'Fulfilment of sincere wishes'],
    whoFor: 'Shiva devotees, anyone in a difficult phase, and people seeking peace — especially on Mondays and in Shravan.',
    bestTime: 'Mondays, Pradosham, Shivaratri, the month of Shravan.', duration: '60–90 min',
    offerings: 'Milk, curd, honey, ghee, sugar, bilva, water.',
    tags: ['Shiva', 'abhishek', 'Monday', 'Shravan', 'peace'],
    imagePrompt: 'A Shiva linga being bathed in a stream of milk and flower petals, bilva leaves piled on top, brass lamps around, warm temple sanctum glow.' },
  { slug: 'hanuman-chalisa-path', type: 'puja', title: 'Hanuman Chalisa Path & Puja', deity: 'Lord Hanuman', category: 'peace',
    description: 'An offering to Hanuman with the Hanuman Chalisa recited, often 11, 21 or 108 times, for courage and freedom from worry.',
    benefits: ['Courage', 'Freedom from fear', 'Protection', "Relief during Saturn's phases"],
    whoFor: 'Anyone anxious or fearful, students before results, travellers, and people going through a hard phase.',
    bestTime: 'Tuesdays, Saturdays, Hanuman Jayanti.', duration: '30–90 min, depending on repetitions',
    offerings: 'Sindoor, jasmine oil, laddoos, betel leaves.',
    tags: ['courage', 'Tuesday', 'Chalisa', 'Saturn'],
    imagePrompt: 'Gentle Lord Hanuman in orange with folded hands, a mound of laddoos and jasmine flowers before him, devotees chanting softly in warm lamplight.' },
  { slug: 'sundarkand-path', type: 'puja', title: 'Sundarkand Path', deity: 'Lord Hanuman & Lord Rama', category: 'peace',
    description: "A recitation of Sundarkand from the Ramcharitmanas, telling of Hanuman's search for Sita, cherished for hope and success in tasks that seem impossible.",
    benefits: ['Hope in difficult times', 'Success in tough tasks', 'Protection', 'Emotional strength'],
    whoFor: 'Families facing a long struggle, before big exams or court dates, and groups keeping a Tuesday tradition.',
    bestTime: 'Tuesdays, Saturdays, Hanuman Jayanti.', duration: '120–180 min',
    offerings: 'Flowers, sweets, a lamp, red cloth.',
    tags: ['path', 'Hanuman', 'hope', 'difficult tasks'],
    imagePrompt: 'Lord Hanuman flying gracefully over a calm blue ocean toward a golden shore at sunrise, an open scripture on a small altar below.' },
  { slug: 'durga-puja', type: 'puja', title: 'Durga Puja', deity: 'Goddess Durga', category: 'peace',
    description: "Worship of the Mother Goddess in her calm, motherly form, honoured as the source of the family's strength and protection.",
    benefits: ['Strength', 'Protection for the family', 'Courage', 'Freedom from fear'],
    whoFor: 'Families during Navratri, women seeking strength, and anyone needing protection and confidence.',
    bestTime: 'Both Navratris, Ashtami, Fridays.', duration: '45–60 min',
    offerings: 'Red flowers, chunri, coconut, kumkum, sweets.',
    tags: ['Navratri', 'strength', 'Devi', 'family'],
    imagePrompt: 'Graceful Goddess Durga seated on a lion with a calm, motherly face, holding a lotus, dressed in red and gold, marigolds and a temple backdrop, no battle scene.' },
  { slug: 'kanya-puja', type: 'puja', title: 'Kanya Puja', deity: 'The Devi, honoured in young girls', category: 'festival',
    description: 'On Ashtami or Navami of Navratri, young girls are honoured as the goddess with a meal and gifts — a joyful and beautiful tradition.',
    benefits: ["The Devi's blessing", 'Gratitude', 'Family joy', 'Charity'],
    whoFor: 'Families during Navratri, and anyone wanting a service-oriented puja.',
    bestTime: 'Ashtami or Navami of Navratri.', duration: '60 min',
    offerings: 'Puri, halwa, chana, gifts, a red chunri.',
    tags: ['Navratri', 'children', 'charity', 'festival'],
    imagePrompt: 'A row of smiling little girls seated on a mat in festive clothes, plates of puri, halwa and chana before them, a joyful decorated home.' },
  { slug: 'karwa-chauth-puja', type: 'puja', title: 'Karwa Chauth Puja', deity: 'Goddess Parvati, Lord Shiva & Chandra (the Moon)', category: 'family',
    description: "The Karwa Chauth evening puja, where married women pray for their husband's long life and hear the vrat katha before the moon rises.",
    benefits: ["Prayers for a spouse's long life", 'Marital harmony', "Parvati's blessings"],
    whoFor: 'Married women observing the vrat, and couples celebrating together.',
    bestTime: 'Karwa Chauth evening (Kartik Krishna Chaturthi).', duration: '45–60 min',
    offerings: 'A karwa pot, a sieve, sweets, henna, red bangles.',
    tags: ['marriage', 'vrat', 'moon', 'festival'],
    imagePrompt: 'Women dressed in red finery seated in a circle around a decorated karwa pot and a Goddess Parvati image, a sieve and lamp in hand, full moon rising in the background.' },
  { slug: 'tulsi-puja', type: 'puja', title: 'Tulsi Puja & Tulsi Vivah', deity: 'Tulsi Devi & Lord Vishnu', category: 'festival',
    description: 'Worship of the holy tulsi plant, either as a daily lamp offering or as the ceremonial wedding of Tulsi and Vishnu that begins the wedding season.',
    benefits: ['Auspiciousness in the home', 'Devotion', 'Wellbeing', 'Blessings for the marriage season'],
    whoFor: 'Households with a tulsi plant, families seeking marriage alliances, and Vishnu devotees.',
    bestTime: 'Daily evenings; Tulsi Vivah from Kartik Shukla Ekadashi to Purnima.', duration: '15–60 min',
    offerings: 'A lamp, water, red cloth, flowers, sugarcane (for the vivah).',
    tags: ['daily', 'tulsi', 'home', 'Kartik', 'marriage season'],
    imagePrompt: 'A tulsi plant in a decorated clay pot, dressed with a red cloth and a small garland, a lamp glowing beside it, a Lord Vishnu image nearby, evening courtyard.' },
  { slug: 'gau-puja', type: 'puja', title: 'Gau Puja', deity: 'Kamadhenu (Gau Mata)', category: 'festival',
    description: 'Honours the cow as a mother and a giver of abundance, by feeding and decorating her and circling her with prayers.',
    benefits: ['Abundance', 'Gratitude', 'Protection', "Kamadhenu's blessings"],
    whoFor: 'Families on Govatsa Dwadashi or Gopashtami, anyone wanting a simple charitable puja, and farmers.',
    bestTime: 'Govatsa Dwadashi, Gopashtami, Fridays.', duration: '20–30 min',
    offerings: 'Green fodder, jaggery, roti, flowers, kumkum.',
    tags: ['cow', 'charity', 'gratitude', 'festival'],
    imagePrompt: 'A gentle white cow with a garland and painted horns, a child feeding her a green leaf, a farm courtyard in soft golden light.' },
  { slug: 'ganga-puja', type: 'puja', title: 'Ganga Puja', deity: 'Goddess Ganga', category: 'peace',
    description: 'An evening offering of lamps to Ganga, the river goddess, for purification, letting go of the past, and peace — lovely to watch from the ghats.',
    benefits: ['Purification', 'Letting go of past burdens', 'Peace', 'Blessings for ancestors'],
    whoFor: 'Anyone seeking a fresh start, those remembering ancestors, and devotees who cannot travel to the ghats.',
    bestTime: 'Every evening at sunset; Ganga Dussehra; Kartik Purnima.', duration: '30–45 min',
    offerings: 'Floating diyas, flowers, incense.',
    tags: ['ghat', 'Haridwar', 'Rishikesh', 'Varanasi', 'evening'],
    imagePrompt: 'Priests holding tiered brass lamps at a river ghat at dusk, hundreds of floating diyas on the water, Goddess Ganga glowing softly above the river.' },
  { slug: 'surya-arghya', type: 'puja', title: 'Surya Arghya & Chhath Puja', deity: 'Lord Surya (the Sun)', category: 'health',
    description: 'Water offered to the rising or setting sun — a daily practice for vitality and the heart of the Chhath festival.',
    benefits: ['Energy and vitality', 'Confidence', 'Gratitude', 'A bright start to the day'],
    whoFor: 'Everyone as a daily practice, families during Chhath, and anyone wanting more vitality.',
    bestTime: 'Sunrise daily; Chhath (six days after Diwali); Ratha Saptami.', duration: '10–20 min daily; Chhath 2–3 hours',
    offerings: 'Water in a copper vessel, red flowers, thekua (for Chhath).',
    tags: ['sunrise', 'daily', 'energy', 'Chhath', 'Bihar'],
    imagePrompt: 'A person standing in a river offering water from a copper vessel to a rising sun, golden light on the water, marigolds floating.' },
];

const altFromPrompt = (prompt: string) => prompt.replace(/\.$/, '') + '.';

export const rituals: Ritual[] = sources.map(source => ({
  ...source,
  href: '/rituals/' + source.slug + '/', // [WEB-SEO-REBRAND-1] trailing slash = the URL Pages serves with 200
  image: `${RITUAL_IMAGE_DIR}/${source.slug}.png`,
  imageAlt: altFromPrompt(source.imagePrompt),
}));

export const ritualBySlug = (slug: string) => rituals.find(ritual => ritual.slug === slug);

// [AUMFE-COPY-SEO-1 2026-10-01] ONE place for each article's search title and
// description, shared by pages/rituals/[slug].astro and lib/seo/resolve.ts (the OG
// card revision depends on both matching). The title stays <= 60 characters once
// resolve.ts appends " · <brand>"; the description aims for 140-160 characters.
export function ritualArticleTitle(ritual: Ritual): string {
  const options = [
    `${ritual.title} Online: Meaning, Story & Blessings`,
    `${ritual.title}: Meaning, Story & Blessings`,
    `${ritual.title}: Meaning & Story`,
  ];
  return options.find(t => t.length + BRAND.name.length + 3 <= 60) ?? ritual.title;
}

export function ritualArticleSummary(ritual: Ritual): string {
  const tails = [' Join online from anywhere, in India or abroad.', ' Take part online from anywhere.', ' Join online.', ''];
  for (const tail of tails) {
    const text = ritual.description + tail;
    if (text.length <= 160 && (text.length >= 140 || tail === '')) return text;
  }
  return ritual.description;
}

/** The eight havans featured on the homepage, in display order. */
export const FEATURED_HAVAN_SLUGS = [
  'ganapati-havan',
  'saraswati-havan',
  'lakshmi-havan',
  'mahamrityunjaya-havan',
  'satyanarayana-havan',
  'griha-pravesh-havan',
  'rudra-havan',
  'shanti-havan',
] as const;

export const featuredHavans: Ritual[] = FEATURED_HAVAN_SLUGS.map(slug => {
  const ritual = ritualBySlug(slug);
  if (!ritual) throw new Error('Featured havan missing from ritualGuides: ' + slug);
  return ritual;
});

/** Commitment level from the catalogue's "Part 3" guidance. */
export function commitmentFor(ritual: Ritual): string {
  const minutes = Number(ritual.duration.match(/(\d+)\s*(?:–\s*(\d+))?\s*min/)?.[2] ?? ritual.duration.match(/(\d+)/)?.[1] ?? 60);
  if (minutes <= 40) return 'Light — under 45 minutes, no fasting needed';
  if (minutes <= 90) return 'Standard — about an hour to an hour and a half';
  return 'Extended — a longer ritual; a light sattvic meal beforehand is traditional';
}

export function muhuratFor(ritual: Ritual): string {
  if (ritual.muhurat === 'required') return 'Required — we will fix an auspicious muhurat with you';
  if (ritual.muhurat === 'recommended') return 'Recommended — we can suggest an auspicious date';
  return 'Not needed — it can be performed on any day';
}

/** Related rituals: same category first, then same deity family, never itself. */
export function relatedRituals(ritual: Ritual, count = 3): Ritual[] {
  const sameCategory = rituals.filter(item => item.slug !== ritual.slug && item.category === ritual.category);
  const others = rituals.filter(item => item.slug !== ritual.slug && item.category !== ritual.category && item.type !== ritual.type && item.deity === ritual.deity);
  return [...sameCategory, ...others].slice(0, count);
}
